"""Selected idx31 rerun through the original frozen DINO adapter and GD runner.

Only the independent plan.py copy changes environment index mapping; the copied
evaluate.py audit permits this precisely selected singleton. MPC, GD, success,
normalization and simulator implementations are otherwise unchanged.
"""
import hashlib
import importlib.metadata
import json
import os
import pickle
import platform
from pathlib import Path
import sys
import time

HERE=Path(__file__).resolve().parent
PLAN=HERE.parent
sys.path.insert(0,str(HERE))
import evaluate as original
import hydra
import numpy as np
import torch
from omegaconf import OmegaConf,open_dict
from PIL import Image
from einops import rearrange


def write_json(name,value):
    Path(name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')


def array_hash(value):
    return hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()


def rng_hash():
    return {'cpu':array_hash(torch.get_rng_state().numpy()),
            'cuda':array_hash(torch.cuda.get_rng_state().cpu().numpy())}


class QualitativeWorkspace(original.AuditedWorkspace):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        assert self.n_evals==1 and self.eval_seed==[3101]
        assert int(self.cfg_dict['seed'])==100
        assert self.planner.n_taken_actions==1 and self.planner.max_iter==30
        assert self.planner.reuse_actions and self.planner.resim_from_start
        sub=self.planner.sub_planner
        assert sub.horizon==5 and sub.lr==.1 and sub.opt_steps==100
        assert sub.sample_type=='zero' and sub.action_noise==0 and not sub.cuda_graph
        assert sub.optimizer_name=='adam' and sub.use_cosine_scheduler
        assert self.cfg_dict['ood_corruption'] is None
        assert self.cfg_dict['env_kwargs_override']=={'color':'Red'}
        assert not any(p.requires_grad for p in self.wm.parameters())
        assert not any(module.training for module in self.wm.modules())
        expected=json.loads((PLAN/'reference/rerun_30mpc/expected_target.json').read_text())
        originals=pickle.loads((PLAN/'reference/raw/dinowm/plan_targets.pkl').read_bytes())
        with np.load(PLAN/'reference/raw/dinowm/final_eval_results.npz') as ref:
            assert np.array_equal(self.state_0[0],ref['state_0'][31])
            assert np.array_equal(self.state_g[0],ref['state_g'][31])
        pair=hashlib.sha256(self.state_0[0].tobytes()+self.state_g[0].tobytes()).hexdigest()
        assert pair==expected['target_pair_float32_sha256']
        assert np.array_equal(self.obs_0['visual'][0,0],originals['obs_0']['visual'][31,0])
        assert np.array_equal(self.obs_g['visual'][0,0],originals['obs_g']['visual'][31,0])
        Image.fromarray(self.obs_0['visual'][0,0]).save('start.png')
        Image.fromarray(self.obs_g['visual'][0,0]).save('goal.png')
        write_json('target_check.json',dict(original_index=31,environment_seed=3101,
            target_pair_float32_sha256=pair,states_exact=True,observation_pixels_exact=True,
            start_pixels_match_paper=bool(np.array_equal(self.obs_0['visual'][0,0],np.asarray(Image.open(PLAN/'reference/frames/dinowm/start.png')))),
            goal_pixels_match_paper=bool(np.array_equal(self.obs_g['visual'][0,0],np.asarray(Image.open(PLAN/'reference/frames/dinowm/goal.png'))))))
        self.before=original.weights_hash(self.wm)
        archived=json.loads((PLAN/'reference/raw/dinowm/frozen_weights_check.json').read_text())
        assert self.before==archived['before_sha256'],'Loaded model differs from original evaluated DINO-WM'
        self.mpc_records=[];self.optimization_records=[];self.last_feedback=None;self.final_replay=None
        self.simulator_action_evaluations=0
        self._install_gd_audit()
        self._install_feedback_audit()
        protocol=json.loads(Path('runtime_protocol.json').read_text())
        protocol.update(original_batch_size=50,original_sample_index=31,environment_seed=3101,
            global_seed=100,goal_reference_replay_seed=3101,ood_corruption=None,
            stochastic_observation_corruption_used=False,
            feedback_noise_note='red_object is an environment color override; no noise RNG is called',
            eval_seed_mapping='seed * original_sample_index + 1',resim_from_start=True,
            single_sample_filter='Original segment[31] copied unchanged; index metadata retained',
            gd_rng_policy='Preserve original 50-microbatch RNG consumption: skip zero-amplitude noise draws for 31 preceding/18 following samples each replan; no other samples are optimized',
            predictor_dropout_in_eval=False,model_hash_matches_original_evaluation=True,
            actual_online_model_updates=0,parameter_count=sum(p.numel() for p in self.wm.parameters()))
        write_json('runtime_protocol.json',protocol)
        write_json('protocol.json',protocol)

    def _install_gd_audit(self):
        sub=self.planner.sub_planner
        original_plan=sub.plan
        original_factory=sub.get_action_optimizer
        self._optimizer_stats=None
        def factory(actions):
            assert actions.requires_grad and not any(p.requires_grad for p in self.wm.parameters())
            opt=original_factory(actions)
            def before_step(optimizer,args,kwargs):
                grad=actions.grad
                assert grad is not None and torch.isfinite(grad).all()
                stats=self._optimizer_stats;stats['steps']+=1
                if stats['steps'] in (1,100):stats[f'gradient_norm_step_{stats["steps"]}']=float(grad.norm())
            opt.register_step_pre_hook(before_step)
            return opt
        sub.get_action_optimizer=factory
        def selected_plan(obs_0,obs_g,actions=None,step=None):
            assert obs_0['visual'].shape[0]==1
            stats={'steps':0};self._optimizer_stats=stats
            # Original GD unconditionally draws randn_like even at action_noise=0.
            # Retain the original microbatch idx31 RNG position without solving
            # the other 49 episodes. Zero init, eval mode and zero noise make
            # those draws numerically irrelevant to actions, but auditable.
            before=rng_hash();dummy=torch.empty((1,sub.horizon,self.action_dim),device=self.device)
            for _ in range(31*sub.opt_steps):torch.randn_like(dummy)
            selected_before=rng_hash()
            t=time.perf_counter();predicted,valid=original_plan(obs_0,obs_g,actions=actions,step=step)
            torch.cuda.synchronize();elapsed=time.perf_counter()-t
            selected_after=rng_hash()
            for _ in range(18*sub.opt_steps):torch.randn_like(dummy)
            assert stats['steps']==100 and torch.isfinite(predicted).all()
            rec=dict(replan_index=len(self.optimization_records)+1,original_index=31,step_argument=step,
                warm_start_model_slots=0 if actions is None else int(actions.shape[1]),
                horizon_model_slots=int(predicted.shape[1]),gd_steps=stats['steps'],
                first_action_gradient_norm=stats['gradient_norm_step_1'],last_action_gradient_norm=stats['gradient_norm_step_100'],
                actions_require_grad=bool(predicted.requires_grad),model_requires_grad=False,
                prediction_action_sha256=array_hash(predicted.detach().cpu().numpy()),optimization_seconds=elapsed,
                rng_before_original_batch=before,rng_before_original_index31=selected_before,
                rng_after_original_index31=selected_after,rng_after_original_batch=rng_hash(),
                preceding_zero_noise_draw_calls=3100,following_zero_noise_draw_calls=1800)
            self.optimization_records.append(rec)
            with open('optimization_audit.jsonl','a') as f:f.write(json.dumps(rec)+'\n')
            return predicted,valid
        sub.plan=selected_plan

    def _install_feedback_audit(self):
        original_eval=self.evaluator.eval_actions
        def capture(actions,action_len=None,filename='output',save_video=False):
            result=original_eval(actions,action_len,filename,save_video)
            metrics,success,obs,states=result
            normal=actions.detach().cpu().numpy()
            physical=self.data_preprocessor.denormalize_actions(rearrange(actions.detach().cpu(),'b t (f d) -> b (t f) d',f=5)).numpy()
            count=len(physical[0]);self.simulator_action_evaluations+=count
            assert np.isfinite(states).all() and np.isfinite(normal).all()
            if filename.startswith('plan'):
                number=len(self.mpc_records)+1
                assert count==number*5 and count<=150 and number==len(self.optimization_records)
                if self.last_feedback is not None:
                    old=self.last_feedback
                    assert np.array_equal(states[:,:old['states'].shape[1]],old['states'])
                    assert np.array_equal(obs['visual'][:,:old['visual'].shape[1]],old['visual'])
                folder=Path('mpc')/f'{number:03d}';folder.mkdir(parents=True,exist_ok=True)
                Image.fromarray(obs['visual'][0,-1]).save(folder/'observation.png')
                np.savez_compressed(folder/'trajectory.npz',states=states[0],normalized_actions=normal[0],
                                    environment_actions=physical[0],feedback_state=states[0,-1])
                goal=self.state_g[0];cur=states[0,-1]
                position=float(np.linalg.norm(goal[:4]-cur[:4]));angle=float(abs((goal[4]-cur[4]+np.pi)%(2*np.pi)-np.pi))
                rec=dict(replan=number,environment_seed=3101,new_environment_actions=5,
                    cumulative_environment_actions=count,model_action_slots=len(normal[0]),success=bool(success[0]),
                    position_distance=position,angle_distance_rad=angle,state=cur.tolist(),
                    frame=str(folder/'observation.png'),trajectory=str(folder/'trajectory.npz'),
                    raw_frame_sha256=array_hash(obs['visual'][0,-1]),source='Direct original evaluator simulator feedback; cumulative prefix replay',
                    feedback_noise_applied=False,optimizer_call=number)
                self.mpc_records.append(rec)
                with open('mpc_records.jsonl','a') as f:f.write(json.dumps(rec)+'\n')
                self.last_feedback=dict(states=states.copy(),visual=obs['visual'].copy(),normalized_actions=normal.copy(),physical_actions=physical.copy())
            elif filename=='output_final':
                assert self.last_feedback is not None
                assert np.array_equal(states,self.last_feedback['states'])
                assert np.array_equal(obs['visual'],self.last_feedback['visual'])
                self.final_replay=dict(matches_last_feedback=True,success=bool(success[0]),environment_actions=count)
            return result
        self.evaluator.eval_actions=capture

    def perform_planning(self):
        started=time.perf_counter()
        result=super().perform_planning()
        elapsed=time.perf_counter()-started
        after=original.weights_hash(self.wm)
        assert after==self.before and not any(p.grad is not None for p in self.wm.parameters())
        count=len(self.mpc_records);assert 1<=count<=30 and count==len(self.optimization_records)
        assert not any(r['success'] for r in self.mpc_records[:-1])
        success=self.mpc_records[-1]['success'];physical_steps=count*5
        assert success or count==30
        with np.load('final_eval_results.npz') as final:
            assert final['successes'].shape==(1,) and bool(final['successes'][0])==success
            assert final['actions'].shape==(1,count,10)
            length=float(final['action_len'][0])
            assert length==count if success else np.isinf(length)
            assert np.array_equal(final['actions'],self.last_feedback['normalized_actions'])
        frames=self.last_feedback['visual'][0];states=self.last_feedback['states'][0]
        folder=Path('frames');folder.mkdir(exist_ok=True)
        for step,frame in enumerate(frames):Image.fromarray(frame).save(folder/f'env_step_{step:03d}.png')
        Image.fromarray(frames[-1]).save('final.png')
        np.savez_compressed('trajectory.npz',visual=frames,states=states,
            normalized_actions=self.last_feedback['normalized_actions'][0],environment_actions=self.last_feedback['physical_actions'][0],
            initial=self.state_0[0],goal=self.state_g[0],mpc_boundary_steps=np.arange(0,physical_steps+1,5))
        versions={}
        for package in ['torch','torchvision','numpy','hydra-core','omegaconf','gym','pygame','pymunk','opencv-python','einops','Pillow']:
            try:versions[package]=importlib.metadata.version(package)
            except importlib.metadata.PackageNotFoundError:versions[package]=None
        write_json('environment.json',dict(python=sys.version,python_executable=sys.executable,platform=platform.platform(),
            packages=versions,torch_cuda=torch.version.cuda,cudnn=torch.backends.cudnn.version(),
            device=torch.cuda.get_device_name(),CUDA_VISIBLE_DEVICES=os.environ.get('CUDA_VISIBLE_DEVICES')))
        receipt=json.loads((PLAN/'source_receipt.json').read_text())
        summary=dict(task='Figure 3 red_object DINO-WM GD singleton rerun',success=success,
            original_sample_index_zero_based=31,mixed14_sample_index_zero_based=30,original_batch_size=50,
            seed=100,environment_seed=3101,goal_replay_seed=3101,feedback_environment_seeds=[3101]*count,
            stochastic_corruption=None,observation_noise_seed_calls=[],
            actual_mpc_replans=count,environment_steps=physical_steps,max_replans=30,max_environment_steps=150,
            environment_actions_per_replan=5,horizon_environment_actions=25,horizon_model_slots=5,
            gd_opt_steps=100,gd_lr=.1,action_optimizer='adam',cosine_scheduler=True,action_noise=0,cuda_graph=False,
            model_epoch=3,model_frozen=True,model_parameter_updates=0,
            before_model_sha256=self.before,after_model_sha256=after,
            checkpoint_sha256=receipt['checkpoint_sha256'],checkpoint=receipt['checkpoint'],
            target_pair_float32_sha256=json.loads(Path('target_check.json').read_text())['target_pair_float32_sha256'],
            action_len_units='model-action slots; each slot = 5 primitive environment actions',
            action_len_value=int(length) if success else 'inf',
            termination_reason='success_at_mpc_feedback' if success else 'maximum_30_replans_reached',
            first_success_replan=count if success else None,first_success_environment_step=physical_steps if success else None,
            final_position_distance=self.mpc_records[-1]['position_distance'],final_angle_distance_rad=self.mpc_records[-1]['angle_distance_rad'],
            final_state=states[-1].tolist(),elapsed_planning_seconds=elapsed,
            final_audit_replay=self.final_replay,
            simulator_action_evaluations_including_prefix_replays=self.simulator_action_evaluations,
            replay_budget_note='The unchanged original evaluator resets and replays cumulative prefixes to reproduce each feedback; the new action trajectory has at most 150 primitive actions. Extra prefix/final audit replay computations are not new MPC actions.',
            images_origin='Unmodified original simulator renders from actual new MPC feedback; full frames saved from final audited replay which matches last feedback pixel-for-pixel',
            evidence=dict(final_results='final_eval_results.npz',frames='frames/',per_mpc='mpc/',trajectory='trajectory.npz',
                config='resolved_config.yaml',launch='launch_command.json',target_check='target_check.json',
                weights_check='frozen_weights_check.json',optimization='optimization_audit.jsonl',feedback='mpc_records.jsonl',
                log='console.log',environment='environment.json'),
            attempt=1,additional_planning_attempts=0)
        write_json('summary.json',summary)
        print('QUALITATIVE_RESULT',json.dumps(summary),flush=True)
        return result


original.plan.PlanWorkspace=QualitativeWorkspace


@hydra.main(config_path='conf',config_name='qualitative',version_base='1.1')
def main(cfg):
    with open_dict(cfg):cfg['saved_folder']=str(Path.cwd())
    OmegaConf.save(cfg,'resolved_config.yaml',resolve=True)
    write_json('launch_command.json',[sys.executable,*sys.argv])
    original.plan.planning_main(original.plan.cfg_to_dict(cfg))


if __name__=='__main__':main()
