"""Run the authorized singleton exactly once on an idle GPU, preserving every attempt."""
from datetime import datetime,timezone
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

PLAN=Path(__file__).resolve().parent
OUTPUT=PLAN.parents[1]/'CL-JEPA-cudagraph/eval_outputs/qualitative/dinowm_red_object_idx31_gd_30mpc_20261109'
PYTHON='/data/zjc/envs/cljepa/bin/python'


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--attempt',type=int,default=1)
    args=parser.parse_args()
    with (PLAN/'execution.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        execute(args.attempt)


def execute(attempt_number):
    if attempt_number==1 and OUTPUT.exists():raise FileExistsError('Inspect previous attempts before another run')
    if attempt_number>1:
        for previous in range(1,attempt_number):
            old=OUTPUT/f'attempt_{previous:02d}'
            assert old.exists() and not (old/'summary.json').exists()
            assert not (old/'optimization_audit.jsonl').exists(), 'Do not rerun completed or partially planned samples automatically'
    OUTPUT.mkdir(parents=True,exist_ok=attempt_number>1)
    status=dict(status='waiting_for_idle_gpu',pid=os.getpid(),requested_episodes=1,original_index=31,
                started_at=datetime.now(timezone.utc).isoformat(),output=str(OUTPUT))
    def save(**items):
        status.update(items,updated_at=datetime.now(timezone.utc).isoformat())
        tmp=PLAN/'execution.tmp';tmp.write_text(json.dumps(status,indent=2)+'\n');tmp.replace(PLAN/'execution.json')
    save()
    try:
        while True:
            mapping=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid','--format=csv,noheader'],text=True).splitlines()
            active=set(subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid','--format=csv,noheader'],text=True).splitlines())
            free=[line.split(',')[0].strip() for line in mapping if line.split(',')[1].strip() not in active]
            if free:gpu=free[0];break
            save(status='waiting_for_idle_gpu');time.sleep(10)
        receipt=json.loads((PLAN/'source_receipt.json').read_text())
        assert hashlib.sha256(Path(receipt['checkpoint']).read_bytes()).hexdigest()==receipt['checkpoint_sha256']
        assert json.loads((PLAN/'target_validation/target_check.json').read_text())['status']=='passed_before_model_planning'
        for path,sha in json.loads((PLAN/'final_code_receipt.json').read_text()).items():
            assert hashlib.sha256((PLAN/path).read_bytes()).hexdigest()==sha,path
        attempt=OUTPUT/f'attempt_{attempt_number:02d}';attempt.mkdir()
        cmd=[PYTHON,'-u',str(PLAN/'evaluation_dual/qualitative.py'),f'hydra.run.dir={attempt}']
        env={**os.environ,'CUDA_VISIBLE_DEVICES':gpu,'TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD':'1','PYTHONUNBUFFERED':'1',
             'SDL_VIDEODRIVER':'dummy','SDL_AUDIODRIVER':'dummy','OMP_NUM_THREADS':'2','MKL_NUM_THREADS':'2',
             'OPENBLAS_NUM_THREADS':'1','WANDB_MODE':'offline','MPLCONFIGDIR':'/tmp/dinowm_idx31_mpl',
             'RERUN_ATTEMPT':str(attempt_number)}
        (OUTPUT/f'launch_attempt_{attempt_number:02d}.json').write_text(json.dumps(dict(command=cmd,cwd=str(PLAN/'code'),gpu=gpu,
            environment={k:env[k] for k in ['CUDA_VISIBLE_DEVICES','TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD','OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','SDL_VIDEODRIVER']},
            attempt=attempt_number),indent=2)+'\n')
        save(status='running',gpu=gpu,attempt=attempt_number)
        with (attempt/'console.log').open('x') as log:
            proc=subprocess.Popen(cmd,cwd=PLAN/'code',env=env,stdout=log,stderr=subprocess.STDOUT)
            save(active_child_pid=proc.pid)
            rc=proc.wait()
        save(returncode=rc)
        if rc:raise RuntimeError(f'Technical failure rc={rc}; preserved {attempt.name}/console.log')
        summary=json.loads((attempt/'summary.json').read_text())
        save(status='completed',success=summary['success'],actual_replans=summary['actual_mpc_replans'],
             environment_steps=summary['environment_steps'],summary=str(attempt/'summary.json'))
    except Exception as exc:
        save(status='failed',error=repr(exc));raise
    finally:save(ended_at=datetime.now(timezone.utc).isoformat())


if __name__=='__main__':main()
