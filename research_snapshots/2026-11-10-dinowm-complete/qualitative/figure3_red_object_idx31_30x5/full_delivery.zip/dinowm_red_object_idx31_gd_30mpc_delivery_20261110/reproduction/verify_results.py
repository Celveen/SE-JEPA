"""Offline evidence audit; never invokes planning, a model, or the simulator."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path

import numpy as np
from omegaconf import OmegaConf
from PIL import Image

PLAN=Path(__file__).resolve().parent
OUTPUT=PLAN.parents[1]/'CL-JEPA-cudagraph/eval_outputs/qualitative/dinowm_red_object_idx31_gd_30mpc_20261109'


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    execution=json.loads((PLAN/'execution.json').read_text())
    assert execution['status']=='completed' and execution['returncode']==0
    folder=Path(execution['summary']).parent
    s=json.loads((folder/'summary.json').read_text())
    steps=s['actual_mpc_replans'];env_steps=s['environment_steps']
    assert steps<=30 and env_steps==5*steps and env_steps<=150
    assert s['original_sample_index_zero_based']==31 and s['environment_seed']==3101 and s['seed']==100
    weights=json.loads((folder/'frozen_weights_check.json').read_text())
    assert weights['unchanged'] and weights['before_sha256']==weights['after_sha256']==s['before_model_sha256']==s['after_model_sha256']
    expected=json.loads((PLAN/'reference/rerun_30mpc/expected_target.json').read_text())
    checkpoint=Path(s['checkpoint']);assert digest(checkpoint)==s['checkpoint_sha256']
    cfg=OmegaConf.load(folder/'resolved_config.yaml')
    assert cfg.planner.max_iter==30 and cfg.planner.n_taken_actions==5 and cfg.planner.sub_planner.horizon==25
    assert cfg.planner.sub_planner.opt_steps==100 and cfg.planner.sub_planner.lr==.1
    assert cfg.planner.sub_planner.microbatch_size==1 and not cfg.planner.sub_planner.cuda_graph
    assert cfg.objective.mode=='last' and cfg.planner.continual.state_in is None
    assert cfg.env_kwargs_override.color=='Red' and cfg.original_sample_indices==[31]
    rec=[json.loads(x) for x in (folder/'mpc_records.jsonl').read_text().splitlines()]
    optim=[json.loads(x) for x in (folder/'optimization_audit.jsonl').read_text().splitlines()]
    assert len(rec)==len(optim)==steps and sum(x['gd_steps'] for x in optim)==100*steps
    assert all(x['optimized_actions_required_grad'] and not x['model_requires_grad'] for x in optim)
    assert all(np.isfinite(x['first_action_gradient_norm']) and np.isfinite(x['last_action_gradient_norm']) for x in optim)
    assert any(x['first_action_gradient_norm']>0 for x in optim)
    assert [r['cumulative_environment_actions'] for r in rec]==list(range(5,env_steps+1,5))
    assert all(x['environment_seed']==3101 and x['new_environment_actions']==5 for x in rec)
    assert not any(x['success'] for x in rec[:-1])
    assert bool(rec[-1]['success'])==bool(s['success'])
    assert s['success'] or steps==30
    with np.load(folder/'final_eval_results.npz') as result,np.load(folder/'trajectory.npz') as trajectory:
        actions=result['actions'];states=trajectory['states'];frames=trajectory['visual'];physical=trajectory['environment_actions']
        assert result['successes'].shape==(1,) and bool(result['successes'][0])==s['success']
        assert actions.shape==(1,steps,10) and np.isfinite(actions).all()
        assert states.shape==(env_steps+1,7) and frames.shape[0]==env_steps+1 and physical.shape==(env_steps,2)
        initial=np.asarray(expected['state_0'],np.float32);goal=np.asarray(expected['state_g'],np.float32)
        assert np.array_equal(result['state_0'][0],initial) and np.array_equal(result['state_g'][0],goal)
        pair=hashlib.sha256(initial.tobytes()+goal.tobytes()).hexdigest();assert pair==expected['target_pair_float32_sha256']
        assert np.array_equal(trajectory['normalized_actions'],actions[0]) and np.array_equal(states[0],initial)
        mean=np.array([-.0087,.0068],np.float32);std=np.array([.2019,.2002],np.float32)
        assert np.array_equal(physical,actions[0].reshape(-1,2)*std+mean)
        assert len(list((folder/'frames').glob('env_step_*.png')))==env_steps+1
        for i,frame in enumerate(frames):assert np.array_equal(np.asarray(Image.open(folder/'frames'/f'env_step_{i:03d}.png')),frame)
        for i,r in enumerate(rec,1):
            end=i*5
            assert np.array_equal(np.asarray(r['state'],np.float32),states[end])
            assert np.array_equal(np.asarray(Image.open(folder/r['frame'])),frames[end])
            with np.load(folder/r['trajectory']) as trace:
                assert np.array_equal(trace['states'],states[:end+1])
                assert np.array_equal(trace['normalized_actions'],actions[0,:i])
                assert np.array_equal(trace['environment_actions'],physical[:end])
            pos=float(np.linalg.norm(goal[:4]-states[end,:4]));angle=float(abs((goal[4]-states[end,4]+np.pi)%(2*np.pi)-np.pi))
            assert r['success']==bool(pos<20 and angle<np.pi/9)
        assert np.array_equal(np.asarray(Image.open(folder/'final.png')),frames[-1])
        assert np.array_equal(np.asarray(Image.open(folder/'start.png')),frames[0])
        with np.load(PLAN/'reference/raw/dinowm/final_eval_results.npz') as original:
            first_action_same=bool(np.array_equal(actions[0,0],original['actions'][31,0]))
        pos=float(np.linalg.norm(goal[:4]-states[-1,:4]));angle=float(abs((goal[4]-states[-1,4]+np.pi)%(2*np.pi)-np.pi))
        assert s['success']==bool(pos<20 and angle<np.pi/9)
    logs=[json.loads(x) for x in (folder/'logs.json').read_text().splitlines() if x.strip()]
    mpc_logs=[x for x in logs if 'mpc/success_rate' in x]
    final_logs=[x for x in logs if 'final_eval/success_rate' in x]
    assert len(mpc_logs)==steps and len(final_logs)==1
    assert final_logs[0]['final_eval/success_rate']==float(s['success'])
    assert not (OUTPUT/'attempt_01/optimization_audit.jsonl').exists()
    report=dict(status='passed',checked_at=datetime.now(timezone.utc).isoformat(),
        result_attempt=folder.name,technical_attempts_total=2,attempts_with_actual_planning=1,
        success=s['success'],actual_mpc_replans=steps,environment_steps=env_steps,
        gd_optimizer_updates=steps*100,raw_simulator_frames=env_steps+1,per_mpc_pngs=steps,
        exact_original_target_pair=True,seed_mapping_preserved=True,model_weights_buffers_unchanged=True,
        action_gradients_finite=True,model_parameter_gradients_disabled=True,
        raw_frame_files_match_trajectory=True,cumulative_prefix_states_and_pixels_match=True,
        final_success_recomputed=True,first_executed_model_slot_bitwise_matches_original_6mpc_run=first_action_same,
        action_len_units=s['action_len_units'],checkpoint_sha256=s['checkpoint_sha256'],
        final_position_distance=pos,final_angle_distance_rad=angle,
        note='No planning or simulation was performed by this offline verification.')
    (OUTPUT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
