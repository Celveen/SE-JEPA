"""Replay only the fixed reference actions to validate the selected target before planning."""
import hashlib
import json
import os
import pickle
from pathlib import Path
import sys

PLAN=Path(__file__).resolve().parent
sys.path.insert(0,str(PLAN/'code'))
os.environ.setdefault('SDL_VIDEODRIVER','dummy')
os.environ.setdefault('SDL_AUDIODRIVER','dummy')
import numpy as np
from PIL import Image
from env.pusht.pusht_wrapper import PushTWrapper


def main():
    data=pickle.loads((PLAN/'targets_idx31.pkl').read_bytes());seg=data['segments'][0]
    expected=json.loads((PLAN/'reference/rerun_30mpc/expected_target.json').read_text())
    base=int(expected['original_batch_seed']);index=int(expected['original_sample_index_zero_based']);env_seed=base*index+1
    initial=np.zeros(7,dtype=np.float32);initial[:5]=seg['states'][0]
    actions=np.asarray(seg['actions'],dtype=np.float32)/100.
    env=PushTWrapper(with_velocity=True,with_target=True,color='Red')
    env.update_env({'shape':seg['shape'],'color':'Red'})
    obs,states=env.rollout(env_seed,initial,actions)
    orig=pickle.loads((PLAN/'reference/raw/dinowm/plan_targets.pkl').read_bytes())
    assert np.array_equal(initial,np.asarray(expected['state_0'],np.float32))
    assert np.array_equal(states[-1],np.asarray(expected['state_g'],np.float32))
    assert np.array_equal(initial,orig['state_0'][index]) and np.array_equal(states[-1],orig['state_g'][index])
    assert np.array_equal(obs['visual'][0],orig['obs_0']['visual'][index,0])
    assert np.array_equal(obs['visual'][-1],orig['obs_g']['visual'][index,0])
    folder=PLAN/'target_validation';folder.mkdir(exist_ok=True)
    Image.fromarray(obs['visual'][0]).save(folder/'start.png')
    Image.fromarray(obs['visual'][-1]).save(folder/'goal_model_input.png')
    # The paper's goal PNG is a static illustration, not the replay observation.
    static=states[-1].copy();static[5:]=0
    goal_obs,goal_state=env.prepare(env_seed,static)
    assert np.array_equal(goal_state[:5],states[-1,:5])
    Image.fromarray(goal_obs['visual']).save(folder/'goal_static.png')
    paper_start=np.asarray(Image.open(PLAN/'reference/frames/dinowm/start.png'))
    paper_goal=np.asarray(Image.open(PLAN/'reference/frames/dinowm/goal.png'))
    assert np.array_equal(obs['visual'][0],paper_start)
    assert np.array_equal(goal_obs['visual'],paper_goal)
    pair_hash=hashlib.sha256(initial.tobytes()+states[-1].tobytes()).hexdigest()
    assert pair_hash==expected['target_pair_float32_sha256']
    report=dict(status='passed_before_model_planning',original_sample_index=31,batch_seed=base,environment_seed=env_seed,
        traj_len=data['traj_len'],shape=seg['shape'],source_episode=seg['ep_idx'],source_offset=seg['offset'],
        exact_state_0=True,exact_state_g=True,target_pair_float32_sha256=pair_hash,
        model_start_pixels_match_original=True,model_goal_pixels_match_original=True,
        start_pixels_match_paper=True,static_goal_pixels_match_paper=True,
        replay_goal_equals_paper_static_goal=bool(np.array_equal(obs['visual'][-1],paper_goal)),
        goal_image_note='goal_model_input is the original reference-action replay observation; goal_static is paper-compatible zero-velocity rendering. Planning uses the original replay observation and unmodified goal state.')
    (folder/'target_check.json').write_text(json.dumps(report,indent=2)+'\n');env.close()
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
