"""Package verified qualitative results, every attempt, and reproducibility evidence."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

from PIL import Image,ImageDraw

PLAN=Path(__file__).resolve().parent
OUTPUT=PLAN.parents[1]/'CL-JEPA-cudagraph/eval_outputs/qualitative/dinowm_red_object_idx31_gd_30mpc_20261109'


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    audit=json.loads((OUTPUT/'verification.json').read_text());assert audit['status']=='passed'
    attempt=OUTPUT/audit['result_attempt'];s=json.loads((attempt/'summary.json').read_text())
    delivery=PLAN.parents[1]/'exports/dinowm_red_object_idx31_gd_30mpc_delivery_20261110'
    if delivery.exists() or delivery.with_suffix('.zip').exists():raise FileExistsError('Delivery already exists; inspect rather than overwrite')
    delivery.mkdir(parents=True)
    shutil.copytree(OUTPUT,delivery/'results',ignore=shutil.ignore_patterns('*.lock','__pycache__','*.pyc'))
    source=delivery/'reproduction';source.mkdir()
    for folder in ['code','evaluation_dual','reference','target_validation']:
        shutil.copytree(PLAN/folder,source/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    for f in PLAN.iterdir():
        if f.is_file() and f.suffix in ('.json','.py','.patch','.pkl','.log'):
            shutil.copy2(f,source/f.name)
    outcome='成功' if s['success'] else '失败（达到最大预算，未触发成功判据）'
    text=f'''# Figure 3 red_object：DINO-WM + GD，30 次 MPC 单样本重跑

实际结果：**{outcome}**。

- 原 DINO-WM 批次零基索引 **31**（mixed14 索引 30）。
- base seed=100，原映射保留为 environment/target seed=3101。
- 原始 epoch 3 DINO-WM，52,319,499 参数，模型参数和 buffers 冻结；只优化动作。
- 保留 last、GD lr=0.1、100 步、Adam+cosine、zero 初值、action_noise=0、microbatch=1、cuda_graph=false、reuse_actions=true。
- 预测 horizon=25 个环境动作（5 个模型动作块），每次执行 5 个环境动作（1 个模型动作块）。
- 实际完成 **{s['actual_mpc_replans']} 次 MPC / {s['environment_steps']} 个环境动作**；最大预算 30×5=150。
- 终止原因：`{s['termination_reason']}`。
- 最终位置判据距离：{s['final_position_distance']:.6f}（要求 <20）；角度距离：{s['final_angle_distance_rad']:.6f} rad（要求 <π/9 ≈0.349066）。位置距离按原实现计算 agent 与物体四个平面坐标，不修改判据。

## 论文端使用

正式结果位于 `results/{attempt.name}/`：

- `start.png`、`goal.png`、`final.png`：原始 224×224 模拟器图片，未裁剪、未生成或修改像素。
- `mpc/001..{s['actual_mpc_replans']:03d}/observation.png`：每次真实 MPC 反馈后的原始图片；同目录 `trajectory.npz` 保存当次状态与动作前缀。
- `frames/env_step_000.png` 至 `env_step_{s['environment_steps']:03d}.png`：全部物理步的原始图片。
- `trajectory.npz`：完整状态/图像轨迹、归一化模型动作、反归一化环境动作、MPC 边界。
- `final_eval_results.npz`：保持原结构（successes/actions/action_len/state_0/state_g），仅包含本样本。`action_len` 单位是模型动作块，每块 5 个物理动作；失败保留 inf，实际执行次数另见 summary。
- `summary.json`、`mpc_records.jsonl`、`optimization_audit.jsonl`：真实重规划次数、梯度、seed/RNG 和终止证据。
- `resolved_config.yaml`、`launch_command.json`、`environment.json`、`console.log`：实际配置、命令、依赖和完整日志。
- `target_check.json`、`frozen_weights_check.json`，以及根部 `results/verification.json`：目标逐元素/逐像素匹配、运行前后模型哈希和独立离线验收。

`preview_start_final_goal.png` 仅把原始图片并排放置并在图外标记 Start/Final/Goal，供预览；论文建议读取单独原图。主表和既有批次成功率未修改，论文分支也未覆盖。

## 尝试记录

`results/attempt_01/` 为技术启动失败：旧 cfg_to_dict 把原样本索引整数列表当作字符串列表拼接，模型加载/规划前即退出；无优化、反馈或新动作。

`results/{attempt.name}/` 为修复包装层类型转换后的唯一实际规划尝试。目标、权重、seed 和参数未变；没有搜索种子、挑选结果或续接旧轨迹。第一次失败的日志、原包装代码和原因均已保留。

## 代码和来源

任务说明与论文原资产来自 `codex/paper-revision-2026-11-05` 提交 `398428a76b93fe3c29d2d75a3746d3bfdf9d10dc`；原结果来源 commit 为 `d4f6cb491ac19d0224485b056fe5b24aa8e50f94`。

`reproduction/` 包含独立评测副本、原模型/规划/模拟器代码、源目标31、原配置、代码哈希及 `code_changes.patch`。原 MPC/GD/微批次/成功判据实现未改；独立 plan.py 仅支持原索引种子映射，evaluate.py 审计仅允许这个精确单例，qualitative.py 负责记录。

原 GD 的每个微批次都会在 action_noise=0 时消耗噪声随机数。包装器保留样本31前后其他样本的零幅噪声 draw 数量（每次重规划前31×100次、后18×100次），但不优化其他样本；没有新增每episode torch seed。red_object 没有图像噪声变换，因此不调用反馈噪声 RNG。

原评估器为了重建物理反馈，会重放累计动作前缀，并在最终再审计回放一次。本包如实保留该行为，所有前缀状态/像素均经一致性检查；30×5=150 指新生成并构成该闭环轨迹的动作预算，不把重复前缀计算误记为额外的新动作。累计内部仿真动作调用数为 {s['simulator_action_evaluations_including_prefix_replays']}，另与环境交互预算分开记录。

## 权重

模型文件未重复放进包，原路径和训练配置在 `reproduction/source_receipt.json` 与 `reproduction/reference/checkpoint_training_config.yaml`。

checkpoint SHA256：`{s['checkpoint_sha256']}`。

模型参数及 buffers 运行前后 SHA256：`{s['before_model_sha256']}`，与原批次冻结审计一致。

目标 state_0+state_g float32 SHA256：`{s['target_pair_float32_sha256']}`。

复核：解压后执行 `sha256sum -c SHA256SUMS`。离线验证脚本 `reproduction/verify_results.py` 的原服务器路径记录在其头部；迁移到其他目录时仅调整本地资料根路径。禁止用验证脚本触发额外模型规划，它只读现有结果。
'''
    (delivery/'README.md').write_text(text)
    panels=[Image.open(attempt/f'{name}.png').convert('RGB') for name in ['start','final','goal']]
    preview=Image.new('RGB',(224*3,252),'white');draw=ImageDraw.Draw(preview)
    for i,(panel,label) in enumerate(zip(panels,['Start','Final','Goal'])):
        preview.paste(panel,(224*i,28));draw.text((224*i+90,8),label,fill='black')
    preview.save(delivery/'preview_start_final_goal.png')
    manifest=dict(status='verified_delivery',created_at=datetime.now(timezone.utc).isoformat(),
        result_attempt=attempt.name,summary='results/'+attempt.name+'/summary.json',
        success=s['success'],mpc_replans=s['actual_mpc_replans'],environment_steps=s['environment_steps'],
        checkpoint_sha256=s['checkpoint_sha256'],source_branch_commit='398428a76b93fe3c29d2d75a3746d3bfdf9d10dc',
        technical_attempts=2,attempts_with_model_planning=1,verification='results/verification.json',
        no_main_table_changes=True,no_paper_branch_changes=True)
    (delivery/'delivery_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    files=sorted(f for f in delivery.rglob('*') if f.is_file())
    (delivery/'SHA256SUMS').write_text('\n'.join(sha(f)+'  '+f.relative_to(delivery).as_posix() for f in files)+'\n')
    archive=delivery.with_suffix('.zip')
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in sorted(delivery.rglob('*')):
            if f.is_file():z.write(f,arcname=delivery.name+'/'+f.relative_to(delivery).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for f in sorted(delivery.rglob('*')):
            if f.is_file():assert hashlib.sha256(z.read(delivery.name+'/'+f.relative_to(delivery).as_posix())).hexdigest()==sha(f)
    receipt=dict(**manifest,package_directory=str(delivery),archive=str(archive),archive_bytes=archive.stat().st_size,
                 archive_sha256=sha(archive),all_archive_files_hash_verified=True)
    (PLAN/'delivery_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))


if __name__=='__main__':main()
