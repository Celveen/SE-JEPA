# SE-JEPA — 精简完整 Overleaf 源码包

## 上传与编译

在 Overleaf 首页选择 New Project → Upload Project，上传本压缩包。
主文件选择根目录的 `main.tex`，编译器选择 **pdfLaTeX**。
文件已放在压缩包根目录，保留 `sec/`、`tables/` 和 `figures/` 的结构即可。
无需运行 Python、转换 SVG 或开启 shell escape。

`main.tex` 包含正文、参考文献及附录 A–E。
当前版本正文 8 页，整篇 21 页。

## 保留的文件

- `main.tex`、`preamble.tex`：论文入口与公共设置。
- `sec/`：全部正文和附录章节。
- `tables/`：实际引用的表格源码。
- `figures/`：正文和附录实际引用的 15 张 PDF 插图。
- `references.bib`：参考文献库。
- `cvpr.sty`、`ieeenat_fullname.bst`、`.latexmkrc`：模板与编译设置。
- `supplement.tex`：单独附录入口，使用 `xr-hyper` 引用正文标签，
  需要先生成并提供 `main.aux`。通常直接编译 `main.tex` 即可查看全部附录。

## 本地编译

```sh
latexmk -pdf main.tex
latexmk -pdf supplement.tex
```

## 研究资料与绘图源文件

本包是完整的论文编译源码；原始实验数据、结果审计、PNG 预览、SVG 编辑稿、
旧图和绘图脚本不参与 LaTeX 编译，因此未放入本包。
全部研究资料与图表生成工具保留在下列 GitHub 版本中：

https://github.com/Celveen/SE-JEPA/tree/codex/paper-revision-2026-11-05/paper/SE_JEPA_CVPR2027_Overleaf

当前版本包含单列上下排列的图 7、十四域混合学习曲线与两张结果表。
附录保留四张原版参考运行图及另外两个变形物体案例，并补齐曲线与案例文字解释。
压缩包仅保留编译需要的文件；原始数据与图表来源记录保存在研究源码中。

主表 SE-JEPA 的 PushObj CEM 已使用第五轮在线结果：80.4% / 73.1% / 12.99 次重规划。
正文和表注已区分在线结果与附录中的配对测试。
