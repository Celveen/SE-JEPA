# SE-JEPA — 精简完整 Overleaf 源码包

## 上传与编译

在 Overleaf 首页选择 New Project → Upload Project，上传本压缩包。
主文件选择根目录的 `main.tex`，编译器选择 **pdfLaTeX**。
文件已放在压缩包根目录，保留 `sec/`、`tables/` 和 `figures/` 的结构即可。
无需运行 Python、转换 SVG 或开启 shell escape。

`main.tex` 包含正文、参考文献及附录 A–E。
当前版本正文 8 页，整篇 19 页。

## 保留的文件

- `main.tex`、`preamble.tex`：论文入口与公共设置。
- `sec/`：全部正文和附录章节。
- `tables/`：实际引用的表格源码。
- `figures/`：正文和附录实际引用的 13 张 PDF 插图。
- `references.bib`：参考文献库。
- `cvpr.sty`、`ieeenat_fullname.bst`、`.latexmkrc`：模板与编译设置。
- `supplement.tex`：单独附录入口，使用 `xr-hyper` 引用正文标签，
  需要先生成并提供 `main.aux`。通常直接编译 `main.tex` 即可查看全部附录。

## 本地编译

```sh
latexmk -pdf main.tex
latexmk -pdf supplement.tex
```

## 研究资料与绘图源文件

本包是完整的论文编译源码；原始实验数据、结果审计、PNG 预览、SVG 编辑稿、
旧图和绘图脚本不参与 LaTeX 编译，因此未放入本包。
全部研究资料与图表生成工具保留在下列 GitHub 版本中：

https://github.com/Celveen/SE-JEPA/tree/codex/paper-revision-2026-11-05/paper/SE_JEPA_CVPR2027_Overleaf

当前版本保留单列上下排列的图 7。十四域实验已提升到正文第 4.5 节（第 7 页），
图 8（第 8 页）展示整体、形状、视觉的五轮学习曲线，三种方法统一取 GD/CEM 平均；
AdaJEPA 和 Frozen 使用已有评测的水平参考线，详细结果表与协议保留在附录 D。
附录保留四张原版参考运行图及曲线与案例文字解释；已移除末尾图 13 的两个额外变形物体案例。
压缩包仅保留编译需要的文件；原始数据与图表来源记录保存在研究源码中。

主表 SE-JEPA 的 PushObj CEM 已使用第五轮在线结果：80.4% / 73.1% / 12.99 次重规划。
正文和表注已区分在线结果与附录中的配对测试。

图 3 已缩小，两行均包含 DINO-WM，且各行的四种方法使用相同起始和目标。
上行为 I 形状测试，下行为十四域混合流的红色物体案例；统一标实际 MPC 重规划次数。
视觉 DINO-WM 为 6 次失败，其余基线为 30 次失败，SE-JEPA 两例均为 6 次成功；图注说明每次执行动作数的差异。
图内 Goal 说明已去掉。原始动作回放与来源验证记录保存在研究源码包中。

图 3 的 DINO-WM 视觉样本正等待服务器进行真实的 30 次 MPC 重规划评测；
收到结果前保留原来的 6 次记录，不延长旧轨迹或预填重跑结果。
