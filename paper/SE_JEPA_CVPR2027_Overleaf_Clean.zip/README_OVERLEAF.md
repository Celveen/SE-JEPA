# SE-JEPA — 精简完整 Overleaf 源码包

## 当前版本

正文为 8 页，参考文献及 LLM 声明 2 页，附录 11 页，合并 PDF 共 21 页。
第七页第 4.5 节和表 2 新增 rope/granular 混合域结果，包含三轮 CD、
存入记忆的领域成员纯度和慢预测器检索准确率。图 7 保留单列上下排列，
压缩纵向留白；附录 D.6 和表 13 保留完整实验协议、成功率和检索计数。
正文与附录全部 127 处段末、42 条参考文献末行通过 40% 宽度检查；
正文第八页末尾空白约 2.43 行。CVPR 模板、字号和页边距保持不变。

摘要使用作者确认的 “we propose SE-JEPA” 精简版，保留导师的代码公开说明。
原始预训练权重固定不变，慢记忆由独立预测器学习。图 2 保留作者调整过的
字体、颜色和位置，并包含真实 rope/granular 仿真图。最新实验与基线数据
已整理入表；附录保留真实运行轨迹和文字解释。

## 上传与编译

在 Overleaf 首页选择 New Project → Upload Project，上传此压缩包。
主文件为根目录的 `main.tex`，编译器选择 **pdfLaTeX**。
无需运行绘图工具、转换 SVG 或开启 shell escape。
本包为本地最新版本，尚未自动回写已有 Overleaf 在线项目。

`main.tex` 包含完整正文、参考文献和附录 A–E。
`supplement.tex` 可单独生成 12 页附录，需要先编译正文并提供 `main.aux`。
本地也可依次运行 `latexmk -pdf main.tex` 与 `latexmk -pdf supplement.tex`。
本地预览以 Tectonic / XeTeX 验证；Overleaf 的 pdfLaTeX 换行可能略有差异。

## 文件范围

本包共 50 个文件，仅包含论文编译依赖和本说明：LaTeX 章节、实际引用的
表格与 PDF 插图、参考文献库及官方 CVPR 模板。
原始实验数据、历史素材、PNG 预览、可编辑 SVG 和绘图工具仅保留在完整研究源码包，
不占用本精简上传包。

研究源码：
https://github.com/Celveen/SE-JEPA/tree/codex/paper-revision-2026-11-05/paper/SE_JEPA_CVPR2027_Overleaf
