# SE-JEPA — 精简完整 Overleaf 源码包

## 上传与编译

在 Overleaf 首页选择 New Project → Upload Project，上传本压缩包。
主文件选择根目录的 `main.tex`，编译器选择 **pdfLaTeX**。
文件已放在压缩包根目录，保留 `sec/`、`tables/` 和 `figures/` 的结构即可。
无需运行 Python、转换 SVG 或开启 shell escape。

`main.tex` 包含正文、参考文献及附录 A–E。
当前版本正文 8 页，整篇 20 页。

## 保留的文件

- `main.tex`、`preamble.tex`：论文入口与公共设置。
- `sec/`：全部正文和附录章节。
- `tables/`：实际引用的表格源码。
- `figures/`：正文和附录实际引用的 13 张 PDF 插图。
- `references.bib`：参考文献库。
- `cvpr.sty`、`ieeenat_fullname.bst`、`.latexmkrc`：模板与编译设置。
- `supplement.tex`：单独附录入口，使用 `xr-hyper` 引用正文标签，
  需要先生成并提供 `main.aux`。通常直接编译 `main.tex` 即可查看全部附录。

## 本地编译

```sh
latexmk -pdf main.tex
latexmk -pdf supplement.tex
```

## 研究资料与绘图源文件

本包是完整的论文编译源码；原始实验数据、结果审计、PNG 预览、SVG 编辑稿、
旧图和绘图脚本不参与 LaTeX 编译，因此未放入本包。
全部研究资料与图表生成工具保留在下列 GitHub 版本中：

https://github.com/Celveen/SE-JEPA/tree/codex/paper-revision-2026-11-05/paper/SE_JEPA_CVPR2027_Overleaf

当前版本保留单列上下排列的图 7。十四域实验已提升到正文第 4.5 节（第 7 页），
图 8（第 8 页）展示整体、形状、视觉的五轮学习曲线，三种方法统一取 GD/CEM 平均；
AdaJEPA 和 Frozen 使用已有评测的水平参考线，详细结果表与协议保留在附录 D。
附录保留四张原版参考运行图及曲线与案例文字解释；已移除末尾图 13 的两个额外变形物体案例。
压缩包仅保留编译需要的文件；原始数据与图表来源记录保存在研究源码中。

主表 SE-JEPA 的 PushObj CEM 已使用第五轮在线结果：80.4% / 73.1% / 12.99 次重规划。
正文和表注已区分在线结果与附录中的配对测试。

图 3 使用服务器真实重跑的 DINO-WM 视觉样本，30 次 MPC 后失败；
两行的四种方法仍使用相同起点和目标，SE-JEPA 均在 6 次 MPC 后成功。
图 8 的 14 个域真实观察小图已排到三个学习曲线面板下方。

主表仅更新 DINO-WM 的 PushT CEM：Shift 33.0%、Color 37.3%、Steps 22.05，
使用新随机数据训练的 epoch 3 权重；PushObj 数据保持不变。
基线与相关工作介绍已压缩，只保留必要的来源、引用及协议说明。

摘要已逐字替换为作者最新 abstract1.md，结果数值与现有证据一致。
DINO-WM PushT CEM Steps 按五动作单位等比例换算为 22.05，附录 B 简要说明。


新增 GD 消融：正文表 3 包含形状链 1 和视觉链 1/2；附录 D 给出完整成功率/MPC 和三链继承对照。新增成熟门控分析和 future work。正文仍为 8 页，末尾约 1.5 行空白，全文 20 页。研究数据与复算工具保存在研究源码包，精简包只含实际编译依赖。
