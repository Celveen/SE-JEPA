import os
import torch
import imageio
import numpy as np
from einops import rearrange, repeat
from utils import (
    cfg_to_dict,
    seed,
    slice_trajdict_with_t,
    aggregate_dct,
    move_to_device,
    concat_trajdict,
)
from torchvision import utils
from planning.image_corruption import corrupt_obs_dict


class PlanEvaluator:  # evaluator for planning
    def __init__(
        self,
        obs_0,
        obs_g,
        state_0,
        state_g,
        env,
        wm,
        frameskip,
        seed,
        preprocessor,
        n_plot_samples,
        decode_for_viz=True,
        ood_corruption=None,
        ood_level=None,
    ):
        self.obs_0 = obs_0
        self.obs_g = obs_g
        self.state_0 = state_0
        self.state_g = state_g
        self.env = env
        self.wm = wm
        self.frameskip = frameskip
        self.seed = seed
        self.preprocessor = preprocessor
        self.n_plot_samples = n_plot_samples
        self.decode_for_viz = bool(decode_for_viz)
        self.ood_corruption = ood_corruption  # e.g. "blur", "snp1", "snp5", "dark", or None
        self.ood_level = ood_level
        self.device = next(wm.parameters()).device

        self.plot_full = False  # plot all frames or frames after frameskip

    def _corrupt(self, obs, seed_offset=0, random_per_call=False):
        """Apply OOD corruption to an observation dict if configured."""
        if random_per_call:
            seed = None  # fresh noise each call
        else:
            base_seed = self.seed[0] if isinstance(self.seed, (list, tuple, np.ndarray)) else self.seed
            seed = int(base_seed) + seed_offset
        return corrupt_obs_dict(obs, self.ood_corruption, self.ood_level, seed=seed)

    def assign_init_cond(self, obs_0, state_0):
        self.obs_0 = obs_0
        self.state_0 = state_0

    def assign_goal_cond(self, obs_g, state_g):
        self.obs_g = obs_g
        self.state_g = state_g

    def get_init_cond(self):
        return self.obs_0, self.state_0

    def _get_trajdict_last(self, dct, length):
        new_dct = {}
        for key, value in dct.items():
            new_dct[key] = self._get_traj_last(value, length)
        return new_dct

    def _get_traj_last(self, traj_data, length):
        last_index = np.where(length == np.inf, -1, length - 1)
        last_index = last_index.astype(int)
        if isinstance(traj_data, torch.Tensor):
            traj_data = traj_data[np.arange(traj_data.shape[0]), last_index].unsqueeze(
                1
            )
        else:
            traj_data = np.expand_dims(
                traj_data[np.arange(traj_data.shape[0]), last_index], axis=1
            )
        return traj_data

    def _mask_traj(self, data, length):
        """
        Zero out everything after specified indices for each trajectory in the tensor.
        data: tensor
        """
        result = data.clone()  # Clone to preserve the original tensor
        for i in range(data.shape[0]):
            if length[i] != np.inf:
                result[i, int(length[i]) :] = 0
        return result

    def eval_actions(
        self, actions, action_len=None, filename="output", save_video=False
    ):
        """
        actions: detached torch tensors on cuda
        Returns
            metrics, and feedback from env
        """
        n_evals = actions.shape[0]
        if action_len is None:
            action_len = np.full(n_evals, np.inf)
        # rollout in wm
        trans_obs_0 = move_to_device(
            self.preprocessor.transform_obs(self.obs_0), self.device
        )
        trans_obs_g = move_to_device(
            self.preprocessor.transform_obs(self.obs_g), self.device
        )
        with torch.no_grad():
            i_z_obses, _ = self.wm.rollout(
                obs_0=trans_obs_0,
                act=actions,
            )
        i_final_z_obs = self._get_trajdict_last(i_z_obses, action_len + 1)

        # rollout in env
        exec_actions = rearrange(
            actions.cpu(), "b t (f d) -> b (t f) d", f=self.frameskip
        )
        exec_actions = self.preprocessor.denormalize_actions(exec_actions).numpy()
        e_obses, e_states = self.env.rollout(self.seed, self.state_0, exec_actions)
        # Intermediate observations get fresh random noise on every MPC iter.
        e_obses = self._corrupt(e_obses, random_per_call=True)
        e_visuals = e_obses["visual"]
        e_final_obs = self._get_trajdict_last(e_obses, action_len * self.frameskip + 1)
        e_final_state = self._get_traj_last(e_states, action_len * self.frameskip + 1)[
            :, 0
        ]  # reduce dim back

        # compute eval metrics
        logs, successes = self._compute_rollout_metrics(
            e_state=e_final_state,
            e_obs=e_final_obs,
            i_z_obs=i_final_z_obs,
        )

        # plot trajs
        if self.decode_for_viz and self.wm.decoder is not None:
            with torch.no_grad():
                i_visuals = self.wm.decode_obs(i_z_obses)[0]["visual"]
            i_visuals = self._mask_traj(
                i_visuals, action_len + 1
            )  # we have action_len + 1 states
            e_visuals = self.preprocessor.transform_obs_visual(e_visuals)
            e_visuals = self._mask_traj(e_visuals, action_len * self.frameskip + 1)
            self._plot_rollout_compare(
                e_visuals=e_visuals,
                i_visuals=i_visuals,
                successes=successes,
                save_video=save_video,
                filename=filename,
            )

        return logs, successes, e_obses, e_states

    def _compute_rollout_metrics(self, e_state, e_obs, i_z_obs):
        """
        Args
            e_state
            e_obs
            i_z_obs
        Return
            logs
            successes
        """
        eval_results = self.env.eval_state(self.state_g, e_state)
        successes = eval_results['success']

        logs = {
            f"success_rate" if key == "success" else f"mean_{key}": np.mean(value) if key != "success" else np.mean(value.astype(float))
            for key, value in eval_results.items()
        }

        print("Success rate: ", logs['success_rate'])
        print(eval_results)

        visual_dists = np.linalg.norm(e_obs["visual"] - self.obs_g["visual"], axis=1)
        mean_visual_dist = np.mean(visual_dists)
        proprio_dists = np.linalg.norm(e_obs["proprio"] - self.obs_g["proprio"], axis=1)
        mean_proprio_dist = np.mean(proprio_dists)

        e_obs = move_to_device(self.preprocessor.transform_obs(e_obs), self.device)
        with torch.no_grad():
            e_z_obs = self.wm.encode_obs(e_obs)
        div_visual_emb = torch.norm(e_z_obs["visual"] - i_z_obs["visual"]).item()
        div_proprio_emb = torch.norm(e_z_obs["proprio"] - i_z_obs["proprio"]).item()

        logs.update({
            "mean_visual_dist": mean_visual_dist,
            "mean_proprio_dist": mean_proprio_dist,
            "mean_div_visual_emb": div_visual_emb,
            "mean_div_proprio_emb": div_proprio_emb,
        })

        return logs, successes

    def _plot_rollout_compare(
        self, e_visuals, i_visuals, successes, save_video=False, filename=""
    ):
        """
        i_visuals may have less frames than e_visuals due to frameskip, so pad accordingly
        e_visuals: (b, t, h, w, c)
        i_visuals: (b, t, h, w, c)
        goal: (b, h, w, c)
        """
        e_visuals = e_visuals[: self.n_plot_samples]
        i_visuals = i_visuals[: self.n_plot_samples]
        goal_visual = self.obs_g["visual"][: self.n_plot_samples]
        goal_visual = self.preprocessor.transform_obs_visual(goal_visual)

        i_visuals = i_visuals.unsqueeze(2)
        i_visuals = torch.cat(
            [i_visuals] + [i_visuals] * (self.frameskip - 1),
            dim=2,
        )  # pad i_visuals (due to frameskip)
        i_visuals = rearrange(i_visuals, "b t n c h w -> b (t n) c h w")
        i_visuals = i_visuals[:, : i_visuals.shape[1] - (self.frameskip - 1)]

        h, w = e_visuals.shape[-2], e_visuals.shape[-1]

        if save_video:
            for idx in range(e_visuals.shape[0]):
                success_tag = "success" if successes[idx] else "failure"
                frames = []
                for i in range(e_visuals.shape[1]):
                    e_obs = torch.cat([e_visuals[idx, i].cpu(), goal_visual[idx, 0]], dim=2)
                    i_obs = torch.cat([i_visuals[idx, i].cpu(), goal_visual[idx, 0]], dim=2)
                    frame = torch.cat([e_obs, i_obs], dim=1)
                    frames.append(rearrange(frame, "c h w -> h w c").detach().cpu().numpy())
                video_writer = imageio.get_writer(
                    f"{filename}_{idx}_{success_tag}.mp4", fps=12
                )
                tags = [
                    ("Simulator", 0, 0),
                    ("Decoder", 0, h),
                    ("Goal", w, 0),
                    ("Goal", w, h),
                ]
                for frame in frames:
                    frame = frame * 2 - 1 if frame.min() >= 0 else frame
                    frame = (((np.clip(frame, -1, 1) + 1) / 2) * 255).astype(np.uint8)
                    video_writer.append_data(self._draw_tags(frame, tags, h))
                video_writer.close()

        # pad i_visuals or subsample e_visuals
        if not self.plot_full:
            e_visuals = e_visuals[:, :: self.frameskip]
            i_visuals = i_visuals[:, :: self.frameskip]

        n_columns = e_visuals.shape[1]
        assert (
            i_visuals.shape[1] == n_columns
        ), f"Rollout lengths do not match, {e_visuals.shape[1]} and {i_visuals.shape[1]}"

        # add a goal column
        e_visuals = torch.cat([e_visuals.cpu(), goal_visual], dim=1)
        i_visuals = torch.cat([i_visuals.cpu(), goal_visual], dim=1)
        rollout = torch.cat([e_visuals.cpu(), i_visuals.cpu()], dim=1)
        n_columns += 1

        imgs_for_plotting = rearrange(rollout, "b h c w1 w2 -> (b h) c w1 w2")
        imgs_for_plotting = (
            imgs_for_plotting * 2 - 1
            if imgs_for_plotting.min() >= 0
            else imgs_for_plotting
        )
        pad = 2  # make_grid default padding
        grid = utils.make_grid(
            imgs_for_plotting, nrow=n_columns, normalize=True, value_range=(-1, 1)
        )
        grid = (grid.mul(255).clamp(0, 255).byte().permute(1, 2, 0).numpy())

        def cell(row, col):  # top-left pixel of a grid cell
            return pad + col * (w + pad), pad + row * (h + pad)

        tags = []
        for s in range(rollout.shape[0]):  # each sample: env row, then decoder row
            tags.append(("Simulator", *cell(2 * s, 0)))
            tags.append(("Decoder", *cell(2 * s + 1, 0)))
            tags.append(("Goal", *cell(2 * s, n_columns - 1)))
            tags.append(("Goal", *cell(2 * s + 1, n_columns - 1)))
        imageio.imwrite(f"{filename}.png", self._draw_tags(grid, tags, h))

    def _draw_tags(self, img, tags, frame_h):
        """Badge-style tags (colored box, white bold text) on a uint8 HWC image.
        tags: list of (text, x, y); box color = self.viz_tag_color (red AdaJEPA / blue frozen)."""
        from PIL import Image, ImageDraw, ImageFont

        color = tuple(getattr(self, "viz_tag_color", (0, 0, 0)))
        size = max(13, frame_h // 13)
        try:
            from matplotlib import font_manager

            font = ImageFont.truetype(
                font_manager.findfont(font_manager.FontProperties(weight="bold")), size
            )
        except Exception:
            font = ImageFont.load_default()
        pil = Image.fromarray(img)
        draw = ImageDraw.Draw(pil)
        pad = max(3, size // 5)
        for text, x, y in tags:
            bb = draw.textbbox((0, 0), text, font=font)
            tw, th = bb[2] - bb[0], bb[3] - bb[1]
            draw.rectangle([x + 4, y + 4, x + 4 + tw + 2 * pad, y + 4 + th + 2 * pad], fill=color)
            draw.text((x + 4 + pad, y + 4 + pad - bb[1]), text, fill=(255, 255, 255), font=font)
        return np.asarray(pil)
