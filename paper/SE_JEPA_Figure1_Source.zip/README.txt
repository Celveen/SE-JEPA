Figure 1: editable SVG, original schematic, chart data and rebuild tools.
The lower GD chart uses the approved data and extends farther left.
The upper schematic is preserved from teaser_before_alignment.pdf.

Requires Python, Matplotlib, NumPy and PyMuPDF.
python plot_teaser.py --data teaser_bars.csv --output-dir .
python combine_teaser.py --template teaser_combined.svg --bars-dir . --output-dir rebuilt --upper-pdf teaser_before_alignment.pdf

The compiled manuscript uses teaser_combined.pdf.
