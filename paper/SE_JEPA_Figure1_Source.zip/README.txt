SE-JEPA 论文 · 图 1 源文件

在 Illustrator 或 Inkscape 中打开 teaser_bars.svg，可单独编辑文字、条形和配色。PDF 是论文中使用的矢量版本，PNG 可用于预览。

数据与重绘
每个百分数对应论文主表的本研究评测列。pushobj_all 包括七种形状，pushobj_unseen 包括预训练中未见的三种形状，pusht_shift 包括六种外观偏移。三列均为 CEM 规划成功率（%）。主表中另列的 DINO-WM 原文两种形状测试属于不同评测。Frozen、AdaJEPA、SE-JEPA 的结果取自配对留出目标。DINO-WM 和 LeWM 的 PushObj 使用测试种子 2000，PushT 使用 VIS50（每种偏移 50 个目标）。

如需修改数值，先编辑 teaser_bars.csv，然后在解压后的文件夹里运行：

    python -m pip install matplotlib
    python plot_teaser.py --data teaser_bars.csv --output-dir rebuilt

重绘后的 SVG、PDF 和 PNG 在 rebuilt 文件夹。若需更换颜色，可编辑 plot_teaser.py。
