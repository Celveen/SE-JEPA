SE-JEPA 首页图 1 源文件

teaser_combined.pdf 为论文用图。teaser_combined.svg 可编辑，包含上方
recurring-shift-schematic 和下方 held-out-planning-success。作者原图见
teaser_combined_original.svg。teaser_bars 提供下半图的 SVG、PDF、PNG 和 CSV。

柱状图统一使用 GD，并按成功率从低到高排列，SE-JEPA 位于最下面。上方结构示意保持 One-round adaptive JEPA，下方柱状图标签为 adaJEPA。PushObj All 覆盖七种形状，Unseen 覆盖 I、square 和
small tee。SE-JEPA 使用完整方法的原始三条学习链。PushT 的六种视觉偏移使用
Frozen、AdaJEPA 和 SE-JEPA 的配对留出测试。

DINO-WM 和 LeWM 的 PushObj 使用 seed 2000，每种形状 50 个回合。所有形状
分别成功 172/350 和 212/350。未见形状分别成功 54/150 和 65/150。
https://github.com/Celveen/SE-JEPA/tree/eec0ba00fbb945c4dc70bd4804035f845b67a463/research_snapshots/2026-11-07/baseline_metadata

Frozen、AdaJEPA 和 SE-JEPA 的数据见论文工程的 data/paper_snapshot.json。
Drive 的视觉测试汇总按六种偏移复算得到相同成功率。
https://drive.google.com/file/d/1UNSDTDPy4XkQZo8njdMFSPwYQMyk_JDH/view

重绘时编辑 teaser_bars.csv。配色在 plot_teaser.py 的 COLORS 中设置。
以下命令使用 Python 3，需要 Matplotlib、CairoSVG、PyMuPDF 和系统 Cairo。

    python plot_teaser.py --data teaser_bars.csv --output-dir rebuilt
    python combine_teaser.py --template teaser_combined.svg --bars-dir rebuilt --output-dir rebuilt

rebuilt 中的 teaser_combined.svg 和 teaser_combined.pdf 为重绘的完整单栏图。
