SE-JEPA 首页图 1 源文件

teaser_combined.pdf 为论文用图。teaser_combined.svg 可编辑，包含上方
recurring-shift-schematic 和下方 held-out-planning-success。作者原图见
teaser_combined_original.svg。teaser_bars 提供下半图的 SVG、PDF、PNG 和 CSV。

柱状图统一使用 GD，并按成功率从低到高排列，SE-JEPA 位于最下面。上方结构示意保持 One-round adaptive JEPA，下方柱状图标签为 adaJEPA。PushObj All 覆盖七种形状，Unseen 覆盖 I、square 和
small tee。SE-JEPA 使用完整方法的原始三条学习链。PushT 的六种视觉偏移中，Frozen、AdaJEPA 和 SE-JEPA 使用配对留出测试；
AdaJEPA 使用官方发布的视觉权重。DINO-WM/LeWM 新增 GD 均值为38.00/39.33，
来自2026-11-08-pusht-gd归档，均为六偏移300回合。

DINO-WM 和 LeWM 的 PushObj 使用 seed 2000，每种形状 50 个回合。所有形状
分别成功 172/350 和 212/350。未见形状分别成功 54/150 和 65/150。
https://github.com/Celveen/SE-JEPA/tree/eec0ba00fbb945c4dc70bd4804035f845b67a463/research_snapshots/2026-11-07/baseline_metadata

Frozen、AdaJEPA 和 SE-JEPA 的数据见论文工程的 data/paper_snapshot.json。
Drive 的视觉测试汇总按六种偏移复算得到相同成功率。
https://drive.google.com/file/d/1UNSDTDPy4XkQZo8njdMFSPwYQMyk_JDH/view

重绘时编辑 teaser_bars.csv。配色在 plot_teaser.py 的 COLORS 中设置。
以下命令使用 Python 3，需要 Matplotlib、CairoSVG、PyMuPDF 和系统 Cairo。

    python plot_teaser.py --data teaser_bars.csv --output-dir rebuilt
    python combine_teaser.py --template teaser_combined.svg --bars-dir rebuilt --output-dir rebuilt

rebuilt 中的 teaser_combined.svg 和 teaser_combined.pdf 为重绘的完整单栏图。

PushT新增结果来源：
https://github.com/Celveen/SE-JEPA/tree/d4f6cb491ac19d0224485b056fe5b24aa8e50f94/research_snapshots/2026-11-08-pusht-gd
DINO-WM每次执行25物理步、最多6次重规划；LeWM每次5步、最多30次。
二者均为150物理步上限，具体差异见论文附录B。共享行顺序按PushObj All排序。
