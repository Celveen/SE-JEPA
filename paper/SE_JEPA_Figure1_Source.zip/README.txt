SE-JEPA 首页图 1 源文件

论文用图为 teaser_combined.pdf，单栏展示上方机制示意和下方三组成功率。用 Illustrator 或 Inkscape 打开 teaser_combined.svg 可编辑全图。其两个主图层为 recurring-shift-schematic（上）和 held-out-planning-success（下）。这两个文件使用核验后的 GD/CEM 数据。

teaser_combined_original.svg 是作者提供的排版原稿，保留原始画布和旧版柱值，便于核对设计。最终稿已将下半部换成新的数值及规划器标识。teaser_bars.svg、teaser_bars.pdf 和 teaser_bars.png 为可单独使用的下半图。

读图
teaser_bars.csv 的三项成功率（%）依次覆盖 PushObj 全部七种形状、其中预训练时未见的三种形状，以及 PushT 的六种外观偏移。柱状图前三行使用 GD，后两行单列 DINO-WM 和 LeWM 的 CEM 参考结果。

PushObj All 上的星号表示关闭熟悉度读写保护的 SE-JEPA，成熟度筛选仍开启。GD 使 1,050 个测试回合中的 873 个达到目标，成功率 83.14%。附文件 gd_no_familiarity_test_batches.csv 保留该次 GD 测试的全部 21 批计数，按种子、形状各 50 个回合。所有行的 successes 之和除以 n 之和即可复算。CEM 同配置的 836/1,050（79.62%）用于论文主表。其余两个 SE-JEPA 柱分别展示完整方法在三种未见形状和六种外观偏移上的 GD 结果。

数据出处
GD 批次摘自下列固定提交的 batch_results.csv，筛选 optimizer=GD、phase=test、method=no_familiarity。文件内的 raw_path 和 sha256 对应原始批次。
https://github.com/Celveen/SE-JEPA/blob/3faad041417c6f2a22df2ad62822c34fd075c4bb/experiments/ablation_archive_20261106/tables/batch_results.csv

CEM 的逐回合结果见同一提交的 familiarity_test_episodes_20261106.csv，筛选 optimizer=CEM、method=no_familiarity。
https://github.com/Celveen/SE-JEPA/blob/3faad041417c6f2a22df2ad62822c34fd075c4bb/experiments/ablation_archive_20261106/preview/familiarity_test_episodes_20261106.csv

Frozen、AdaJEPA 和完整 SE-JEPA 的 GD 数据来自论文工程 data/paper_snapshot.json 中的 shape.GD 和 visual.rates.GD。DINO-WM 和 LeWM 的 CEM 参考结果在 PushObj 上使用 H7t3 的 seed 2000，在 PushT 上使用 VIS50。DINO-WM 的六种偏移共计 171/300（57.0%）。
https://github.com/Celveen/SE-JEPA/tree/974c70aaefee43a867840fd118f21f7c39d452e2

重绘数字与配色
在此文件夹中编辑 teaser_bars.csv。配色在 plot_teaser.py 顶部的 COLORS 中设置，条形和柱外数值会同步更新。以下命令使用 Python 3，在本目录运行：

    python -m pip install matplotlib CairoSVG PyMuPDF
    python plot_teaser.py --data teaser_bars.csv --output-dir rebuilt
    python combine_teaser.py --template teaser_combined.svg --bars-dir rebuilt --output-dir rebuilt

rebuilt/teaser_combined.svg 和 rebuilt/teaser_combined.pdf 是含更新数值的完整单栏图。若只改上方示意，可以先用矢量编辑器编辑 teaser_combined.svg，然后以 --bars-dir . 重新组合。保留下方图层的 ID 和纵向位置。CairoSVG 需要系统可载入 Cairo 动态库，字体相同的环境可复现论文中的字形。
