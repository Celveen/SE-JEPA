# SE-JEPA · Overleaf source package

This archive contains the source for the main paper and supplementary material
from the Overleaf snapshot synchronized on 2026-11-17, used for the two PDFs
delivered on 2026-11-18.

1. In Overleaf, choose New Project → Upload Project and upload this ZIP.
2. Select pdfLaTeX. Select main.tex as the main document for the paper.
3. Select supplement.tex as the main document for the supplementary material.

The two entry points share the same bibliography and figure assets. If main.aux
is present, the supplement reads the current main-paper numbering from it.
A fresh import uses the included main-crossrefs.tex snapshot. After any changes
that renumber the main paper, recompile it and refresh the snapshot if building
the supplement in a clean project.
