"""One shape-GD pure EMA ablation, with exact source tasks and verified backups."""
from pathlib import Path
import concurrent.futures as cf
import fcntl,json,queue,shutil,signal,sys,threading,time,traceback
import numpy as np
import torch
from omegaconf import OmegaConf
import engine as E
import naive_reference as B

ROOT=E.ROOT;CODE=E.CODE;P=E.P;OLD=Path(P['source_experiment'])
ALPHA=P['variants']['ema_slow']['ema_alpha']

def job(index):
    if index<35:
        rnd=index//7+1;tag=P['domain_order'][index%7]
        return dict(phase='learn',optimizer='GD',method='ema_slow',chain=1,index=index,round=rnd,tag=tag,
                    seed=P['seed_schedule'][0][rnd-1],input_key=f'learn_c1_r{rnd}_{tag}')
    i=index-35;seed=P['test_seeds'][i//7];tag=P['domain_order'][i%7]
    return dict(phase='test',optimizer='GD',method='ema_slow',chain=1,index=i,round=5,tag=tag,
                seed=seed,input_key=f'test_s{seed}_{tag}')

def output(j):
    if j['phase']=='learn':return ROOT/'results/learn/GD/ema_slow'/f"chunk_{j['index']:02d}_r{j['round']}_{j['tag']}"
    return ROOT/'results/test/GD/ema_slow'/f"seed_{j['seed']}"/j['tag']

def command(j,out,n,state=None,variant=None):
    if variant in ['stock','naive']:return B.command(j,out,n,state,'stock' if variant=='stock' else None)
    alpha={'ema_zero':0.0,'ema_one':1.0}.get(variant,ALPHA)
    cmd=B.command(j,out,n,None,'stock')
    return cmd+['planner._target_=planning.ema_slow.EMASlowPlanner',
        '+planner.ema.alpha='+str(alpha),'+planner.ema.mode='+('learn' if j['phase']=='learn' else 'readonly'),
        '+planner.ema.state_in='+(str(state) if state else 'null'),
        '+planner.ema.state_out=continual_state.pt','+planner.ema.checkpoint_sha256='+P['checkpoint_sha256']]

def audit(j,out,n,initial,state,state_before,variant):
    if variant in ['stock','naive']:return B.audit(j,out,n,initial,state,state_before,'stock' if variant=='stock' else None)
    row=B.audit(j,out,n,initial,state,state_before,'stock')
    cfg=OmegaConf.to_container(OmegaConf.load(out/'.hydra/config.yaml'),resolve=True)
    alpha={'ema_zero':0.0,'ema_one':1.0}.get(variant,ALPHA)
    assert cfg['planner']['ema']['alpha']==alpha
    assert cfg['planner']['ema']['mode']==('learn' if j['phase']=='learn' else 'readonly')
    assert 'continual' not in cfg['planner'] and 'inheritance' not in cfg['planner']
    a=json.loads((out/'ema_audit.json').read_text());rec=E.lines(out/'episodes.jsonl')
    assert a['alpha']==alpha and a['episodes']==n
    assert a['initial_episode']==initial and a['final_episode']==initial+n
    assert a['exact_episode_starts_verified'] and a['final_reset_exact']
    assert a['no_cross_episode_replay'] and a['slow_optimizer_steps']==0 and a['optimizer_calls_only_within_episode']
    assert [r['episode'] for r in rec]==list(range(initial,initial+n))
    assert [r['sample_idx'] for r in rec]==list(range(n))
    assert all(r['slow_optimizer_steps']==0 and r['alpha']==alpha for r in rec)
    with np.load(out/'final_eval_results.npz') as z:
        assert [r['success'] for r in rec]==z['successes'].tolist()
        if n==50:
            prior=(OLD/'results/learn/GD/slow_lr_high'/f"chunk_{j['index']:02d}_r{j['round']}_{j['tag']}" if j['phase']=='learn'
                   else OLD/'results/test/GD/adajepa_same'/f"seed_{j['seed']}"/j['tag'])/'final_eval_results.npz'
            with np.load(prior) as old:
                assert np.array_equal(z['state_0'],old['state_0']) and np.array_equal(z['state_g'],old['state_g'])
            row['targets_match_completed_core_ablation']=True
    trace=E.lines(out/'per_iter_logs.json')
    assert a['fast_optimizer_calls']==sum('adajepa/pred_loss' in r for r in trace)
    if state:
        prev=json.loads((Path(state).parent/'ema_audit.json').read_text())
        assert a['loaded_slow_sha256']==prev['final_slow_sha256'] and initial==prev['final_episode']
    if j['phase']=='learn':
        assert all(r['ema_applied'] for r in rec) and a['state_written']
        assert all(x['slow_before_sha256']==y['slow_after_sha256'] for x,y in zip(rec[1:],rec[:-1]))
        st=torch.load(out/'continual_state.pt',map_location='cpu',weights_only=False)
        assert st['schema']=='ema-slow-parameters-v1' and st['alpha']==alpha and st['episode']==initial+n
        assert st['parameter_sha256']==a['final_slow_sha256']
        assert all(torch.isfinite(s).all() for s in st['parameters'])
        assert not set(st)&{'memory','replay','domains','optimizer','opt'}
        row.update(state_sha256=E.sha(out/'continual_state.pt'),state_in_sha256=state_before,
                   initial_episode=initial,final_episode=initial+n,ema_alpha=alpha,no_slow_gradient_training=True)
    else:
        assert a['persistent_state_unchanged'] and not a['state_written']
        assert not (out/'continual_state.pt').exists()
        assert all(not r['ema_applied'] and r['slow_before_sha256']==a['loaded_slow_sha256']==r['slow_after_sha256'] for r in rec)
        row.update(readonly_verified=True,state_in_sha256=state_before,initial_episode=initial,ema_alpha=alpha)
    return row

def preflight():
    assert ALPHA==1e-4 and P['total_episodes']==2800 and P['total_jobs']==56
    assert E.sha(Path(P['checkpoint'])/'checkpoints/model_latest.pth')==P['checkpoint_sha256']
    previous=json.loads((OLD/'protocol.json').read_text())
    assert P['seed_schedule']==previous['seed_schedule'] and P['test_seeds']==previous['test_seeds']
    for key,v in P['streams'].items():
        assert E.sha(v['path'])==v['sha256']==previous['streams'][key]['sha256']
    for name,h in json.loads((ROOT/'base_source_manifest.json').read_text()).items():assert E.sha(CODE/name)==h,name
    assert shutil.disk_usage(ROOT).free>8*2**30
    E.save(ROOT/'preflight.json',{'passed':True,'time':E.now(),'alpha':ALPHA,'formal_episodes':2800,
        'checkpoint_sha256':P['checkpoint_sha256'],'all_56_inputs_match_completed_core_ablation':True,
        'same_seed_order':True,'no_replay_or_slow_gradient_training':True})

def smoke():
    preflight();E.PHASE='validating';j=job(0);checks={}
    def boundary(gpu,ema_variant,reference):
        x=ROOT/'smoke'/ema_variant;y=ROOT/'smoke'/reference
        E.execute(j,gpu,n=3,out=x,variant=ema_variant)
        E.execute(j,gpu,n=3,out=y,variant=reference)
        return B.compare(x,y)
    with cf.ThreadPoolExecutor(2) as pool:
        z=pool.submit(boundary,2,'ema_zero','stock')
        o=pool.submit(boundary,3,'ema_one','naive')
        checks['alpha_zero_matches_adajepa_exactly']=z.result()
        checks['alpha_one_matches_naive_inheritance_exactly']=o.result()
    from planning.ema_slow import ema_update_
    s=[torch.tensor([1.,-2.,3.],dtype=torch.float64)]
    ema_update_(s,[torch.tensor([5.,6.,7.],dtype=torch.float64)],ALPHA)
    assert torch.allclose(s[0],torch.tensor([1.0004,-1.9992,3.0004],dtype=torch.float64),rtol=0,atol=1e-12)
    checks['requested_coefficient_math']=True
    learn=ROOT/'smoke/actual';E.execute(j,2,n=4,out=learn)
    state=learn/'continual_state.pt'
    with cf.ThreadPoolExecutor(2) as pool:
        resume=pool.submit(E.execute,job(1),2,n=2,out=ROOT/'smoke/resume',state=state,initial=4)
        readonly=pool.submit(E.execute,{**j,'phase':'test'},3,n=2,out=ROOT/'smoke/readonly',state=state,initial=4)
        resume.result();readonly.result()
    checks.update(resume_exact=True,heldout_state_unchanged=True,no_slow_optimizer=True,finite_weights=True)
    E.save(ROOT/'smoke_validation.json',{'passed':True,'time':E.now(),'checks':checks,
        'only_learning_samples_used':True,'excluded_from_formal_results':True,'formal_chain_restarts_from_pretrained':True})
    E.status('validation_passed')

def run():
    preflight();assert json.loads((ROOT/'smoke_validation.json').read_text())['passed']
    def restored(j):
        out=output(j)
        if not (out/'audit.json').exists() or not (out/'backup_ack.json').exists():return False
        a=json.loads((out/'audit.json').read_text());assert E.sha(out/'final_eval_results.npz')==a['result_sha256']
        with E.LOCK:E.FINISHED[str(out)]=a
        return True
    def execute(j,gpu,state,initial,prev=None):
        try:
            out=output(j);a=E.execute(j,gpu,state=state,initial=initial);E.export(j,out)
            if prev:E.retire_previous(prev,out)
            with E.LOCK:E.FINISHED[str(out)]=a
        except BaseException:
            with E.LOCK:E.ERRORS.append({'job':j,'traceback':traceback.format_exc()})
            E.STOP.set();raise
    E.PHASE='learning'
    for i in range(35):
        E.check_stop();j=job(i)
        if restored(j):continue
        prev=output(job(i-1)) if i else None
        execute(j,2,prev/'continual_state.pt' if prev else None,i*50,prev)
    E.PHASE='heldout_test';q=queue.Queue()
    for i in range(35,56):
        if not restored(job(i)):q.put(job(i))
    def worker(gpu):
        while not E.STOP.is_set() and not q.empty():
            if gpu in [0,1]:
                try:s=json.loads((Path(P['concurrent_experiment'])/'status.json').read_text())
                except (OSError,json.JSONDecodeError):s={}
                if s.get('status')!='completed':E.check_stop();time.sleep(5);continue
            try:j=q.get_nowait()
            except queue.Empty:return
            try:execute(j,gpu,output(job(34))/'continual_state.pt',1750)
            finally:q.task_done()
    with cf.ThreadPoolExecutor(4) as pool:
        for f in [pool.submit(worker,g) for g in [2,3,0,1]]:f.result()
    E.check_stop();assert len(E.FINISHED)==56
    summarize();E.PHASE='completed';E.status()
    E.save(ROOT/'final_results.json',{'status':'completed','time':E.now(),'results':list(E.FINISHED.values())})

def summarize():
    def metric(rows):
        n=sum(r['n'] for r in rows);s=sum(r['successes'] for r in rows)
        return dict(n=n,successes=s,success_rate=s/n,mpc_steps_all=sum(r['mpc_steps_all_mean']*r['n'] for r in rows)/n,
                    mpc_steps_success=sum((r['mpc_steps_success_mean'] or 0)*r['successes'] for r in rows)/s if s else None)
    tests={}
    for tag in ['all']+P['domain_order']:
        rows=[r for r in E.FINISHED.values() if r['phase']=='test' and (tag=='all' or r['tag']==tag)]
        by={str(s):metric([r for r in rows if r['seed']==s]) for s in P['test_seeds']}
        tests[tag]={'pooled':metric(rows),'by_test_seed':by,'success_rate_test_seed_std':float(np.std([r['success_rate'] for r in by.values()],ddof=1))}
    E.save(ROOT/'test_summary.json',{'source':'H7t3 heldout; final S7t5/s100 slow parameters; no persistent test updates','alpha':ALPHA,'results':{'ema_slow':tests}})
    E.save(ROOT/'learning_summary.json',{'source':'S7t5 online learning','results':{'ema_slow':{str(i):metric([r for r in E.FINISHED.values() if r['phase']=='learn' and r['round']==i]) for i in range(1,6)}}})

E.command=command;E.audit=audit;E.output=output
if __name__=='__main__':
    lock=(ROOT/'supervisor.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    signal.signal(signal.SIGTERM,lambda *_:E.STOP.set());signal.signal(signal.SIGINT,lambda *_:E.STOP.set())
    threading.Thread(target=E.heartbeat,daemon=True).start()
    try:{'preflight':preflight,'smoke':smoke,'run':run}[sys.argv[1]]()
    except BaseException:
        E.ERRORS.append({'time':E.now(),'traceback':traceback.format_exc()});E.STOP.set()
        E.status('stopped' if (ROOT/'STOP').exists() else 'failed');raise
    finally:E.STOP.set()
