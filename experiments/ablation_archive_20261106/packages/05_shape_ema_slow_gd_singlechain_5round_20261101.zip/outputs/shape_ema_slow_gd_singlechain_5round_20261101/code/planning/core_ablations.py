"""Narrow CLS6a ablations and invariant checks, without changes to the fast planner."""
import hashlib,json
from pathlib import Path
import numpy as np
import torch
from .continual import ContinualMPCPlanner
from .continual_v7 import CLSv7MPCPlanner


def tree_hash(obj):
    h=hashlib.sha256()
    def visit(x):
        if isinstance(x,torch.Tensor):
            x=x.detach().cpu().contiguous()
            h.update(str((str(x.dtype),tuple(x.shape))).encode());h.update(x.numpy().tobytes())
        elif isinstance(x,dict):
            for k in sorted(x,key=lambda y:str(y)):h.update(repr(k).encode());visit(x[k])
        elif isinstance(x,(list,tuple)):
            h.update(str(len(x)).encode())
            for v in x:visit(v)
        else:h.update(repr(x).encode())
    visit(obj);return h.hexdigest()


class AuditedCLSAblation(CLSv7MPCPlanner):
    def __init__(self,ablation='full',continual=None,**kwargs):
        assert ablation in ['full','shared_slow','no_maturity_read','slow_lr_low','slow_lr_high']
        self.ablation=ablation
        super().__init__(continual=continual,**kwargs)
        self._audit_initial_episode=self._episode
        self._audit_initial_digest=self._persistent_digest()
        self._audit_seen=0
        assert self.familiar_read and self.familiar_thr==.0146
        assert self.mature_k==3 and self.mature_ratio==.9 and self.reject_ratio==1.2
        assert self.slow_steps==15 and self.slow_batch==8 and self.min_n==3 and self.write_w==0
        if self.ablation=='shared_slow':self._check_single()

    def _persistent_digest(self):
        ds={}
        for k,d in self.domains.items():
            ds[k]={key:val for key,val in d.items() if key not in ['learner','opt']}
            ds[k]['learner']=d['learner'].state_dict() if d['learner'] is not None else None
            ds[k]['opt']=d['opt'].state_dict() if d['opt'] is not None else None
        return tree_hash({'domains':ds,'pending':self.pending,'slow':self._slow})

    def _check_single(self):
        assert set(self.domains)<= {'shared'} and not self.pending
        assert sum(d['learner'] is not None for d in self.domains.values())<=1

    def _learners(self):
        if self.ablation=='no_maturity_read':
            return [k for k,d in self.domains.items() if d['learner'] is not None and not d.get('merged_into')]
        return super()._learners()

    def _learn(self,d):
        assert not self.read_only
        return super()._learn(d)

    def _train(self,d,steps):
        assert not self.read_only
        return super()._train(d,steps)

    def _end_episode(self):
        if self.ablation=='shared_slow' and not self.read_only:self._end_shared()
        else:super()._end_episode()
        if self.ablation=='shared_slow':self._check_single()
        r=self._ep_records[-1]
        r['ablation']=self.ablation
        if self.read_only:assert r['write'] is None and r['write_rule']=='read_only'
        self._audit_seen+=1
        with open('episodes.jsonl','a') as f:f.write(json.dumps(r)+'\n')

    def _end_shared(self):
        """Collapse allocation to one global replay, preserving non-partition guards."""
        self._check_single()
        z=self._episode_latents()
        fam=self._familiarity(z)
        delta=[p.detach()-s for p,s in zip(self._params,self._start)]
        base=self._base
        self._val_cache={};self._abs_cache={}
        key=None;rule='familiar';ratio=float('nan');loss=float('nan');rejected=[]
        if fam>self.familiar_thr:
            if 'shared' in self.domains and self._rejects('shared',z):
                rule='rejected';rejected=['shared']
            else:
                key='shared';rule='shared'
                d=self.domains.setdefault(key,{'n':0,'tags':{},'replay':[],'fp_sum':None,'fp_n':0,'learner':None,'opt':None,'val':[]})
                if d['learner'] is not None:
                    ratio=self._val_ratio(key,z);d['val'].append(float(ratio))
                self._add(d,self.tag,z.detach(),self._fp(delta) if base is None else None)
                loss=self._learn(d)
        ContinualMPCPlanner._end_episode(self)
        r=self._ep_records[-1]
        r.update(read=base,route=self._route_log,write=key,write_rule=rule,slow_loss=loss,val_ratio=ratio,
                 familiar_score=fam,rejected_by=rejected,pending_n=0,new_members=[],merges=[],absorbs=[],
                 val_all=dict(self._val_cache),rejected_ratios=dict(self._val_cache),
                 domains={k:{'n':d['n'],'tags':dict(d['tags']),'learner':d['learner'] is not None,
                              'mature':d['learner'] is not None and self._mature(d),'val_last':d.get('val',[])[-3:]}
                          for k,d in self.domains.items()})

    def plan(self,*args,**kwargs):
        out=super().plan(*args,**kwargs)
        final=self._persistent_digest()
        if self.read_only:
            assert final==self._audit_initial_digest,'Persistent state changed during heldout evaluation'
            assert not Path(self.state_out).exists()
        Path('ablation_audit.json').write_text(json.dumps({
            'ablation':self.ablation,'read_only':self.read_only,'initial_episode':self._audit_initial_episode,
            'final_episode':self._episode,'episodes':self._audit_seen,
            'initial_persistent_sha256':self._audit_initial_digest,'final_persistent_sha256':final,
            'persistent_state_unchanged':final==self._audit_initial_digest,
            'active_learners':sum(d['learner'] is not None for d in self.domains.values()),
            'domain_keys':list(self.domains),'slow_lr':self.slow_lr,
            'familiarity_protection_kept':True,'mature_k_for_write_and_absorption':self.mature_k,
            'read_maturity_gate_removed':self.ablation=='no_maturity_read',
            'state_written':not self.read_only},indent=2))
        return out
