"""Pure episodic parameter EMA on top of the unchanged AdaJEPA fast adapter."""
import json,time
from pathlib import Path
import torch
from .adajepa_mpc import AdaJEPAMPCPlanner
from .naive_inheritance import digest


@torch.no_grad()
def ema_update_(slow,fast,alpha):
    assert 0 <= alpha <= 1
    for s,p in zip(slow,fast):
        if alpha==1:s.copy_(p.detach())
        elif alpha!=0:s.add_(p.detach()-s,alpha=alpha)


class EMASlowPlanner(AdaJEPAMPCPlanner):
    def __init__(self,ema=None,**kwargs):
        super().__init__(**kwargs)
        self.c=dict(ema or {})
        self.alpha=float(self.c['alpha']);assert 0<=self.alpha<=1
        self.mode=self.c.get('mode','learn');assert self.mode in ('learn','readonly')
        tr=self.adajepa_trainer
        self.params=list(tr._ada_predictor_params)+list(tr._ada_encoder_params)
        names={id(p):n for n,p in self.wm.named_parameters()}
        self.names=[names[id(p)] for p in self.params]
        self.initial={k:v.detach().clone() for k,v in self.wm.state_dict().items()}
        self.slow=[p.detach().clone() for p in self.params]
        self.initial_episode=0
        if self.c.get('state_in'):
            st=torch.load(self.c['state_in'],map_location='cpu',weights_only=False)
            assert st['schema']=='ema-slow-parameters-v1'
            assert st['checkpoint_sha256']==self.c['checkpoint_sha256']
            assert st['alpha']==self.alpha and st['parameter_names']==self.names
            assert digest(zip(self.names,st['parameters']))==st['parameter_sha256']
            assert len(st['parameters'])==len(self.params)
            assert all(p.shape==s.shape and p.dtype==s.dtype for p,s in zip(self.params,st['parameters']))
            self.slow=[s.to(p.device).clone() for p,s in zip(self.params,st['parameters'])]
            self.initial_episode=int(st['episode'])
        assert self.mode!='readonly' or self.c.get('state_in')
        self.loaded_digest=digest(zip(self.names,self.slow))
        self.records=[];self.fast_optimizer_calls=0
        original_make=tr._make_optimizer
        def make_fast_optimizer():
            self.fast_optimizer_calls+=1
            return original_make()
        tr._make_optimizer=make_fast_optimizer
        Path('ema_definition.json').write_text(json.dumps({
            'mode':self.mode,'alpha':self.alpha,'parameter_names':self.names,
            'parameter_count':sum(p.numel() for p in self.params),
            'update':'slow += alpha * (fast_end - slow) once after each learning episode',
            'slow_gradient_optimizer':False,'cross_episode_replay':False,
            'domain_partitioning':False,'familiarity_gating':False,'maturity_routing':False,
            'fast_optimizer':'Unchanged fresh Adam within each finetune',
            'buffers':'Pretrained buffers restored before every episode; no EMA on buffers',
            'within_episode_buffer':'Original recent5; empty at each episode start',
            'state_in':self.c.get('state_in'),'initial_episode':self.initial_episode,
            'loaded_slow_sha256':self.loaded_digest},indent=2))

    @torch.no_grad()
    def assert_reset(self):
        assert bool(torch.stack([torch.all(v==self.initial[k]) for k,v in self.wm.state_dict().items()]).all())
        assert not self._obs_buffer and not self._act_buffer and not self._segment_scores

    def _plan_single(self,**kwargs):
        self.assert_reset()
        with torch.no_grad():
            for p,s in zip(self.params,self.slow):p.copy_(s)
        before=digest(zip(self.names,self.params))
        expected=self.records[-1]['slow_after_sha256'] if self.records and self.mode=='learn' else self.loaded_digest
        assert before==expected,'Episode start does not match the slow endpoint'
        calls=self.fast_optimizer_calls;start=time.perf_counter()
        result=super()._plan_single(**kwargs)
        fast_after=digest(zip(self.names,self.params))
        assert all(torch.isfinite(p).all() for p in self.params)
        # Independent float64 samples witness the actual interpolation, without any gradient operation.
        old_sample=[s.detach().reshape(-1)[:32].double().cpu().clone() for s in self.slow]
        fast_sample=[p.detach().reshape(-1)[:32].double().cpu().clone() for p in self.params]
        if self.mode=='learn':ema_update_(self.slow,self.params,self.alpha)
        slow_after=digest(zip(self.names,self.slow))
        residual=0.0
        for s,old,fast in zip(self.slow,old_sample,fast_sample):
            actual=s.detach().reshape(-1)[:32].double().cpu()
            target=(1-self.alpha)*old+self.alpha*fast if self.mode=='learn' else old
            error=float((actual-target).abs().max())
            tolerance=8*torch.finfo(s.dtype).eps*max(1.0,float(target.abs().max()))
            assert error<=tolerance,'EMA arithmetic mismatch'
            residual=max(residual,error)
        assert all(not s.requires_grad and torch.isfinite(s).all() for s in self.slow)
        if self.mode=='readonly':assert slow_after==self.loaded_digest
        rec=dict(sample_idx=self._sample_idx,episode=self.initial_episode+len(self.records),
                 mode=self.mode,alpha=self.alpha,success=bool(self.is_success[0]),steps=int(self.iter),
                 first_success_step=int(self.action_len[0]/self.n_taken_actions) if self.is_success[0] else None,
                 slow_before_sha256=before,fast_after_sha256=fast_after,slow_after_sha256=slow_after,
                 ema_applied=self.mode=='learn',ema_sample_max_residual=residual,
                 fast_optimizer_calls=self.fast_optimizer_calls-calls,slow_optimizer_steps=0,
                 reset_buffers_verified=True,empty_recent_buffer_verified=True,
                 seconds=time.perf_counter()-start,finished_at=time.time())
        self.records.append(rec)
        with open('episodes.jsonl','a') as f:f.write(json.dumps(rec)+'\n')
        print('[episode]',json.dumps(rec),flush=True)
        return result

    def plan(self,*args,**kwargs):
        result=super().plan(*args,**kwargs)
        assert bool(torch.stack([torch.all(v==self.initial[k]) for k,v in self.wm.state_dict().items()]).all())
        endpoint=digest(zip(self.names,self.slow))
        fast_calls=sum('adajepa/pred_loss' in r for r in self._records)
        assert self.fast_optimizer_calls==fast_calls,'Optimizer calls outside fast adaptation'
        if self.mode=='learn':
            torch.save(dict(schema='ema-slow-parameters-v1',checkpoint_sha256=self.c['checkpoint_sha256'],
                            alpha=self.alpha,episode=self.initial_episode+len(self.records),
                            parameter_names=self.names,parameters=[s.cpu() for s in self.slow],
                            parameter_sha256=endpoint),self.c.get('state_out','continual_state.pt'))
        else:
            assert endpoint==self.loaded_digest
            assert not Path(self.c.get('state_out','continual_state.pt')).exists()
        Path('ema_audit.json').write_text(json.dumps(dict(
            mode=self.mode,alpha=self.alpha,initial_episode=self.initial_episode,
            final_episode=self.initial_episode+len(self.records),episodes=len(self.records),
            loaded_slow_sha256=self.loaded_digest,final_slow_sha256=endpoint,
            exact_episode_starts_verified=True,final_reset_exact=True,
            persistent_state_unchanged=endpoint==self.loaded_digest,
            state_written=self.mode=='learn',no_cross_episode_replay=True,slow_optimizer_steps=0,
            fast_optimizer_calls=self.fast_optimizer_calls,optimizer_calls_only_within_episode=True),indent=2))
        return result
