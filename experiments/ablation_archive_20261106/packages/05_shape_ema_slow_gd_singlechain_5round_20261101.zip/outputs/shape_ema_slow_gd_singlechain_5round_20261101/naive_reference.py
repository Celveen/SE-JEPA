"""GD-only shape ablation; reuse the audited execution and backup machinery."""
from pathlib import Path
import concurrent.futures as cf
import fcntl, hashlib, json, os, pickle, queue, shutil, signal, sys, threading, traceback
import numpy as np
from omegaconf import OmegaConf
import engine as E

ROOT=E.ROOT; CODE=E.CODE; P=E.P


def learning_job(opt,chain,index):
    rnd=index//7+1;tag=P['domain_order'][index%7]
    return dict(phase='learn',optimizer='GD',method='naive',chain=chain,index=index,round=rnd,
                tag=tag,seed=P['seed_schedule'][chain-1][rnd-1],input_key=f'learn_c{chain}_r{rnd}_{tag}')


def test_job(chain,seed,tag):
    return dict(phase='test',optimizer='GD',method='naive',chain=chain,index=P['domain_order'].index(tag),
                round=5,tag=tag,seed=seed,input_key=f'test_s{seed}_{tag}')


def command(j,out,n,state=None,variant=None):
    cmd=[sys.executable,str(CODE/'plan.py'),'--config-name','adajepa_plan_gd_pushobj',
         'ckpt_base_path='+P['checkpoint'],'model_epoch=latest',
         'eval_data_path='+P['streams'][j['input_key']]['path'],f'n_evals={n}',f"seed={j['seed']}",
         '+segments_order=file','goal_source=segments','+wandb_logging=false','hydra.run.dir='+str(out),
         'planner.max_iter=30','n_plot_samples=0','decode_for_viz=false','+planner.sub_planner.cuda_graph=true']
    if variant=='stock':
        return cmd
    mode='reset_control' if variant=='reset' else ('learn' if j['phase']=='learn' else 'readonly')
    return cmd+['planner._target_=planning.naive_inheritance.NaiveInheritancePlanner',
        '+planner.inheritance.mode='+mode,'+planner.inheritance.state_in='+(str(state) if state else 'null'),
        '+planner.inheritance.state_out=naive_state.pt','+planner.inheritance.checkpoint_sha256='+P['checkpoint_sha256']]


def audit(j,out,n,initial,state,state_before,variant):
    cfg=OmegaConf.to_container(OmegaConf.load(out/'.hydra/config.yaml'),resolve=True);p=cfg['planner']
    assert cfg['seed']==j['seed'] and cfg['n_evals']==n and cfg['segments_order']=='file'
    assert cfg['ckpt_base_path']==P['checkpoint'] and cfg['model_epoch']=='latest'
    assert cfg['eval_data_path']==P['streams'][j['input_key']]['path']
    assert p['max_iter']==30 and p['n_taken_actions']==5 and cfg['goal_H']==25
    assert p['adapt']==E.REF['GD']['planner']['adapt']
    assert p['sub_planner']['opt_steps']==100 and p['sub_planner']['lr']==.1
    assert p['sub_planner']['horizon']==25 and p['sub_planner']['cuda_graph']
    assert p['sub_planner']['sample_type']=='zero' and p['sub_planner']['action_noise']==0
    assert p['reuse_actions'] and cfg['ood_corruption'] is None and cfg['env_kwargs_override'] is None
    with np.load(out/'final_eval_results.npz') as z:
        succ=z['successes'].astype(bool);length=z['action_len'].copy();a0=z['state_0'].copy();ag=z['state_g'].copy()
        assert len(succ)==n and np.isfinite(z['actions']).all()
        assert np.all(np.isfinite(length[succ])) and np.all(np.isinf(length[~succ]))
        assert np.all((length[succ]>=1)&(length[succ]<=30))
    inp=pickle.load(open(cfg['eval_data_path'],'rb'))
    raw=np.array([x['states'][0] for x in inp['segments'][:n]])
    expected0=np.zeros_like(a0);expected0[:,:raw.shape[1]]=raw
    assert np.array_equal(a0,expected0)
    assert inp['indices']==P['streams'][j['input_key']]['indices']
    assert E.sha(cfg['eval_data_path'])==P['streams'][j['input_key']]['sha256']
    target=ROOT/'target_references'/(j['input_key']+'_'+str(n)+'.npz')
    with E.TARGET_LOCK:
        target.parent.mkdir(exist_ok=True)
        if target.exists():
            with np.load(target) as z:assert np.array_equal(a0,z['state_0']) and np.array_equal(ag,z['state_g'])
        else:np.savez_compressed(target,state_0=a0,state_g=ag)
    row={**j,'n':n,'successes':int(succ.sum()),'success_rate':float(succ.mean()),
         'mpc_steps_all_mean':float(np.where(succ,length,30).mean()),
         'mpc_steps_success_mean':float(length[succ].mean()) if succ.any() else None,
         'success_counts_by_mpc_step':[int(np.sum(succ&(length<=k))) for k in range(1,31)],
         'source_input_sha256':P['streams'][j['input_key']]['sha256'],'paired_targets_verified':True,
         **json.loads((out/'run_metadata.json').read_text())}
    if state:assert E.sha(state)==state_before
    if variant!='stock':
        a=json.loads((out/'inheritance_audit.json').read_text());records=E.lines(out/'episodes.jsonl')
        assert a['initial_episode']==initial and a['final_episode']==initial+n
        assert a['episodes']==n and a['exact_episode_starts_verified'] and a['final_reset_exact']
        assert [r['sample_idx'] for r in records]==list(range(n))
        assert [r['episode'] for r in records]==list(range(initial,initial+n))
        assert [r['success'] for r in records]==succ.tolist()
        assert all(r['reset_buffers_verified'] and r['empty_recent_buffer_verified'] for r in records)
        assert all(r['first_success_step']==int(length[i]) if r['success'] else np.isinf(length[i]) for i,r in enumerate(records))
        trace=E.lines(out/'per_iter_logs.json')
        assert len(trace)==sum(r['steps'] for r in records)
        if state:
            prev=json.loads((Path(state).parent/'inheritance_audit.json').read_text())
            assert a['loaded_parameter_sha256']==prev['final_parameter_sha256'] and initial==prev['final_episode']
        if a['mode']=='learn':
            assert a['state_written']
            assert all(x['parameter_before_sha256']==y['parameter_after_sha256'] for x,y in zip(records[1:],records[:-1]))
            import torch
            st=torch.load(out/'naive_state.pt',map_location='cpu',weights_only=False)
            assert st['episode']==initial+n and st['parameter_sha256']==a['final_parameter_sha256']
            row.update(state_sha256=E.sha(out/'naive_state.pt'),state_in_sha256=state_before,initial_episode=initial,final_episode=initial+n)
        else:
            assert not a['state_written'] and a['persistent_state_unchanged']
            assert all(r['parameter_before_sha256']==a['loaded_parameter_sha256'] for r in records)
            assert not (out/'naive_state.pt').exists()
            row.update(readonly_verified=True,state_in_sha256=state_before,initial_episode=initial)
    row['result_sha256']=E.sha(out/'final_eval_results.npz')
    return row


def preflight():
    assert P['optimizers']==['GD'] and P['total_episodes']==8400
    assert E.sha(Path(P['checkpoint'])/'checkpoints/model_latest.pth')==P['checkpoint_sha256']
    for v in P['streams'].values():assert E.sha(v['path'])==v['sha256']
    for tag in P['domain_order']:
        train={i for v in P['streams'].values() if v['phase']=='learn' and v['tag']==tag for i in v['indices']}
        test={i for v in P['streams'].values() if v['phase']=='test' and v['tag']==tag for i in v['indices']}
        assert not train&test
    manifest=json.loads((ROOT/'base_source_manifest.json').read_text())
    assert all(E.sha(CODE/name)==h for name,h in manifest.items())
    assert shutil.disk_usage(ROOT).free>8*2**30
    E.save(ROOT/'source_release.json',{'time':E.now(),'files':{n:E.sha(ROOT/n) for n in ['run_experiment.py','engine.py','protocol.json','naive_inheritance.py']}})
    E.save(ROOT/'preflight.json',{'passed':True,'time':E.now(),'checkpoint_sha256':P['checkpoint_sha256'],
        'published_stream_files_verified':len(P['streams']),'train_test_segment_disjoint':True,
        'trajectory_disjoint_claimed':False,'free_gib':shutil.disk_usage(ROOT).free/2**30})


def compare(a,b,first=False):
    with np.load(a/'final_eval_results.npz') as x,np.load(b/'final_eval_results.npz') as y:
        for key in ['state_0','state_g','successes','action_len']:
            assert np.array_equal(x[key][:1] if first else x[key],y[key][:1] if first else y[key]),key
        for i in range(1 if first else len(x['successes'])):
            # plan.py groups five simulator actions into one model action;
            # compare the executed prefix, excluding batch padding.
            n=int(x['action_len'][i]) if x['successes'][i] else 30
            assert np.array_equal(x['actions'][i,:n],y['actions'][i,:n]),'Actions differ'
    return True


def smoke():
    preflight();E.PHASE='validating'
    j=learning_job('GD',1,0)
    tasks=[(j,0,ROOT/'smoke/learn',None),(j,1,ROOT/'smoke/stock','stock'),(j,2,ROOT/'smoke/reset','reset')]
    with cf.ThreadPoolExecutor(3) as pool:
        fs=[pool.submit(E.execute,j,g,n=2,out=o,variant=v) for j,g,o,v in tasks]
        for f in fs:f.result()
    state=ROOT/'smoke/learn/naive_state.pt'
    with cf.ThreadPoolExecutor(2) as pool:
        fs=[pool.submit(E.execute,learning_job('GD',1,1),0,n=2,out=ROOT/'smoke/resume',state=state,initial=2),
            pool.submit(E.execute,{**j,'phase':'test'},1,n=2,out=ROOT/'smoke/readonly',state=state,initial=2)]
        for f in fs:f.result()
    checks={'reset_matches_unmodified_adajepa':compare(ROOT/'smoke/reset',ROOT/'smoke/stock'),
            'first_learning_episode_matches_adajepa':compare(ROOT/'smoke/learn',ROOT/'smoke/stock',first=True),
            'exact_inheritance_and_readonly_reset_audited':True}
    E.save(ROOT/'smoke_validation.json',{'passed':True,'time':E.now(),'checks':checks,
        'excluded_from_formal_results':True,'formal_chains_restart_from_pretrained':True})
    E.status('validation_passed')


def run():
    preflight();assert json.loads((ROOT/'smoke_validation.json').read_text())['passed']
    E.PHASE='learning'
    def chain_worker(chain,gpu):
        for i in range(35):
            j=learning_job('GD',chain,i);out=E.output(j)
            prev=E.output(learning_job('GD',chain,i-1)) if i else None
            try:
                a=E.execute(j,gpu,state=prev/'naive_state.pt' if prev else None,initial=i*50)
                E.export(j,out)
                if prev:E.retire_previous(prev,out)
                with E.LOCK:E.FINISHED[str(out)]=a
            except BaseException:
                with E.LOCK:E.ERRORS.append({'job':j,'traceback':traceback.format_exc()})
                E.STOP.set();raise
    with cf.ThreadPoolExecutor(3) as pool:
        for f in [pool.submit(chain_worker,c,c-1) for c in [1,2,3]]:f.result()
    E.check_stop();E.PHASE='heldout_test';q=queue.Queue()
    for c in [1,2,3]:
        for s in P['test_seeds']:
            for tag in P['domain_order']:q.put(test_job(c,s,tag))
    def test_worker(gpu):
        while not E.STOP.is_set():
            try:j=q.get_nowait()
            except queue.Empty:return
            try:
                state=E.output(learning_job('GD',j['chain'],34))/'naive_state.pt'
                a=E.execute(j,gpu,state=state,initial=1750);E.export(j,E.output(j))
                with E.LOCK:E.FINISHED[str(E.output(j))]=a
            except BaseException:
                with E.LOCK:E.ERRORS.append({'job':j,'traceback':traceback.format_exc()})
                E.STOP.set();raise
            finally:q.task_done()
    with cf.ThreadPoolExecutor(4) as pool:
        for f in [pool.submit(test_worker,g) for g in range(4)]:f.result()
    assert len(E.FINISHED)==168 and sum(x['n'] for x in E.FINISHED.values())==8400
    E.save(ROOT/'final_results.json',{'status':'completed','time':E.now(),'protocol':P,'results':list(E.FINISHED.values())})
    summarize();E.PHASE='completed';E.status()


def summarize():
    def metric(rows):
        n=sum(x['n'] for x in rows);s=sum(x['successes'] for x in rows)
        return {'episodes':n,'successes':s,'success_rate':s/n,
                'mpc_steps_all':sum(x['mpc_steps_all_mean']*x['n'] for x in rows)/n,
                'mpc_steps_success':sum((x['mpc_steps_success_mean'] or 0)*x['successes'] for x in rows)/s if s else None}
    tests={};learn={}
    for tag in ['all']+P['domain_order']:
        rows=[x for x in E.FINISHED.values() if x['phase']=='test' and (tag=='all' or x['tag']==tag)]
        seeds={str(s):metric([x for x in rows if x['seed']==s]) for s in P['test_seeds']}
        group={'pooled':metric(rows),'by_test_seed':seeds}
        for k in ['success_rate','mpc_steps_all','mpc_steps_success']:
            v=[x[k] for x in seeds.values()]
            group[k]={'mean':float(np.mean(v)),'sample_std':float(np.std(v,ddof=1))} if all(x is not None for x in v) else None
        tests[tag]=group
    for r in range(1,6):
        values=[metric([x for x in E.FINISHED.values() if x['phase']=='learn' and x['round']==r and x['chain']==c]) for c in [1,2,3]]
        learn[str(r)]={'chains':values,'success_rate_mean':float(np.mean([x['success_rate'] for x in values])),
                       'success_rate_sample_std':float(np.std([x['success_rate'] for x in values],ddof=1))}
    E.save(ROOT/'test_summary.json',{'source':'H7t3 heldout only','results':{'GD':{'naive':tests}}})
    E.save(ROOT/'learning_summary.json',{'source':'online learning, separate from heldout results','results':{'GD':learn}})


E.command=command;E.audit=audit;E.learning_job=learning_job
if __name__=='__main__':
    lock=(ROOT/'supervisor.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    signal.signal(signal.SIGTERM,lambda *_:E.STOP.set());signal.signal(signal.SIGINT,lambda *_:E.STOP.set())
    threading.Thread(target=E.heartbeat,daemon=True).start()
    try:{'preflight':preflight,'smoke':smoke,'run':run}[sys.argv[1]]()
    except BaseException:
        E.ERRORS.append({'time':E.now(),'traceback':traceback.format_exc()});E.STOP.set()
        E.status('stopped' if (ROOT/'STOP').exists() else 'failed');raise
    finally:E.STOP.set()
