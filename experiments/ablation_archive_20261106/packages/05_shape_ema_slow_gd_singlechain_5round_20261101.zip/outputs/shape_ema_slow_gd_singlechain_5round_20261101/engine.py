from pathlib import Path
import concurrent.futures as cf
import datetime, fcntl, gzip, hashlib, json, os, pickle, queue, shutil, signal, subprocess, sys, threading, time, traceback
import numpy as np
from omegaconf import OmegaConf

ROOT=Path(__file__).resolve().parent;CODE=ROOT/'code'
sys.path[:0]=[str(ROOT),str(CODE)]
import baseline_helpers as helper
P=json.loads((ROOT/'protocol.json').read_text())
T=json.loads((ROOT/'v6a_templates.json').read_text())
REF=json.loads((ROOT/'v6a_reference_configs.json').read_text())
ENV=json.loads((ROOT/'runtime_env.json').read_text())
LOCK=threading.RLock();START_LOCK=threading.Lock();TARGET_LOCK=threading.Lock()
STOP=threading.Event();ACTIVE={};FINISHED={};ERRORS=[];EXPORTS={};PHASE='preparing'

def now():return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
def save(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2));tmp.replace(path)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return h.hexdigest()
def lines(path):
    if not Path(path).exists():return []
    result=[]
    for s in Path(path).read_text().splitlines():
        try:result.append(json.loads(s))
        except json.JSONDecodeError:pass
    return result
def check_stop():
    if (ROOT/'STOP').exists():STOP.set()
    if STOP.is_set():raise InterruptedError('Stop requested')
def learning_job(opt,chain,index):
    rnd=index//7+1
    return dict(phase='learn',optimizer=opt,method='v6a',chain=chain,index=index,round=rnd,
                tag=P['domain_order'][index%7],seed=P['seed_schedule'][chain-1][rnd-1],input_key=f'learn_c{chain}_r{rnd}')
def test_job(opt,method,chain,seed,tag):
    return dict(phase='test',optimizer=opt,method=method,chain=chain,index=P['domain_order'].index(tag),
                round=5 if method=='v6a' else None,tag=tag,seed=seed,input_key=f'test_s{seed}')
def output(j):
    if j['phase']=='learn':return ROOT/'results/learn'/j['optimizer']/f"chain_{j['chain']}"/f"chunk_{j['index']:02d}_r{j['round']}_{j['tag']}"
    return ROOT/'results/test'/j['optimizer']/j['method']/f"chain_{j['chain']}"/f"seed_{j['seed']}"/j['tag']
def endpoint(opt,chain):return output(learning_job(opt,chain,34))/'continual_state.pt'

def command(j,out,n,state=None,variant=None):
    block=next(b for b in P['blocks'] if b['tag']==j['tag'])
    if j['method']=='v6a':
        old=T[j['optimizer']];start=next(i for i,x in enumerate(old) if x.endswith('/plan.py'))-1
        cmd=old[start:];cmd[0]=sys.executable;cmd[1]=str(CODE/'plan.py')
        planner='planning.round_seed_logging.AuditedRoundV6aPlanner' if j['phase']=='learn' else 'planning.heldout_planners.ReadOnlyV6aPlanner'
        if variant=='learning_reference':planner='planning.round_seed_logging.AuditedRoundV6aPlanner'
        replace={'ckpt_base_path':P['checkpoint_by_method']['v6a'],'seed':str(j['seed']),
            'eval_data_path':P['streams'][j['input_key']]['path'],'n_evals':str(n),'hydra.run.dir':str(out),
            'planner._target_':planner,'planner.continual.tag':j['tag'],
            'planner.continual.state_in':str(state) if state else 'null',
            'planner.continual.save_frames':'false','planner.continual.save_deltas':'false'}
        cmd=[x for x in cmd if not x.lstrip('+').startswith(('env_kwargs_override.','ood_corruption=','ood_level='))]
        for i,x in enumerate(cmd):
            key=x.split('=',1)[0].lstrip('+')
            if key in replace:cmd[i]=key+'='+replace[key]
        return cmd+['n_plot_samples=0']+block['overrides']
    cmd=[sys.executable,str(CODE/'plan.py'),'--config-name','adajepa_plan_'+j['optimizer'].lower()+'_pushobj',
         'ckpt_base_path='+P['checkpoint_by_method'][j['method']],'model_epoch=latest',
         'eval_data_path='+P['streams'][j['input_key']]['path'],f'n_evals={n}',f"seed={j['seed']}",
         '+segments_order=file','goal_source=segments','+wandb_logging=false','hydra.run.dir='+str(out),
         'planner.max_iter=30','decode_for_viz=false','n_plot_samples=0','+ood_noise_seed=20261019','+ood_noise_pair_across_seeds=true']
    if j['method']=='frozen':
        target='planning.continual.SlowFrozenMPCPlanner' if variant=='frozen_reference' else 'planning.heldout_planners.LoggedFrozenPlanner'
        cmd+=['planner._target_='+target]
    else:cmd+=['planner._target_=planning.official_baseline_logging.LoggedAdaJEPAPlanner']
    if j['optimizer']=='GD':cmd+=['planner.sub_planner.target=planning.cuda_graph_gd.CUDAGraphGDPlanner','objective._target_=planning.cuda_graph_objectives.create_objective_fn']
    return cmd+block['overrides']

def audit(j,out,n,initial,state,state_before,variant):
    cfg=OmegaConf.to_container(OmegaConf.load(out/'.hydra/config.yaml'),resolve=True);p=cfg['planner']
    assert cfg['seed']==j['seed'] and cfg['n_evals']==n and cfg['segments_order']=='file'
    assert cfg['eval_data_path']==P['streams'][j['input_key']]['path']
    assert cfg['ckpt_base_path']==P['checkpoint_by_method'][j['method']]
    assert p['max_iter']==30 and p['n_taken_actions']==5 and cfg['goal_H']==25
    assert p['sub_planner']['horizon']==25
    if j['optimizer']=='GD':assert p['sub_planner']['opt_steps']==100 and p['sub_planner']['lr']==.1
    else:assert p['sub_planner']['opt_steps']==10 and p['sub_planner']['num_samples']==200 and p['sub_planner']['topk']==30
    if j['method']!='frozen':
        assert p['adapt']['steps']==1 and p['adapt']['lr']==5e-4 and p['adapt']['encoder_lr']==1e-5
    if j['method']=='v6a':
        expected=REF[j['optimizer']]['planner']['continual'].copy()
        expected.update(tag=j['tag'],state_in=str(state) if state else None,save_frames=False,save_deltas=False)
        assert p['continual']==expected,'Continual parameters changed'
    with np.load(out/'final_eval_results.npz') as z:
        succ=z['successes'].astype(bool);length=z['action_len'].copy()
        assert len(succ)==n and np.isfinite(z['actions']).all()
        assert np.all(np.isfinite(length[succ])) and np.all(np.isinf(length[~succ]))
        assert np.all((length[succ]>=1)&(length[succ]<=30))
        a0=z['state_0'].copy();ag=z['state_g'].copy()
    inp=pickle.load(open(P['streams'][j['input_key']]['path'],'rb'))
    raw=np.array([x['states'][0] for x in inp['segments'][:n]])
    expected0=np.zeros_like(a0);expected0[:,:raw.shape[1]]=raw
    assert np.array_equal(a0,expected0),'Execution initial states do not match selected source tasks'
    key=j['input_key']+'_'+j['tag']+'_'+str(j['seed'])
    target=ROOT/'target_references'/(key+'.npz')
    with TARGET_LOCK:
        target.parent.mkdir(exist_ok=True)
        if target.exists():
            with np.load(target) as ref:
                assert np.array_equal(a0,ref['state_0'][:n]) and np.array_equal(ag,ref['state_g'][:n]),'Paired targets differ'
        else:np.savez_compressed(target,state_0=a0,state_g=ag)
    row={**j,'n':n,'successes':int(succ.sum()),'success_rate':float(succ.mean()),
         'mpc_steps_all_mean':float(np.where(succ,length,30).mean()),
         'mpc_steps_success_mean':float(length[succ].mean()) if succ.any() else None,
         'success_counts_by_mpc_step':[int(np.sum(succ&(length<=k))) for k in range(1,31)],
         'source_input_sha256':P['streams'][j['input_key']]['sha256'],'paired_targets_verified':True,
         **json.loads((out/'run_metadata.json').read_text())}
    if state:assert sha(state)==state_before,'Input state file changed'
    if j['method']=='v6a':
        records=lines(out/'continual_episodes.jsonl')
        assert [r['sample_idx'] for r in records]==list(range(n))
        assert [r['success'] for r in records]==succ.tolist()
        assert [r['episode'] for r in records]==list(range(initial,initial+n))
        if j['phase']=='learn' or variant=='learning_reference':
            import torch
            st=torch.load(out/'continual_state.pt',map_location='cpu',weights_only=False)
            assert st['episode']==initial+n
            load=json.loads((out/'state_load_audit.json').read_text())
            assert load['initial']['episode']==initial and load['final']['episode']==initial+n
            if state and (Path(state).parent/'state_load_audit.json').exists():
                prev=json.loads((Path(state).parent/'state_load_audit.json').read_text())
                assert load['initial']==prev['final'],'Library inheritance mismatch'
            row.update(state_sha256=sha(out/'continual_state.pt'),state_in_sha256=state_before,initial_episode=initial,final_episode=initial+n)
            del st
        else:
            a=json.loads((out/'readonly_audit.json').read_text())
            assert a['persistent_state_unchanged'] and a['tested_episodes']==n
            assert not (out/'continual_state.pt').exists()
            assert all(r['write'] is None and not r['merges'] and not r['absorbs'] for r in records)
            row.update(readonly_verified=True,state_in_sha256=state_before,initial_episode=initial)
    elif variant!='frozen_reference':
        records=lines(out/'episodes.jsonl')
        assert [r['sample_idx'] for r in records]==list(range(n)) and [r['success'] for r in records]==succ.tolist()
        reset=json.loads((out/'model_reset_audit.json').read_text())
        assert reset['final_reset_exact']
        if j['method']=='frozen':assert reset['all_frozen_episodes_unchanged']
    row['result_sha256']=sha(out/'final_eval_results.npz')
    return row

def execute(j,gpu,n=50,out=None,state=None,initial=0,variant=None):
    out=out or output(j)
    if (out/'audit.json').exists():
        a=json.loads((out/'audit.json').read_text());assert sha(out/'final_eval_results.npz')==a['result_sha256'];return a
    check_stop();assert shutil.disk_usage(ROOT).free>4*2**30,'Insufficient free space before batch'
    if out.exists():
        target=ROOT/'interrupted_attempts'/('_'.join(out.relative_to(ROOT).parts)+'_'+str(time.time_ns()))
        target.parent.mkdir(exist_ok=True);out.rename(target)
    out.mkdir(parents=True)
    state_before=sha(state) if state else None
    cmd=['taskset','-c',','.join(map(str,P['cpu_affinity'][str(gpu)]))]+command(j,out,n,state,variant)
    save(out/'command.json',cmd);start=time.time()
    with (out/'console.log').open('w') as log:
        with START_LOCK:
            check_stop()
            proc=subprocess.Popen(cmd,cwd=CODE,env={**os.environ,**ENV,'CUDA_VISIBLE_DEVICES':str(gpu)},stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            with LOCK:ACTIVE[str(gpu)]={**j,'path':str(out),'pid':proc.pid,'n':n,'started':now()}
            time.sleep(3)
        print('START',j,'GPU',gpu,'PID',proc.pid,flush=True)
        try:
            while proc.poll() is None:
                if (ROOT/'STOP').exists() or shutil.disk_usage(ROOT).free<2*2**30:STOP.set()
                if STOP.is_set():
                    os.killpg(proc.pid,signal.SIGTERM)
                    try:proc.wait(timeout=30)
                    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
                    raise InterruptedError('Stopped or disk reserve reached')
                if time.time()-start>7200:raise RuntimeError('Batch exceeded two-hour watchdog')
                time.sleep(2)
        except BaseException:
            if proc.poll() is None:os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=30)
            raise
        finally:
            with LOCK:ACTIVE.pop(str(gpu),None)
    save(out/'run_metadata.json',{'rc':proc.returncode,'seconds':time.time()-start,'gpu':gpu,'completed':now(),'path':str(out)})
    assert proc.returncode==0,f'Batch failed: {out}/console.log'
    row=audit(j,out,n,initial,state,state_before,variant)
    helper.compact_targets(out)
    save(out/'audit.json',row)
    print('AUDITED',j,row['successes'],'/',n,flush=True)
    return row

def export(j,out):
    include_state=j['phase']=='learn' and j['index']%7==6
    entries=[]
    for f in out.rglob('*'):
        if not f.is_file() or f.name in ['backup_ack.json','export_manifest.json']:continue
        if f.name=='continual_state.pt' and not include_state:continue
        entries.append({'name':str(f.relative_to(out)),'bytes':f.stat().st_size,'sha256':sha(f)})
    manifest={'relative':str(out.relative_to(ROOT)),'path':str(out),'round_state_included':include_state,'files':entries}
    save(out/'export_manifest.json',manifest)
    manifest['manifest_sha256']=sha(out/'export_manifest.json')
    with LOCK:
        EXPORTS[manifest['relative']]=manifest
        save(ROOT/'export_queue.json',list(EXPORTS.values()))
    while True:
        check_stop()
        ack=out/'backup_ack.json'
        if ack.exists():
            a=json.loads(ack.read_text());assert a['manifest_sha256']==manifest['manifest_sha256'];break
        time.sleep(2)
    with LOCK:
        EXPORTS.pop(manifest['relative'],None);save(ROOT/'export_queue.json',list(EXPORTS.values()))

def retire_previous(previous,current):
    old=previous/'continual_state.pt'
    if not old.exists():return
    a=json.loads((previous/'audit.json').read_text());b=json.loads((current/'audit.json').read_text())
    assert sha(old)==a['state_sha256']==b['state_in_sha256']
    assert sha(current/'continual_state.pt')==b['state_sha256']
    if a['index']%7==6:
        ack=json.loads((previous/'backup_ack.json').read_text())
        assert ack['round_state_included']
    save(previous/'state_retired.json',{'reason':'Successor verified; round-end states also preserved in local backup','old_sha256':a['state_sha256'],'successor':str(current),'time':now()})
    old.unlink()

def status(state=None):
    with LOCK:
        active=[]
        for v in ACTIVE.values():
            rec=lines(Path(v['path'])/'episodes.jsonl')
            active.append({**v,'completed_episodes':len(rec),'successes':sum(r['success'] for r in rec)})
        save(ROOT/'status.json',{'status':state or PHASE,'updated':now(),'total_episodes':P['total_episodes'],'total_jobs':P['total_jobs'],
            'audited_episodes':sum(r['n'] for r in FINISHED.values()),'completed_jobs':len(FINISHED),
            'active':active,'waiting_backups':list(EXPORTS),'disk_free_gib':shutil.disk_usage(ROOT).free/2**30,
            'errors':ERRORS,'finished':list(FINISHED.values())})

def compare(a,b,first_only=False):
    with np.load(a/'final_eval_results.npz') as x,np.load(b/'final_eval_results.npz') as y:
        for key in ['state_0','state_g','successes','action_len']:
            xv=x[key][:1] if first_only else x[key];yv=y[key][:1] if first_only else y[key]
            assert np.array_equal(xv,yv),(key,str(a),str(b))
        xa=x['actions'][:1] if first_only else x['actions'];ya=y['actions'][:1] if first_only else y['actions']
        assert xa.shape==ya.shape and np.allclose(xa,ya,rtol=0,atol=1e-6),'Actions changed'
    return True

def preflight():
    assert P['user_confirmed'] and P['gpus']==[0,1,2,3]
    for key in ['checkpoint','original_checkpoint']:
        expected=P['checkpoint_sha256'] if key=='checkpoint' else P['original_checkpoint_sha256']
        assert sha(Path(P[key])/'checkpoints/model_latest.pth')==expected
    for item in P['streams'].values():assert sha(item['path'])==item['sha256']
    training={s['ep_idx'] for v in P['streams'].values() if v['phase']=='learn' for s in v['samples']}
    heldout={s['ep_idx'] for v in P['streams'].values() if v['phase']=='test' for s in v['samples']}
    assert not training&heldout and len(heldout)==150
    assert shutil.disk_usage(ROOT).free>8*2**30
    manifest=json.loads((ROOT/'base_source_manifest.json').read_text())
    assert all(sha(CODE/name)==h for name,h in manifest.items())
    save(ROOT/'source_release.json',{'time':now(),'files':{name:sha(ROOT/name) for name in ['run_experiment.py','code/planning/heldout_planners.py','protocol.json','sample_manifest.json','remote_io.py']},'original_code_files':len(manifest)})
    save(ROOT/'preflight.json',{'passed':True,'time':now(),'gpu_count':4,'train_test_trajectory_disjoint':True,'source_files_verified':len(manifest),'free_gib':shutil.disk_usage(ROOT).free/2**30})

def smoke():
    global PHASE
    PHASE='validating';preflight();checks={}
    def work(opt,gpu):
        j=dict(phase='learn',optimizer=opt,method='v6a',chain=1,index=0,round=1,tag='snp1',seed=9000,input_key='validation')
        first=ROOT/'smoke'/f'{opt}_learn'
        execute(j,gpu,n=2,out=first)
        second=ROOT/'smoke'/f'{opt}_learn_resume'
        execute({**j,'tag':'blur','seed':9001},gpu,n=2,out=second,state=first/'continual_state.pt',initial=2)
        prior=Path(P['source_experiment'])/'results'/opt/'v6a/repeat_1/chunk_34_r5_red_goal/continual_state.pt'
        import torch
        initial=int(torch.load(prior,map_location='cpu',weights_only=False)['episode'])
        for variant,name in [('learning_reference','read_reference'),(None,'read_only')]:
            execute({**j,'phase':'test','tag':'snp1'},gpu,n=1,out=ROOT/'smoke'/f'{opt}_{name}',state=prior,initial=initial,variant=variant)
        checks[opt+'_readonly_first_episode_matches_learning']=compare(ROOT/'smoke'/f'{opt}_read_reference',ROOT/'smoke'/f'{opt}_read_only')
        execute({**j,'phase':'test','tag':'dark'},gpu,n=2,out=ROOT/'smoke'/f'{opt}_readonly_two',state=prior,initial=initial)
        return True
    def baseline(opt,gpu):
        j=dict(phase='test',optimizer=opt,method='frozen',chain=0,index=0,round=None,tag='snp1',seed=9000,input_key='validation')
        execute(j,gpu,n=2,out=ROOT/'smoke'/f'{opt}_frozen')
        execute(j,gpu,n=2,out=ROOT/'smoke'/f'{opt}_frozen_reference',variant='frozen_reference')
        checks[opt+'_frozen_logging_equivalent']=compare(ROOT/'smoke'/f'{opt}_frozen',ROOT/'smoke'/f'{opt}_frozen_reference')
        execute({**j,'method':'adajepa'},gpu,n=2,out=ROOT/'smoke'/f'{opt}_adajepa')
    with cf.ThreadPoolExecutor(4) as pool:
        futures=[pool.submit(work,'GD',0),pool.submit(work,'CEM',1),pool.submit(baseline,'GD',2),pool.submit(baseline,'CEM',3)]
        for f in futures:f.result()
    save(ROOT/'smoke_validation.json',{'passed':True,'time':now(),'checks':checks,'smoke_excluded_from_formal_results':True})
    status('validation_passed')

def run():
    global PHASE
    preflight();assert json.loads((ROOT/'smoke_validation.json').read_text())['passed']
    PHASE='learning';chains=[];q=queue.Queue()
    for chain in [1,2,3]:
        for opt in ['GD','CEM']:
            c={'opt':opt,'chain':chain,'next':0}
            for i in range(35):
                out=output(learning_job(opt,chain,i))
                if not (out/'audit.json').exists() or not (out/'backup_ack.json').exists():break
                a=json.loads((out/'audit.json').read_text());assert sha(out/'final_eval_results.npz')==a['result_sha256']
                FINISHED[str(out)]=a;c['next']=i+1
            chains.append(c)
            if c['next']<35:q.put(c)
    def worker(gpu):
        while not STOP.is_set():
            try:c=q.get(timeout=1)
            except queue.Empty:
                if all(c['next']==35 for c in chains):return
                continue
            try:
                i=c['next'];j=learning_job(c['opt'],c['chain'],i);out=output(j)
                prev=output(learning_job(c['opt'],c['chain'],i-1)) if i else None
                a=execute(j,gpu,state=prev/'continual_state.pt' if prev else None,initial=i*50)
                export(j,out)
                if prev:retire_previous(prev,out)
                with LOCK:FINISHED[str(out)]=a;c['next']+=1
                if c['next']<35:q.put(c)
            except BaseException:
                with LOCK:ERRORS.append({'time':now(),'gpu':gpu,'job':j,'traceback':traceback.format_exc()})
                STOP.set();raise
            finally:q.task_done()
    with cf.ThreadPoolExecutor(4) as pool:
        for f in [pool.submit(worker,g) for g in range(4)]:f.result()
    check_stop();PHASE='heldout_test';q=queue.Queue()
    for opt in ['GD','CEM']:
        for seed in P['test_seeds']:
            for method in ['frozen','adajepa','v6a']:
                for chain in ([1,2,3] if method=='v6a' else [0]):
                    for tag in P['domain_order']:q.put(test_job(opt,method,chain,seed,tag))
    def test_worker(gpu):
        while not STOP.is_set():
            try:j=q.get_nowait()
            except queue.Empty:return
            try:
                state=endpoint(j['optimizer'],j['chain']) if j['method']=='v6a' else None
                a=execute(j,gpu,state=state,initial=1750 if state else 0)
                export(j,output(j))
                with LOCK:FINISHED[str(output(j))]=a
            except BaseException:
                with LOCK:ERRORS.append({'time':now(),'gpu':gpu,'job':j,'traceback':traceback.format_exc()})
                STOP.set();raise
            finally:q.task_done()
    with cf.ThreadPoolExecutor(4) as pool:
        for f in [pool.submit(test_worker,g) for g in range(4)]:f.result()
    assert len(FINISHED)==420 and sum(x['n'] for x in FINISHED.values())==21000
    save(ROOT/'final_results.json',{'status':'completed','time':now(),'protocol':P,'results':list(FINISHED.values())})
    summarize()
    PHASE='completed';status()

def summarize():
    def metric(rows):
        n=sum(x['n'] for x in rows);success=sum(x['successes'] for x in rows)
        return {'episodes':n,'successes':success,'success_rate':success/n,
            'mpc_steps_all':sum(x['mpc_steps_all_mean']*x['n'] for x in rows)/n,
            'mpc_steps_success':sum((x['mpc_steps_success_mean'] or 0)*x['successes'] for x in rows)/success if success else None}
    test={};learn={}
    for opt in ['GD','CEM']:
        test[opt]={};learn[opt]={}
        for method in ['frozen','adajepa','v6a']:
            test[opt][method]={}
            for tag in ['all']+P['domain_order']:
                rows=[x for x in FINISHED.values() if x['phase']=='test' and x['optimizer']==opt and x['method']==method and (tag=='all' or x['tag']==tag)]
                seeds=[metric([x for x in rows if x['seed']==seed]) for seed in P['test_seeds']]
                group={'pooled':metric(rows),'by_test_seed':dict(zip(map(str,P['test_seeds']),seeds))}
                for key in ['success_rate','mpc_steps_all','mpc_steps_success']:
                    values=[x[key] for x in seeds]
                    group[key]={'mean':float(np.mean(values)),'sample_std':float(np.std(values,ddof=1))} if all(v is not None for v in values) else {'mean':None,'sample_std':None}
                test[opt][method][tag]=group
        for rnd in range(1,6):
            chains=[metric([x for x in FINISHED.values() if x['phase']=='learn' and x['optimizer']==opt and x['round']==rnd and x['chain']==chain]) for chain in [1,2,3]]
            learn[opt][str(rnd)]={'chains':chains,'success_rate_mean':float(np.mean([x['success_rate'] for x in chains])),
                                'success_rate_sample_std':float(np.std([x['success_rate'] for x in chains],ddof=1))}
    save(ROOT/'test_summary.json',{'source':'held-out test only','error_bars':'sample standard deviation across three test seeds; Ours chains pooled within each test seed','results':test})
    save(ROOT/'learning_summary.json',{'source':'online learning stream, separate from final held-out success','results':learn})

def heartbeat():
    while not STOP.wait(10):status()

if __name__=='__main__':
    lock=(ROOT/'supervisor.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    def stop_signal(*_):STOP.set()
    signal.signal(signal.SIGTERM,stop_signal);signal.signal(signal.SIGINT,stop_signal)
    thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
    try:{'preflight':preflight,'smoke':smoke,'run':run}[sys.argv[1]]()
    except BaseException:
        ERRORS.append({'time':now(),'traceback':traceback.format_exc()});STOP.set();status('stopped' if (ROOT/'STOP').exists() else 'failed');raise
    finally:STOP.set()
