"""One figure per ablation, each compared only with the same full Ours baseline."""
from pathlib import Path
import sys,json,hashlib,shutil,html,csv,zipfile
sys.path.insert(0,r'D:\ADAJEPA\tmp\T_figure_python_deps')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.backends.backend_pdf import PdfPages
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1] if Path(__file__).parent.name=='scripts' else Path(r'D:\ADAJEPA\报告\七形状域_逐项消融对比图_20261104')
OLD=Path(r'D:\ADAJEPA\报告\七形状域_消融核心四图_20261104')
for sub in ['data','figures','preview','PNG_600dpi','SVG_矢量','scripts']:(ROOT/sub).mkdir(parents=True,exist_ok=True)
for name in ['heldout_episode_data.json','learning_round_metrics.csv','learning_round_audit.json']:
    if not (ROOT/'data'/name).exists():shutil.copy2(OLD/'data'/name,ROOT/'data'/name)
D=json.loads((ROOT/'data/heldout_episode_data.json').read_text(encoding='utf-8'))
ROWS=D['rows']
with (ROOT/'data/learning_round_metrics.csv').open(encoding='utf-8-sig',newline='') as f:LEARN=list(csv.DictReader(f))
DOM=['I','L','square','Z','small_tee','plus','T'];DLAB=['I','L','square','Z','smallT','+','T'];SEEDS=[2000,2100,2200]
METHODS=['naive','ema_slow','adajepa_same']
LABEL={'naive':'Naive inheritance','ema_slow':'Slow-parameter EMA','adajepa_same':'AdaJEPA','ours':'Ours'}
SHORT={'naive':'Naive inheritance','ema_slow':'Slow-parameter EMA','adajepa_same':'AdaJEPA','ours':'Ours'}
ZH={'naive':'朴素继承','ema_slow':'慢参数EMA','adajepa_same':'同权重AdaJEPA'}
COLOR={'naive':'#CFCAC2','ema_slow':'#AAB2E8','adajepa_same':'#7BCDBF','ours':'#7FB5E8'}
LS={'naive':'--','ema_slow':':','adajepa_same':'-.','ours':'-'};GD='#708CC3'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.labelsize':10,'axes.titlesize':11,
 'axes.linewidth':.65,'axes.edgecolor':'#555555','xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,
 'text.color':'#151515','axes.labelcolor':'#151515','xtick.color':'#333333','ytick.color':'#333333',
 'pdf.fonttype':42,'ps.fonttype':42,'figure.facecolor':'white','savefig.facecolor':'white','svg.hashsalt':'shape-one-ablation-20261104'})

def getrows(m,domain=None,seed=None):
    return [r for r in ROWS if r['method']==m and (domain is None or r['domain']==domain) and (seed is None or r['test_seed']==seed)]
def stat(rr):
    return {'n':len(rr),'successes':sum(r['success'] for r in rr),'rate':float(np.mean([r['success'] for r in rr])*100),
            'mpc':float(np.mean([r['mpc_steps'] for r in rr]))}
def summary(m,domain=None):
    out=stat(getrows(m,domain));bs=[stat(getrows(m,domain,s)) for s in SEEDS]
    for key in ['rate','mpc']:out[key+'_sd']=float(np.std([b[key] for b in bs],ddof=1))
    return out
def tidy(ax,top,ticks,bars=True,bottom=0):
    ax.set_axisbelow(True);ax.set_ylim(bottom,top);ax.set_yticks(ticks)
    ax.grid(axis='y' if bars else 'both',color='#E3E3E3' if bars else '#D0D0D0',lw=.5,ls='-' if bars else ':')
    if bars:
        ax.set_facecolor('#F7F7F7')
        for sp in ax.spines.values():sp.set_color('#D0D0D0')
    ax.tick_params(length=2.8,pad=3)
def bar(ax,x,m,s,key,width=.52,fs=10):
    v,e=s[key],s[key+'_sd'];ax.bar(x,v,width,color=COLOR[m],edgecolor='white',lw=.6,
         yerr=e,capsize=2,error_kw={'elinewidth':.65,'capthick':.65})
    ax.text(x,v+e+(2.1 if key=='rate' else .55),f'{v:.1f}' if fs<10 and key=='rate' else f'{v:.2f}',ha='center',va='bottom',fontsize=fs)
def linelegend(ax,pair,loc='lower right'):
    handles=[Line2D([],[],color=GD,ls=LS[m],lw=1.9 if m=='ours' else 1.6,marker=None,label=LABEL[m]) for m in pair]
    ax.legend(handles=handles,loc=loc,frameon=False,handlelength=3.1,fontsize=8.4)
def budget(ax,pair):
    tidy(ax,100,range(0,101,20),bars=False)
    for m in pair:
        blocks=[]
        for s in SEEDS:
            rr=getrows(m,seed=s);blocks.append([100*sum(r['success'] and r['mpc_steps']<=k for r in rr)/len(rr) for k in range(1,31)])
        a=np.asarray(blocks);mu=a.mean(0);sd=a.std(0,ddof=1)
        assert np.all(np.diff(mu)>=0) and abs(mu[-1]-summary(m)['rate'])<1e-9
        ax.fill_between(range(1,31),np.maximum(0,mu-sd),np.minimum(100,mu+sd),color=GD,alpha=.07,lw=0)
        ax.plot(range(1,31),mu,color=GD,ls=LS[m],lw=1.9 if m=='ours' else 1.6,marker=None,gid=m)
    ax.set(xlim=(0,30),xticks=[0,5,10,15,20,25,30],xlabel='MPC Step Budget',ylabel='Success Rate (%)')
    ax.set_title('(e) Held-out success within MPC budget',loc='left',pad=9);linelegend(ax,pair)
def learning(ax,pair):
    tidy(ax,100,range(40,101,10),bars=False,bottom=40)
    for m in pair:
        rr=sorted([r for r in LEARN if r['method']==m],key=lambda r:int(r['round']))
        assert len(rr)==5 and all(int(r['n'])==350 for r in rr)
        y=[float(r['success_rate']) for r in rr]
        ax.plot(range(1,6),y,color=GD,ls=LS[m],lw=1.9 if m=='ours' else 1.6,marker=None,gid=m)
        for x,v in zip(range(1,6),y):ax.text(x,v+(2.7 if m=='ours' else -4.3),f'{v:.1f}',ha='center',va='center',fontsize=8)
    ax.set(xlim=(.8,5.2),xticks=[1,2,3,4,5],xlabel='Learning Round',ylabel='Success Rate (%)')
    ax.set_title('(f) Learning-stage success (not held-out)',loc='left',pad=9);linelegend(ax,pair)

assert len(ROWS)==4200
for m,ns in [('ours',855),('naive',679),('ema_slow',795),('adajepa_same',808)]:
    assert summary(m)['n']==1050 and summary(m)['successes']==ns
    assert all(len(getrows(m,d,s))==50 for d in DOM for s in SEEDS)

manifest=[];metrics=[];combined=ROOT/'七形状域_逐项消融对比.pdf'
with PdfPages(combined) as pdf:
    for index,m in enumerate(METHODS,1):
        pair=[m,'ours'];has_learning=m!='adajepa_same'
        fig=plt.figure(figsize=(13.2,10.2))
        gs=fig.add_gridspec(3,2,left=.065,right=.99,top=.865,bottom=.16,hspace=.66,wspace=.23)
        fig.suptitle(f'{LABEL[m]} vs Ours',x=.53,y=.985,fontsize=15)
        fig.legend(handles=[Patch(facecolor=COLOR[k],label=LABEL[k]) for k in pair],loc='upper center',bbox_to_anchor=(.53,.957),ncol=2,frameon=False,columnspacing=3)
        fig.text(.53,.910,'Seven shape domains | GD | Same original shape pretrained checkpoint',ha='center',fontsize=9,color='#555555')
        for col,key,title,top,ticks in [(0,'rate','(a) Overall held-out success rate',110,range(0,101,20)),
                                       (1,'mpc','(b) Mean MPC steps (all test episodes)',21,range(0,21,5))]:
            ax=fig.add_subplot(gs[0,col]);tidy(ax,top,ticks)
            for j,k in enumerate(pair):bar(ax,j,k,summary(k),key)
            ax.set_xticks([0,1],[SHORT[k] for k in pair]);ax.set_xlim(-.65,1.65)
            ax.set_ylabel('Success Rate (%)' if key=='rate' else 'MPC Steps');ax.set_title(title,loc='left',pad=9)
        for col,key,title,top,ticks in [(0,'rate','(c) Held-out success by shape',110,range(0,101,20)),
                                       (1,'mpc','(d) Mean MPC steps by shape',32,range(0,31,5))]:
            ax=fig.add_subplot(gs[1,col]);tidy(ax,top,ticks)
            for j,k in enumerate(pair):
                for i,d in enumerate(DOM):bar(ax,i+(j-.5)*.42,k,summary(k,d),key,width=.34,fs=7.8)
            ax.set_xticks(range(7),DLAB);ax.set_xlim(-.6,6.6)
            ax.set_ylabel('Success Rate (%)' if key=='rate' else 'MPC Steps');ax.set_title(title,loc='left',pad=9)
        budget(fig.add_subplot(gs[2,0] if has_learning else gs[2,:]),pair)
        if has_learning:learning(fig.add_subplot(gs[2,1]),pair)
        footer=['Held-out tests: 1,050 episodes per method, 150 per shape; round-5 endpoints, one learning chain.',
                'Error bars and budget shading: +/- 1 SD across three test seeds, not training repeats. Failures count as 30 MPC steps.']
        if has_learning:
            footer+=['Panel (f): 350 online-learning episodes per round; new seed each round. It is not a fixed-test evaluation curve.']
        else:
            footer+=['AdaJEPA resets to the same pretrained checkpoint each episode. No comparable five-round learning log is available.']
        for i,line in enumerate(footer):fig.text(.065,.090-i*.022,line,fontsize=8.3,color='#555555')
        fig.canvas.draw();renderer=fig.canvas.get_renderer();w,h=fig.canvas.get_width_height()
        for t in fig.findobj(matplotlib.text.Text):
            if t.get_visible() and t.get_text():
                b=t.get_window_extent(renderer)
                assert b.x0>=-.5 and b.y0>=-.5 and b.x1<=w+.5 and b.y1<=h+.5,(m,t.get_text(),b.bounds)
        for ax in fig.axes:
            for ln in ax.lines:
                if ln.get_gid()=='ours':assert ln.get_linestyle()=='-' and ln.get_marker() in [None,'None','',' ']
        stem=f'{index:02d}_{m}_vs_ours';caption=f'{ZH[m]}与Ours一对一比较。各自1050测试回合，展示总体和逐域成功率、全部回合平均MPC及预算曲线。'
        if has_learning:caption+='右下角仅为真实学习阶段曲线，不是逐轮独立测试。'
        else:caption+='AdaJEPA每回合恢复相同的预训练权重，无可比五轮学习记录，未绘制虚构学习曲线。'
        pdf.savefig(fig);fig.savefig(ROOT/'figures'/f'{stem}.pdf',metadata={'Title':f'{LABEL[m]} vs Ours','Subject':caption,'Creator':'Python / Matplotlib'})
        fig.savefig(ROOT/'preview'/f'{stem}.png',dpi=180);fig.savefig(ROOT/'PNG_600dpi'/f'{stem}.png',dpi=600);fig.savefig(ROOT/'SVG_矢量'/f'{stem}.svg')
        s,o=summary(m),summary('ours')
        metric={'ablation':m,'baseline':'ours','ablation_metrics':s,'ours_metrics':o,'ours_minus_ablation_success_pp':o['rate']-s['rate'],
                'ours_minus_ablation_mpc':o['mpc']-s['mpc']};metrics.append(metric)
        manifest.append({'stem':stem,'title':f'{ZH[m]} vs Ours','caption':caption,'methods':pair,'panels':6 if has_learning else 5,'has_learning_stage_panel':has_learning})
        plt.close(fig);print('Saved',stem,flush=True)
assert len(PdfReader(combined).pages)==3
(ROOT/'data/pairwise_summary.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'figure_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
target=ROOT/'scripts/build_figures.py'
if target.resolve()!=Path(__file__).resolve():shutil.copy2(__file__,target)
cards=[]
for f in manifest:
    st=f['stem'];cards.append(f'<article><h2>{html.escape(f["title"])}</h2><img src="preview/{st}.png" alt="{html.escape(f["title"])}"><p>{html.escape(f["caption"])}</p><nav><a href="figures/{st}.pdf">独立PDF</a><a href="PNG_600dpi/{st}.png">600dpi原图</a><a href="SVG_矢量/{st}.svg">SVG矢量图</a></nav></article>')
page='''<!doctype html><html lang="zh"><meta charset="utf-8"><title>七形状域·逐项消融对比</title><style>body{max-width:1380px;margin:36px auto;padding:0 24px;font:16px/1.65 system-ui;color:#243447;background:#f4f6f8}article,section{background:white;padding:24px;margin:24px 0;border-radius:10px}h1{font-size:30px}h2{font-size:22px}img{width:100%;height:auto}a{color:#386b99}nav{display:flex;gap:24px}</style><h1>一个消融，一张对比图</h1><p>七形状域 · GD · 各消融分别与完整Ours对比</p><nav><a href="七形状域_逐项消融对比.pdf">3页PDF合集</a><a href="data/pairwise_summary.json">定量汇总</a></nav><section><p>每张图只出现一个消融和Ours。成功率及平均MPC柱状图保持零起点；Ours曲线为纯实线、无圆点，其他组用不同虚线。误差棒/阴影为3个测试种子的样本SD，不代表3次训练重复。</p><p>朴素继承和EMA图的右下角为学习阶段记录：每轮350回合，每轮更换种子，不能解释为固定测试集上的学习曲线。AdaJEPA无可比五轮学习日志，仅展示独立测试结果。</p><p>全部方法各1050测试回合；朴素继承仅取第1链，Ours为原s100链，慢学习率1e-4；EMA系数1e-4。AdaJEPA、朴素继承与EMA原始初始/目标状态已核对；Ours沿用报告CSV，协议和回合键对齐，但CSV不含状态张量，不能仅据CSV独立核验Ours物理状态配对。</p></section>'''+''.join(cards)+'</html>'
(ROOT/'图表索引.html').write_text(page,encoding='utf-8')
(ROOT/'README.txt').write_text('七形状域GD：每个消融单独一张综合图，与Ours比较。\n3张独立PDF/600dpi PNG/SVG，以及3页PDF合集。\n前三种对比：朴素继承 vs Ours、慢参数EMA vs Ours、同权重AdaJEPA vs Ours。\n每图包含总体/逐域成功率与平均MPC、预算曲线。朴素继承/EMA额外包含真实学习阶段曲线（非独立测试）。\nPython/Matplotlib生成，来源数据和脚本完整附带。\n',encoding='utf-8')
print(json.dumps({'output':str(ROOT),'figures':len(manifest)},ensure_ascii=False))
