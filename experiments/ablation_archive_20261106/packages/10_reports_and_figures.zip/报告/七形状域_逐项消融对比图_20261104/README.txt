七形状域GD：每个消融单独一张综合图，与Ours比较。
3张独立PDF/600dpi PNG/SVG，以及3页PDF合集。
前三种对比：朴素继承 vs Ours、慢参数EMA vs Ours、同权重AdaJEPA vs Ours。
每图包含总体/逐域成功率与平均MPC、预算曲线。朴素继承/EMA额外包含真实学习阶段曲线（非独立测试）。
Python/Matplotlib生成，来源数据和脚本完整附带。
