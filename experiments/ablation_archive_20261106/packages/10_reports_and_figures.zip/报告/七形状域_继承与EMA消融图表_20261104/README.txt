七形状域GD：朴素继承、慢参数EMA、同初始权重AdaJEPA与完整Ours对照。
8张独立矢量PDF、600dpi PNG、SVG，以及8页PDF合集、中文索引、逐回合JSON数据、Python源码。
Python依赖：numpy、matplotlib、pypdf。运行 scripts/build_figures.py 可复现绘图。
各组1050测试回合；朴素继承取第1链；Ours沿用原S7t5/s100结果。失败计30步；误差棒为3测试种子的样本SD，不是训练重复。
