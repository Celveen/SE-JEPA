"""Rebuild four matched shape-GD ablation plotting inputs from saved results.

This reads experiments only. It writes plot_data.json; it does not run models.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
from datetime import datetime
from pathlib import Path
from statistics import stdev

import numpy as np


BASE = Path(r"D:\ADAJEPA\outputs")
CORE = BASE / "shape_core_gd_singlechain_5round_20261031"
NAIVE = BASE / "shape_naive_gd_n50_3x5_heldout_20261031"
EMA = BASE / "shape_ema_slow_gd_singlechain_5round_20261101"
OUT = Path(r"D:\ADAJEPA\报告\七形状域_继承与EMA消融图表_20261104\data\plot_data.json")
DOMAINS = ["I", "L", "square", "Z", "small_tee", "plus", "T"]
SEEDS = [2000, 2100, 2200]
METHODS = ["ours", "adajepa_same", "naive", "ema_slow"]
LABELS = {
    "ours": "Ours (slow LR = 1e-4)",
    "adajepa_same": "AdaJEPA (same initial weights)",
    "naive": "Naive inheritance (chain 1)",
    "ema_slow": "Shared slow EMA (alpha = 1e-4)",
}
LABELS_ZH = {
    "ours": "完整 Ours（慢学习率 1e-4）",
    "adajepa_same": "AdaJEPA（相同初始权重）",
    "naive": "朴素继承（第 1 条链）",
    "ema_slow": "共享慢参数 EMA（α=1e-4，无慢梯度训练）",
}
EXPECTED = {
    "ours": (855, 11.366666666666667),
    "adajepa_same": (808, 12.54),
    "naive": (679, 16.11904761904762),
    "ema_slow": (795, 12.838095238095239),
}
manifest: dict[str, dict] = {}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def record(path: Path, role: str, **metadata) -> str:
    key = path.as_posix()
    digest = sha256(path)
    manifest[key] = {"path": key, "sha256": digest, "size_bytes": path.stat().st_size,
                     "role": role, **metadata}
    return digest


def read_json(path: Path, role: str = "reference_summary") -> dict:
    record(path, role)
    return json.loads(path.read_text(encoding="utf-8-sig"))


def metrics(rows: list[dict]) -> dict:
    successes = sum(r["success"] for r in rows)
    steps_sum = sum(r["mpc_steps"] for r in rows)
    success_steps_sum = sum(r["mpc_steps"] for r in rows if r["success"])
    return {
        "n": len(rows), "successes": successes,
        "success_rate": successes / len(rows),
        "success_rate_percent": 100 * successes / len(rows),
        "mpc_steps_sum": steps_sum, "mpc_steps_all": steps_sum / len(rows),
        "mpc_steps_success": success_steps_sum / successes if successes else None,
    }


def add_test_seed_sd(result: dict, by_seed: dict[str, dict]) -> dict:
    result["test_seed_sample_sd"] = {
        "n": stdev(x["n"] for x in by_seed.values()),
        "successes": stdev(x["successes"] for x in by_seed.values()),
        "success_rate": stdev(x["success_rate"] for x in by_seed.values()),
        "success_rate_percentage_points": stdev(x["success_rate_percent"] for x in by_seed.values()),
        "mpc_steps_all": stdev(x["mpc_steps_all"] for x in by_seed.values()),
        "ddof": 1, "number_of_test_seeds": 3,
        "interpretation": "Spread across three test seeds; not independent training repeats.",
    }
    return result


def curve(rows: list[dict]) -> list[dict]:
    output = []
    for step in range(1, 31):
        count = sum(r["success"] and r["mpc_steps"] <= step for r in rows)
        per_seed = {}
        for seed in SEEDS:
            subset = [r for r in rows if r["test_seed"] == seed]
            k = sum(r["success"] and r["mpc_steps"] <= step for r in subset)
            per_seed[str(seed)] = {"n": len(subset), "successes": k,
                                   "success_rate": k / len(subset)}
        output.append({
            "mpc_step": step, "n": len(rows), "successes": count,
            "success_rate": count / len(rows), "success_rate_percent": 100 * count / len(rows),
            "by_seed": per_seed,
            "test_seed_sample_sd": stdev(x["success_rate"] for x in per_seed.values()),
            "test_seed_sample_sd_percentage_points": 100 * stdev(x["success_rate"] for x in per_seed.values()),
        })
    return output


def check_summary(got: dict, expected: dict) -> None:
    assert got["n"] == expected.get("n", expected.get("episodes")), (got, expected)
    assert got["successes"] == expected["successes"], (got, expected)
    for field in ["success_rate", "mpc_steps_all", "mpc_steps_success"]:
        assert math.isclose(got[field], expected[field], rel_tol=0, abs_tol=1e-12), (field, got, expected)


def load_ours() -> list[dict]:
    path = CORE / "reference_shape_report/reused_ours_s100_episodes.csv"
    record(path, "per_episode_original_report_extract", method="ours")
    result = []
    with path.open(encoding="utf-8-sig", newline="") as handle:
        for r in csv.DictReader(handle):
            assert (r["planner"], r["method"], r["unit"]) == ("GD", "ours", "s100")
            success, steps = int(r["success"]), float(r["mpc_steps"])
            assert success in (0, 1) and steps.is_integer() and 1 <= steps <= 30
            assert (success and int(r["success_step"]) == steps) or (not success and steps == 30 and not r["success_step"])
            result.append({"method": "ours", "domain": r["shape"], "test_seed": int(r["seed"]),
                           "sample_idx": int(r["sample_idx"]), "success": bool(success), "mpc_steps": int(steps)})
    return result


def load_raw(method: str, root: Path, chain: str = "") -> tuple[list[dict], dict]:
    result, targets = [], {}
    for seed in SEEDS:
        for domain in DOMAINS:
            folder = root / "results/test/GD" / method / chain / f"seed_{seed}" / domain
            audit = read_json(folder / "audit.json", "per_batch_audit")
            raw = folder / "final_eval_results.npz"
            digest = record(raw, "raw_per_episode_result", method=method, test_seed=seed, domain=domain)
            assert digest == audit["result_sha256"], raw
            assert audit["phase"] == "test" and audit["optimizer"] == "GD" and audit["chain"] == 1
            assert audit["method"] == method and audit["seed"] == seed and audit["tag"] == domain
            assert audit["paired_targets_verified"] and audit["readonly_verified"] and audit["rc"] == 0
            readonly_file = "ema_audit.json" if method == "ema_slow" else "inheritance_audit.json"
            readonly = read_json(folder / readonly_file, "persistent_state_readonly_audit")
            for field in ["exact_episode_starts_verified", "final_reset_exact", "persistent_state_unchanged"]:
                assert readonly[field], (folder, field)
            assert readonly["state_written"] is False and readonly["episodes"] == 50
            if method == "ema_slow":
                assert readonly["alpha"] == 1e-4 and readonly["slow_optimizer_steps"] == 0
            with np.load(raw, allow_pickle=False) as z:
                success = z["successes"]
                action_len = z["action_len"]
                assert success.shape == action_len.shape == (50,) and success.dtype == np.bool_
                assert np.isfinite(action_len[success]).all()
                assert np.isinf(action_len[~success]).all()
                assert ((action_len[success] >= 1) & (action_len[success] <= 30)).all()
                assert np.equal(action_len[success], np.floor(action_len[success])).all()
                steps = np.where(success, action_len, 30).astype(int)
                targets[(seed, domain)] = (z["state_0"].copy(), z["state_g"].copy(), audit["source_input_sha256"])
                rows = [{"method": method, "domain": domain, "test_seed": seed, "sample_idx": i,
                         "success": bool(success[i]), "mpc_steps": int(steps[i])} for i in range(50)]
                recomputed = metrics(rows)
                assert recomputed["n"] == audit["n"] == 50
                assert recomputed["successes"] == audit["successes"]
                assert math.isclose(recomputed["mpc_steps_all"], audit["mpc_steps_all_mean"], abs_tol=1e-12)
                assert [sum(r["success"] and r["mpc_steps"] <= k for r in rows)
                        for k in range(1, 31)] == audit["success_counts_by_mpc_step"]
                result.extend(rows)
    return result, targets


def main() -> None:
    protocol = read_json(CORE / "protocol.json", "source_protocol")
    for root in [NAIVE, EMA]:
        read_json(root / "protocol.json", "source_protocol")
    comparisons = read_json(CORE / "completed_comparison.json")
    ours_summary = read_json(CORE / "reference_shape_report/reused_ours_s100_summary.json")
    core_summary = read_json(CORE / "test_summary.json")
    ema_summary = read_json(EMA / "test_summary.json")
    read_json(NAIVE / "test_summary.json", "reference_summary_three_chains_not_pooled_here")
    for name in ["provenance.json", "sources.json"]:
        read_json(CORE / "reference_shape_report" / name, "original_report_provenance")
    assert protocol["domain_order"] == DOMAINS and protocol["test_seeds"] == SEEDS
    assert protocol["checkpoint_sha256"] == "6ac64a6230d3e7918c4df3bdc5d71ecd36dc2537685dec111cfa937d9bde5947"

    rows_by_method = {"ours": load_ours()}
    states = {}
    for method, root, chain in [("adajepa_same", CORE, ""), ("naive", NAIVE, "chain_1"), ("ema_slow", EMA, "")]:
        rows_by_method[method], states[method] = load_raw(method, root, chain)
    expected_keys = {(seed, domain, i) for seed in SEEDS for domain in DOMAINS for i in range(50)}
    methods = {}
    for method, rows in rows_by_method.items():
        assert len(rows) == 1050
        assert {(r["test_seed"], r["domain"], r["sample_idx"]) for r in rows} == expected_keys
        rows.sort(key=lambda r: (r["test_seed"], DOMAINS.index(r["domain"]), r["sample_idx"]))
        by_seed = {str(seed): metrics([r for r in rows if r["test_seed"] == seed]) for seed in SEEDS}
        overall = add_test_seed_sd(metrics(rows), by_seed)
        assert overall["successes"] == EXPECTED[method][0]
        assert math.isclose(overall["mpc_steps_all"], EXPECTED[method][1], abs_tol=1e-12)
        by_domain = {}
        for domain in DOMAINS:
            subset = [r for r in rows if r["domain"] == domain]
            per_seed = {str(s): metrics([r for r in subset if r["test_seed"] == s]) for s in SEEDS}
            by_domain[domain] = add_test_seed_sd(metrics(subset), per_seed)
            by_domain[domain]["by_seed"] = per_seed
            by_domain[domain]["cumulative_success_by_mpc_step"] = curve(subset)
        methods[method] = {"label": LABELS[method], "label_zh": LABELS_ZH[method], "training_chain": 1,
                           "overall": overall, "by_domain": by_domain, "by_seed": by_seed,
                           "cumulative_success_by_mpc_step": curve(rows)}
        if method in comparisons["methods"]:
            ref = comparisons["methods"][method]
            check_summary(overall, ref["overall"])
            for domain in DOMAINS:
                check_summary(by_domain[domain], ref["by_shape"][domain])
            for seed in SEEDS:
                check_summary(by_seed[str(seed)], ref["by_test_seed"][str(seed)])
        source_summary = {"ours": ours_summary, "adajepa_same": core_summary["results"]["adajepa_same"],
                          "ema_slow": ema_summary["results"]["ema_slow"]}.get(method)
        if source_summary:
            check_summary(overall, source_summary["pooled"] if method == "ours" else source_summary["all"]["pooled"])
            if method != "ours":
                for domain in DOMAINS:
                    check_summary(by_domain[domain], source_summary[domain]["pooled"])
                    for seed in SEEDS:
                        check_summary(by_domain[domain]["by_seed"][str(seed)],
                                      source_summary[domain]["by_test_seed"][str(seed)])
                for seed in SEEDS:
                    check_summary(by_seed[str(seed)], source_summary["all"]["by_test_seed"][str(seed)])
    pair_batches = []
    for seed in SEEDS:
        for domain in DOMAINS:
            reference = states["adajepa_same"][(seed, domain)]
            for method in ["naive", "ema_slow"]:
                candidate = states[method][(seed, domain)]
                assert reference[2] == candidate[2]
                assert np.array_equal(reference[0], candidate[0]) and np.array_equal(reference[1], candidate[1])
            pair_batches.append({"test_seed": seed, "domain": domain, "n": 50,
                                 "source_input_sha256": reference[2],
                                 "state_0_and_state_g_exactly_equal": True})
    output = {
        "schema_version": 1, "created_at": datetime.now().astimezone().isoformat(),
        "title": "七形状域 GD：完整 Ours、AdaJEPA、朴素继承与 EMA 消融",
        "method_order": METHODS, "domain_order": DOMAINS, "test_seeds": SEEDS,
        "protocol": {
            "optimizer": "GD", "learning_rounds": 5, "learning_episodes_per_domain_per_round": 50,
            "learning_seed_schedule": [100, 200, 300, 1000, 1100],
            "learning_episodes_per_learned_method": 1750, "evaluation_endpoint": "round 5 / S7t5 / s100 / chain 1",
            "test_episodes_per_domain_per_seed": 50, "test_episodes_per_method": 1050,
            "test_episodes_per_domain": 150, "test_episodes_per_seed": 350,
            "training_chains_selected_per_learned_method": 1,
            "adajepa_same_policy": "Reset to the same shape pretrained checkpoint each episode; no cross-episode training.",
            "checkpoint": protocol["checkpoint"], "checkpoint_sha256": protocol["checkpoint_sha256"],
            "ours_slow_learning_rate": 1e-4, "ema_alpha": 1e-4,
            "ema_definition": "One shared slow parameter copy updated by EMA from episode-final fast parameters; no slow gradient optimizer or cross-episode replay.",
            "mpc_steps_definition": "Successful episodes use action_len/success_step; failed episodes are assigned the 30-step budget.",
            "cumulative_success_definition": "At step k, count successful episodes with success_step <= k, divided by ALL episodes in that group (including failures).",
            "heldout_policy": "Fresh same final endpoint each test episode; within-episode fast adaptation allowed; no persistent test updates.",
            "statistics": "All SD values are sample SD (ddof=1) across test seeds 2000/2100/2200, not independent training repeats. No multi-training-seed uncertainty claim.",
            "sampling_caveat": "Original H7t3 segment-level heldout protocol; 1,050 evaluation episodes must not be advertised as 1,050 independently verified unique physical tasks.",
        },
        "rows": [r for method in METHODS for r in rows_by_method[method]],
        "methods": methods,
        "pairing_validation": {
            "key_set_equal_all_four_methods": True,
            "key": ["test_seed", "domain", "sample_idx"],
            "raw_state_paired_methods": ["adajepa_same", "naive", "ema_slow"],
            "raw_state_pairing_verified_episodes_per_method": 1050,
            "raw_npz_files_sha256_and_batch_audit_verified": 63,
            "readonly_audits_verified": 63,
            "batches": pair_batches,
            "ours": {
                "data_source": "Original shape report per-episode CSV, GD / ours / s100, reused by the core ablation.",
                "all_1050_log_keys_match": True, "initial_goal_states_available_in_csv": False,
                "physical_state_pairing_independently_verified_here": False,
                "limitation": "The Ours CSV does not include state_0/state_g. Its protocol and episode keys align, but exact physical initial/goal state pairing cannot be independently rechecked from this file.",
            },
        },
        "summary_validation": {"expected_successes": {m: EXPECTED[m][0] for m in METHODS},
                               "all_expected_counts_mpc_and_saved_summaries_match": True,
                               "naive_scope": "Only chain_1; never pooled with chain_2 or chain_3."},
        "source_manifest": list(manifest.values()),
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(output, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(OUT), "rows": len(output["rows"]), "source_files": len(manifest),
                      "overall": {m: methods[m]["overall"] for m in METHODS}}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
