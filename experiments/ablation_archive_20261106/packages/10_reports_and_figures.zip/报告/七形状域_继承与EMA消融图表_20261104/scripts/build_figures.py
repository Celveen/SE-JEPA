"""Reproduce selected shape GD ablations from audited episode data, using the previous paper style."""
from pathlib import Path
import hashlib, html, json, shutil, sys, zipfile
fallback=Path(r'D:\ADAJEPA\tmp\T_figure_python_deps')
if fallback.exists():sys.path.insert(0,str(fallback))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.backends.backend_pdf import PdfPages
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1]
for name in ['figures','PNG_600dpi','SVG_矢量','preview']:(ROOT/name).mkdir(exist_ok=True)
DATA=json.loads((ROOT/'data/plot_data.json').read_text(encoding='utf-8'))
ROWS=DATA['rows']
METHODS=['adajepa_same','naive','ema_slow','ours']
DOMAIN=['I','L','square','Z','small_tee','plus','T']
DOMAIN_LABEL=dict(zip(DOMAIN,['I','L','square','Z','smallT','+','T']))
LABEL={'adajepa_same':'AdaJEPA','naive':'Naive inheritance','ema_slow':'Slow-parameter EMA','ours':'Ours'}
SHORT={'adajepa_same':'AdaJEPA','naive':'Naive\ninheritance','ema_slow':'Slow-parameter\nEMA','ours':'Ours'}
COLOR={'adajepa_same':'#7BCDBF','naive':'#CFCAC2','ema_slow':'#AAB2E8','ours':'#7FB5E8'}
STYLE={'adajepa_same':'-.','naive':'--','ema_slow':':','ours':'-'}
GD_COLOR='#708CC3'
SEEDS=[2000,2100,2200]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.labelsize':10,'axes.titlesize':12,
    'axes.linewidth':.65,'axes.edgecolor':'#555555','xtick.labelsize':9,'ytick.labelsize':9,
    'legend.fontsize':9,'text.color':'#151515','axes.labelcolor':'#151515','xtick.color':'#333333',
    'ytick.color':'#333333','pdf.fonttype':42,'ps.fonttype':42,'savefig.facecolor':'white','figure.facecolor':'white',
    'axes.facecolor':'white','svg.hashsalt':'shape-selected-ablation-20261104'})

def subset(method,domain=None,seed=None):
    return [r for r in ROWS if r['method']==method and (domain is None or r['domain']==domain) and (seed is None or r['test_seed']==seed)]

def metrics(rows):
    n=len(rows);success=sum(r['success'] for r in rows)
    return {'n':n,'successes':success,'success_rate':success/n*100,'mpc_steps':float(np.mean([r['mpc_steps'] for r in rows]))}

def summary(method,domain=None,seed=None):
    rows=subset(method,domain,seed);out=metrics(rows)
    seeds=[metrics([r for r in rows if r['test_seed']==s]) for s in SEEDS] if seed is None else []
    for key in ['success_rate','mpc_steps']:out[key+'_sd']=float(np.std([s[key] for s in seeds],ddof=1)) if seeds else 0.
    return out

def curve(method,domain=None):
    values=[]
    for seed in SEEDS:
        rows=subset(method,domain,seed)
        values.append([0.]+[100*sum(r['success'] and r['mpc_steps']<=step for r in rows)/len(rows) for step in range(1,31)])
    a=np.asarray(values);mu=a.mean(axis=0);sd=a.std(axis=0,ddof=1)
    assert np.all(np.diff(mu)>=0) and abs(mu[-1]-summary(method,domain)['success_rate'])<1e-9
    return mu,sd

assert len(ROWS)==4200
for method,expected in [('ours',855),('adajepa_same',808),('naive',679),('ema_slow',795)]:
    assert summary(method)['n']==1050 and summary(method)['successes']==expected
    assert all(len(subset(method,d))==150 for d in DOMAIN)
    assert all(len(subset(method,seed=s))==350 for s in SEEDS)

def bar_tidy(ax,ylim,ticks):
    ax.set_facecolor('#F7F7F7');ax.set_axisbelow(True)
    ax.grid(axis='y',color='#E3E3E3',ls='-',lw=.5)
    for spine in ax.spines.values():spine.set_color('#D0D0D0')
    ax.set_ylim(*ylim);ax.set_yticks(ticks);ax.tick_params(length=2.8,pad=3)

def line_tidy(ax):
    ax.set_axisbelow(True);ax.grid(color='#D0D0D0',ls=':',lw=.55)
    ax.set(xlim=(0,30),ylim=(0,100),xticks=[0,10,20,30],yticks=[0,20,40,60,80,100])
    ax.tick_params(length=2.8,pad=3)

def legend(fig,methods=METHODS,lines=False,y=.985):
    handles=[Line2D([],[],color=GD_COLOR,ls=STYLE[m],marker=None,lw=1.8 if m=='ours' else 1.5,label=LABEL[m])
             if lines else Patch(facecolor=COLOR[m],label=LABEL[m]) for m in methods]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.53,y),ncol=len(methods),frameon=False,
               columnspacing=2.5,handlelength=3.1 if lines else 2.)

def foot(fig,text,second=None,left=.065):
    compact=fig.get_size_inches()[1]<3.6
    fig.text(left,(.07 if compact else .045) if second else .035,text,fontsize=8.3,color='#555555')
    if second:fig.text(left,.02 if compact else .012,second,fontsize=8.3,color='#555555')

def draw_bar(ax,x,method,row,metric,sd=True,width=.60,fontsize=8.5,offset=None):
    value=row[metric];err=row[metric+'_sd'] if sd else 0.
    ax.bar(x,value,width,color=COLOR[method],edgecolor='white',linewidth=.6,
           yerr=err if sd else None,capsize=2,error_kw={'elinewidth':.65,'capthick':.65})
    if offset is None:offset=(ax.get_ylim()[1]-ax.get_ylim()[0])*.022
    ax.text(x,value+err+offset,f'{value:.1f}' if metric=='success_rate' else f'{value:.2f}',ha='center',va='bottom',fontsize=fontsize)

def draw_curve(ax,method,domain=None,alpha=.085):
    mu,sd=curve(method,domain)
    ax.fill_between(range(31),np.clip(mu-sd,0,100),np.clip(mu+sd,0,100),color=GD_COLOR,alpha=alpha,lw=0)
    ax.plot(range(31),mu,color=GD_COLOR,ls=STYLE[method],marker=None,lw=1.8 if method=='ours' else 1.5,gid=method)

MANIFEST=[]
COMBINED=ROOT/'七形状域_继承与EMA消融图表.pdf'
PDF=PdfPages(COMBINED)
COMMON=('Seven shape domains, GD. Original shape pretrained checkpoint. Trained methods use the S7t5/s100 chain '
        'after five rounds; naive inheritance uses chain 1 only. H7t3 test seeds 2000, 2100, 2200; '
        '50 tasks per domain per seed, 1050 tests per method. Ours is the original full method with slow Adam lr=1e-4; '
        'EMA alpha=1e-4 is an interpolation coefficient. AdaJEPA resets to the same pretrained checkpoint each episode. '
        'Test-time within-episode fast adaptation is retained; no persistent test-time updates. '
        'Where shown, error bars and shading are sample SD across three test seeds, not training repeats or confidence intervals. '
        'Mean MPC includes all episodes, with failures counted as 30. Ours is reused from the original report; '
        'its episode CSV does not contain state tensors, so physical-state pairing with Ours is not independently asserted here.')

def save(fig,stem,title,title_zh,caption,caption_zh):
    fig.canvas.draw();renderer=fig.canvas.get_renderer();w,h=fig.canvas.get_width_height()
    outside=[]
    for t in fig.findobj(matplotlib.text.Text):
        if not t.get_visible() or not t.get_text():continue
        b=t.get_window_extent(renderer)
        if b.x0<-.5 or b.y0<-.5 or b.x1>w+.5 or b.y1>h+.5:outside.append(t.get_text())
    assert not outside,(stem,outside)
    for ax in fig.axes:
        for line in ax.lines:
            if line.get_gid()=='ours':assert line.get_linestyle()=='-' and line.get_marker() in [None,'None','',' ']
            if line.get_gid()=='adajepa_same':assert line.get_linestyle()=='-.'
    path=ROOT/'figures'/f'{stem}.pdf'
    fig.savefig(path,metadata={'Title':title,'Subject':caption+' '+COMMON,'Creator':'Python / Matplotlib'})
    PDF.savefig(fig)
    fig.savefig(ROOT/'preview'/f'{stem}.png',dpi=180)
    fig.savefig(ROOT/'PNG_600dpi'/f'{stem}.png',dpi=600)
    fig.savefig(ROOT/'SVG_矢量'/f'{stem}.svg')
    assert len(PdfReader(path).pages)==1
    MANIFEST.append({'number':len(MANIFEST)+1,'stem':stem,'title':title,'title_zh':title_zh,'caption':caption,
                     'caption_zh':caption_zh,'text_bounds_verified':True,'pdf_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    plt.close(fig);print('Saved',stem,flush=True)

# 1. Main outcome, same typography and quantified bars as prior MPC figures.
fig,axs=plt.subplots(1,2,figsize=(13.2,4.25));fig.subplots_adjust(left=.065,right=.99,top=.78,bottom=.24,wspace=.20)
legend(fig)
for ax,metric,title,ylim,ticks in [(axs[0],'success_rate','(a) Held-out success rate',(0,110),range(0,101,20)),
                                (axs[1],'mpc_steps','(b) Mean MPC steps (all episodes)',(0,21),range(0,21,5))]:
    bar_tidy(ax,ylim,ticks)
    for i,m in enumerate(METHODS):draw_bar(ax,i,m,summary(m),metric,fontsize=10)
    ax.set_xticks(range(4),[SHORT[m] for m in METHODS]);ax.set_title(title,loc='left',pad=10)
    ax.set_ylabel('Success Rate (%)' if metric=='success_rate' else 'MPC Steps')
foot(fig,'1,050 test episodes per method. Error bars: +/- 1 SD across test seeds 2000/2100/2200.',
     'One learning chain for trained methods; AdaJEPA resets per episode. Failures count as 30 MPC steps.')
save(fig,'01_overall_success_and_mpc','Shape GD ablation - overall outcomes','整体成功率与平均MPC步数',
     'Overall held-out success and mean all-episode MPC steps, including failures.','四种方法各1050回合；左图为成功率，右图为所有回合平均MPC步数，失败按30步计入。误差棒为三个测试种子的标准差。')

# 2-3. Per-domain metrics.
for num,metric,title,zh in [(2,'success_rate','Held-out success by shape','七形状域成功率对比'),(3,'mpc_steps','Mean MPC steps by shape','七形状域平均MPC步数对比')]:
    fig,ax=plt.subplots(figsize=(13.2,4.1));fig.subplots_adjust(left=.065,right=.99,top=.79,bottom=.21);legend(fig)
    maximum=max(summary(m,d)[metric]+summary(m,d)[metric+'_sd'] for m in METHODS for d in DOMAIN)
    top=max(110,maximum+7) if metric=='success_rate' else max(32,maximum+3)
    bar_tidy(ax,(0,top),range(0,101,20) if metric=='success_rate' else range(0,31,5))
    for j,m in enumerate(METHODS):
        for i,d in enumerate(DOMAIN):draw_bar(ax,i+(j-1.5)*.20,m,summary(m,d),metric,width=.19,fontsize=7.8,offset=1.3 if metric=='success_rate' else .55)
    ax.set_xticks(range(7),[DOMAIN_LABEL[d] for d in DOMAIN]);ax.set_xlim(-.6,6.6)
    ax.set_ylabel('Success Rate (%)' if metric=='success_rate' else 'MPC Steps');ax.set_title(title+' - GD',loc='left',pad=10)
    foot(fig,'150 test episodes per shape and method. Error bars: +/- 1 SD across three test seeds.',
         'Single learning chain; identical H7t3 evaluation protocol. Failures count as 30 MPC steps.')
    save(fig,f'{num:02d}_per_shape_{metric}',title,zh,
         'Per-shape comparison with equal episode counts and test-seed standard deviations.',
         '每个形状每种方法150回合，三个测试种子各50回合；误差棒为测试种子间标准差。')

# 4. All-method cumulative success, retaining the original GD planner blue.
fig,ax=plt.subplots(figsize=(10.2,4.3));fig.subplots_adjust(left=.085,right=.98,top=.79,bottom=.21);legend(fig,lines=True)
line_tidy(ax)
for m in METHODS:draw_curve(ax,m,alpha=.045)
ax.set_xlabel('MPC Step');ax.set_ylabel('Success Rate (%)');ax.set_title('Cumulative held-out success - GD',loc='left',pad=10)
foot(fig,'1,050 test episodes per method. Shading: +/- 1 SD across three test seeds.',
     'Curves count successful episodes only; unsuccessful episodes remain in the denominator.',left=.085)
save(fig,'04_cumulative_success_all','Cumulative success across MPC steps','整体累计成功率曲线',
     'Cumulative success probability up to each MPC step; failures stay in the denominator.',
     '横轴为MPC步数，纵轴为不超过该步数已成功的回合占全部回合的比例；第30步终点等于最终成功率。Ours为无标记纯实线。')

# 5-7. Separate corresponding ablation panels versus the same full Ours baseline.
for num,m,zh in [(5,'naive','朴素继承与Ours：七域累计成功率'),(6,'ema_slow','慢参数EMA与Ours：七域累计成功率'),(7,'adajepa_same','同权重AdaJEPA与Ours：七域累计成功率')]:
    fig,axs=plt.subplots(1,7,figsize=(13.5,3.3),sharey=True)
    fig.subplots_adjust(left=.055,right=.993,top=.70,bottom=.29,wspace=.09)
    legend(fig,[m,'ours'],lines=True,y=1.0)
    for i,(ax,d) in enumerate(zip(axs,DOMAIN)):
        line_tidy(ax)
        draw_curve(ax,m,domain=d);draw_curve(ax,'ours',domain=d)
        ax.set_title(DOMAIN_LABEL[d],pad=7);ax.set_xticks([10,20,30]);ax.set_xlabel('MPC Step',labelpad=3)
        ax.tick_params(labelleft=i==0)
        if i==0:ax.set_ylabel('Success Rate (%)')
    foot(fig,'150 test episodes per shape and method. Shading: +/- 1 SD across test seeds 2000/2100/2200.',
         'Ours: original full method, slow lr = 1e-4. Single learning chain; all curves use the GD planner.',left=.055)
    save(fig,f'{num:02d}_{m}_vs_ours',LABEL[m]+' versus Ours - seven shapes',zh,
         'Separate per-shape cumulative curves for '+LABEL[m]+' and the original full Ours.',
         LABEL[m]+'与完整Ours逐域比较；每域各150回合。Ours始终为纯实线，另一方法用既定线型区分。')

# 8. Show all three test blocks without treating them as learned model replicates.
fig,axs=plt.subplots(1,2,figsize=(13.2,4.15));fig.subplots_adjust(left=.065,right=.99,top=.78,bottom=.22,wspace=.18);legend(fig)
for ax,metric,title,ylim,ticks in [(axs[0],'success_rate','(a) Success rate by test seed',(0,110),range(0,101,20)),
                                 (axs[1],'mpc_steps','(b) Mean MPC steps by test seed',(0,21),range(0,21,5))]:
    bar_tidy(ax,ylim,ticks)
    for j,m in enumerate(METHODS):
        for i,s in enumerate(SEEDS):draw_bar(ax,i+(j-1.5)*.20,m,summary(m,seed=s),metric,sd=False,width=.19,fontsize=8)
    ax.set_xticks(range(3),[str(s) for s in SEEDS]);ax.set_xlabel('Held-out test seed');ax.set_title(title,loc='left',pad=10)
    ax.set_ylabel('Success Rate (%)' if metric=='success_rate' else 'MPC Steps');ax.set_xlim(-.6,2.6)
foot(fig,'350 episodes per method and test seed. These are test blocks, not independent learning chains.',
     'Raw block values are shown without error bars. Failures count as 30 MPC steps.')
save(fig,'08_test_seed_comparison','Results by held-out test seed','三个独立测试种子的结果',
     'Raw success and MPC means for each held-out test seed; no error bars.',
     '每个测试种子每种方法350回合。这里只比较测试分块，不能解释为三次独立训练重复；因此本图直接标数值，不加误差棒。')
PDF.close();assert len(PdfReader(COMBINED).pages)==8

STYLE_META={'source_style':'20张图表_独立原图_20261027 and 七视觉域_仿形状版20图_20261030',
    'bar_colors':COLOR,'line_color':GD_COLOR,'line_styles':STYLE,'ours_markers':None,
    'font':'DejaVu Sans','pdf_fonttype':42,'png_dpi':600,'error_bars':'sample SD across three test seeds (ddof=1), not learning repeats or CI'}
(ROOT/'data/style.json').write_text(json.dumps(STYLE_META,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'figure_manifest.json').write_text(json.dumps({'protocol':COMMON,'figures':MANIFEST,'style':STYLE_META},ensure_ascii=False,indent=2),encoding='utf-8')
summary_rows=[{'method':m,'label':LABEL[m],**summary(m)} for m in METHODS]
(ROOT/'data/summary.json').write_text(json.dumps(summary_rows,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'English_captions.txt').write_text(COMMON+'\n\n'+'\n\n'.join(f"Figure {x['number']}: {x['title']}\n{x['caption']}" for x in MANIFEST),encoding='utf-8')

cards=[]
for f in MANIFEST:
    stem=f['stem'];cards.append(f'''<article><h2>{f['number']:02d} · {html.escape(f['title_zh'])}</h2><img src="preview/{stem}.png" alt="{html.escape(f['title'])}"><p>{html.escape(f['caption_zh'])}</p><nav><a href="figures/{stem}.pdf">PDF</a><a href="PNG_600dpi/{stem}.png">600 dpi 原图</a><a href="SVG_矢量/{stem}.svg">SVG 矢量图</a></nav></article>''')
table=''.join(f"<tr><td>{LABEL[r['method']]}</td><td>{r['successes']}/{r['n']}</td><td>{r['success_rate']:.2f}%</td><td>{r['mpc_steps']:.3f}</td></tr>" for r in summary_rows)
page=f'''<!doctype html><html lang="zh"><meta charset="utf-8"><title>七形状域 · 继承与EMA消融图表</title><style>body{{max-width:1320px;margin:40px auto;padding:0 24px;font:16px/1.6 system-ui;color:#243447;background:#f4f6f8}}h1{{font-size:30px}}article,section{{background:white;padding:24px;border-radius:10px;margin:24px 0}}h2{{font-size:20px}}img{{width:100%;height:auto}}nav{{display:flex;gap:24px}}a{{color:#386b99}}table{{border-collapse:collapse;width:100%}}td,th{{padding:10px;border-bottom:1px solid #e4e7eb;text-align:left}}small{{color:#637587}}</style><h1>七形状域 · 继承与EMA消融图表</h1><p>GD规划器 · 朴素继承第1链、慢参数EMA、同权重AdaJEPA，与原完整Ours对照。</p><nav><a href="{COMBINED.name}">下载8页PDF合集</a><a href="data/plot_data.json">逐回合绘图数据</a><a href="scripts/build_figures.py">Python绘图源码</a></nav><section><table><tr><th>方法</th><th>成功回合</th><th>成功率</th><th>平均MPC步数</th></tr>{table}</table><p>各方法1050个测试回合，失败按30步计入平均MPC。学习型方法均使用S7t5/s100单链第5轮；AdaJEPA每回合恢复相同的形状域预训练权重。Ours慢学习率1e-4，EMA系数α=1e-4；两者含义不同。</p><p>误差棒／阴影：测试种子2000、2100、2200之间的样本标准差，不是三条学习链的波动，也不是置信区间。朴素继承仅取第1链，不混用三链汇总结果。</p><small>数据依据：AdaJEPA、朴素继承和EMA来自原始NPZ并核验状态配对；Ours沿用原报告逐回合日志，该CSV不含状态张量，本次不独立声称核验了它与其余组的物理状态配对。完整来源和校验记录见data/plot_data.json。正在运行的熟悉度消融不纳入本套图。</small></section>{''.join(cards)}</html>'''
(ROOT/'图表索引.html').write_text(page,encoding='utf-8')
(ROOT/'README.txt').write_text('七形状域GD：朴素继承、慢参数EMA、同初始权重AdaJEPA与完整Ours对照。\n8张独立矢量PDF、600dpi PNG、SVG，以及8页PDF合集、中文索引、逐回合JSON数据、Python源码。\nPython依赖：numpy、matplotlib、pypdf。运行 scripts/build_figures.py 可复现绘图。\n各组1050测试回合；朴素继承取第1链；Ours沿用原S7t5/s100结果。失败计30步；误差棒为3测试种子的样本SD，不是训练重复。\n',encoding='utf-8')
print(json.dumps({'figures':len(MANIFEST),'combined_pdf':str(COMBINED),'summary':summary_rows},ensure_ascii=False),flush=True)
