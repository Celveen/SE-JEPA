$ErrorActionPreference = 'Stop'
$taskRoot = 'D:\ADAJEPA\报告\消融实验图文报告_20261105'
$wordApp = $null
$reportDoc = $null
try {
    $wordApp = New-Object -ComObject Word.Application
    $wordApp.Visible = $false
    $wordApp.DisplayAlerts = 0
    $reportDoc = $wordApp.Documents.Open((Join-Path $taskRoot '消融实验图文报告.docx'), $false, $true)
    $reportDoc.Repaginate()
    $pageCount = $reportDoc.ComputeStatistics(2)
    $reportDoc.ExportAsFixedFormat((Join-Path $taskRoot '消融实验图文报告.pdf'), 17)
    [pscustomobject]@{pages=$pageCount; renderer='Microsoft Word native PDF export'} | ConvertTo-Json -Compress
} finally {
    if ($null -ne $reportDoc) { $reportDoc.Close($false); [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($reportDoc) }
    if ($null -ne $wordApp) { $wordApp.Quit(); [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($wordApp) }
}
