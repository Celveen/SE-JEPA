from pathlib import Path
import csv
import json
from statistics import stdev
from report_layout import Report, ROOT

S = json.loads((ROOT/'data/shape_audit.json').read_text(encoding='utf-8'))
V = json.loads((ROOT/'data/visual_audit.json').read_text(encoding='utf-8'))
RUN = json.loads((ROOT/'data/running_snapshot.json').read_text(encoding='utf-8'))
M = {m['id']: m for m in S['methods']}
O = M['ours_s100']
DOM = S['domain_order']
DL = {'I':'I','L':'L','square':'Square','Z':'Z','small_tee':'Small T','plus':'Plus','T':'T'}
LABEL = {'ours_s100':'Ours 1e-4','adajepa_same':'同权重 AdaJEPA','naive_s100':'朴素继承','ema_slow':'EMA α=1e-4','shared_slow':'共享慢学习器','no_maturity_read':'关闭成熟度读取门控','no_familiarity':'关闭熟悉度读写保护','slow_lr_low':'慢学习率 5e-5','slow_lr_high':'慢学习率 2e-4','slow_lr_3e4':'慢学习率 3e-4','slow_lr_5e4':'慢学习率 5e-4','slow_lr_1e2':'慢学习率 0.01'}
STRUCT = ['ours_s100','adajepa_same','naive_s100','ema_slow','shared_slow','no_maturity_read','no_familiarity']
LR = ['slow_lr_low','ours_s100','slow_lr_high','slow_lr_3e4','slow_lr_5e4','slow_lr_1e2']
LRT = ['5e-5','1e-4','2e-4','3e-4','5e-4','0.01']
PRI = STRUCT + [x for x in LR if x != 'ours_s100']

def pct(m): return f"{m['success_rate']*100:.2f}%"
def cnt(m): return f"{m['successes']}/{m['n']}"
def num(x): return '未提供' if x is None else f'{x:.2f}'
def mpc(m): return m.get('mpc_steps_all', m.get('mpc_steps_all_mean'))
def mpcs(m): return m.get('mpc_steps_success', m.get('mpc_steps_success_mean'))
def diff(m, base=O['overall']): return 100*(m['success_rate']-base['success_rate'])
def signed(x): return f'{x:+.2f}'
def plot(r, name, caption, width=6.8): r.figure(ROOT/'figures'/f'{name}.png', caption, width)
def vgroup(planner, lr): return next(g for g in V['groups'] if g['planner']==planner and g['method']=='v6a' and g['slow_lr']==lr)

r = Report()
r.page('AdaJEPA持续学习消融实验图文报告','七形状域机制消融与七视觉域慢学习率对比',cover=True)
r.p('汇总日期 2026年11月5日。报告覆盖已完成的朴素继承、慢参数 EMA、同权重 AdaJEPA、共享慢学习器、成熟度读取门控、熟悉度读写保护和慢学习率实验。图表与表格均由已保存的实验数据生成。')
r.p('主要观察：完整 Ours 在匹配的形状单链测试中优于朴素继承、当前 EMA 设置及同权重 AdaJEPA；共享慢学习器与 Ours 非常接近。关闭熟悉度读写保护提高了总成功率，但各形状收益并不一致。学习率增大没有带来跨规划器、跨域的一致提升。')
r.h('关键结果')
rows=[]
for k in ['ours_s100','naive_s100','ema_slow','adajepa_same','shared_slow','no_familiarity']:
    x=M[k]['overall']; rows.append([LABEL[k],cnt(x),pct(x),num(mpc(x)),signed(diff(x))])
r.table(['形状 GD 匹配单链','成功数 / 测试数','成功率','平均 MPC','差值 pp'],rows,[2.1,1.4,1.0,1.1,1.3])
r.p('差值均为“该组减 Ours”。pp 表示百分点。MPC 使用全部测试回合，数值越小越好；成功率越大越好。这里的多数消融只有一条学习链，不能将三个测试种子解释为三次独立训练。')
r.h('阅读方式')
r.p('先阅读实验协议与结构总览，再按每项消融查看图、逐域明细和结论边界。后半部分给出六档慢学习率、三链朴素继承、视觉 GD 与 CEM 对比，以及逐测试种子和学习阶段附录。报告末尾列出尚在运行的实验与全部数据来源。')
r.p('附件提供逐回合 CSV、汇总 JSON、每张图的矢量 PDF 和 SVG，以及高分辨率 PNG。学习过程的在线成功率与第五轮权重的独立测试结果分开报告。')

r.page('实验协议与比较条件')
r.table(['项目','七形状域主体消融','七视觉域学习率比较'],[
 ['规划器','GD','GD 与 CEM 分开比较'],
 ['学习规模','每链 5轮 × 7域 × 50 = 1750','每规划器每学习率 3链，共5250'],
 ['测试规模','每链 3种子 × 7域 × 50 = 1050','每规划器每学习率3链，共3150'],
 ['比较终点','第五轮终态','每条链的第五轮终态均测试'],
 ['跨回合状态','测试期保持只读','测试期保持只读'],
 ['回合内快适应','保留，Frozen参考组除外','保留，Frozen参考组除外'],
 ['测试种子','2000 / 2100 / 2200','2000 / 2100 / 2200'],
 ['主比较初始权重','Ours及新增消融相同','两学习率的Ours相同'],
], [1.2,2.85,2.85],size=9.5)
r.h('学习链与域顺序')
r.table(['学习链','轮1','轮2','轮3','轮4','轮5'],[
 ['链1 起始s100',100,200,300,1000,1100],['链2 起始s400',400,500,600,1200,1300],['链3 起始s700',700,800,900,1400,1500]], [1.9,1,1,1,1,1])
r.p('形状顺序为 I、L、Square、Z、Small T、Plus、T。视觉顺序为原始视觉、模糊、椒盐噪声、暗光、红色智能体、红色物体、红色目标。单链主体采用链1；三链扩展单独报告。')
r.h('任务匹配与指标定义')
r.p('形状协议采用片段索引排除，未声称底层轨迹或三个测试块完全互斥。视觉协议额外按来源轨迹编号ep_idx排除学习轨迹，并保证三个测试块互不重复：学习覆盖466条来源轨迹，测试为三个各50条的互斥块。视觉两学习率6300个配对评测的初始和目标状态已核验一致。形状新增消融之间也核验状态一致；原Ours历史CSV缺少原始状态，其逐回合变化仅作同协议键匹配统计。')
r.p('成功率按原始successes标志重算，第30次MPC成功仍算成功。MPC是重规划次数，不是原始环境控制步数。失败回合按30次MPC计入全部回合均值。成功回合均值另外给出，但不同方法的成功子集不同，不能单独据此判断效率。')

r.page('方法模块与消融定义')
r.p('完整 Ours 以回合内快速适应收集经验，通过分域慢预测器和跨回合回放保留知识；熟悉度、成熟度及拒收等规则影响知识的读取和巩固。下表按实际代码定义消融，避免将多个不同的关闭操作混称。')
r.table(['方法','跨回合保留什么','慢更新与保护'],[
 ['完整 Ours','分域慢预测器及经验','回放梯度训练；熟悉度与成熟度等规则'],
 ['同权重 AdaJEPA','无持续慢记忆','每回合从相同初始模型开始快适应'],
 ['朴素继承','快适应的编码器与预测器参数','直接继承回合末参数；无慢库与跨回合回放'],
 ['慢参数 EMA','快适应参数的指数滑动平均','每回合EMA；无慢梯度训练、分域和门控'],
 ['共享慢学习器','单个共享预测器与全局回放','保留梯度训练和主要保护；取消分域分配、合并、吸收'],
 ['关闭成熟度读取门控','同完整 Ours','只放开读取候选；写入、加入、吸收成熟度保留'],
 ['关闭熟悉度读写保护','同完整 Ours','放开熟悉度对读取与直接写入的限制；其他规则保留'],
 ['慢学习率消融','同完整 Ours','只改慢优化器学习率'],
], [1.55,2.05,3.3],size=9.4)
r.h('参数范围与控制变量')
r.p('形状基线慢学习率为1e-4，慢更新15步、批量8。回合内快更新沿用原配置：预测器学习率5e-4、编码器1e-5、每次重规划一次更新、recent5缓存。GD规划最多30次MPC，每次动作优化100步、学习率0.1。')
r.p('EMA 更新的是原快适应所涉及的编码器与预测器参数；完整 Ours 的慢梯度路径主要训练预测器。因此 EMA 与 Ours 同时涉及更新规则、参数范围和记忆结构差异，不是仅改变一个数值的对照。')
r.p('关闭熟悉度写入保护不等于每回合强制写入；pending形成、拒收、成熟度等仍可能阻止巩固。熟悉回合在完整方法中也可能触发旧经验的周期性吸收，不能把“直接写入受保护”写成“该回合所有慢更新都停止”。')

r.page('七形状域结构消融总览')
plot(r,'01_structure_overview','匹配单链的结构消融。每组1050次测试；误差线表示测试种子块之间的标准差，不是独立学习重复的不确定性。')
rows=[]
for k in STRUCT:
    x=M[k]['overall'];rows.append([LABEL[k],cnt(x),pct(x),signed(diff(x)),num(mpc(x)),num(mpcs(x))])
r.table(['方法','成功数 / N','成功率','差值 pp','MPC全部','MPC成功'],rows,[1.95,1.1,.95,.85,1.05,1.0],size=9.0)
r.p('朴素继承落后幅度最大；共享慢学习器与 Ours 的差距很小。熟悉度联合关闭的总成绩更高，但是否稳定、主要来自读还是写，仍需结合在跑拆分实验和学习重复判断。数据来源 S01、S02、S03、S06。')

descriptions = {
 'naive_s100': ('朴素继承消融','02_naive_s100_vs_ours','快适应涉及的编码器与预测器参数跨回合、域和轮直接继承；无领域库、路由、慢训练和跨回合回放。缓存按原方法重置，优化器动量不跨回合继承。','本组比 Ours 少成功176回合，差16.76个百分点。直接继承在当前协议下表现较弱；仅凭第五轮终点还不能区分遗忘、参数漂移与优化不稳定各自的贡献。'),
 'ema_slow': ('慢参数 EMA 消融','03_ema_slow_vs_ours','每回合结束时，以α=1e-4将回合末快参数融入慢参数；下一回合从慢参数开始。没有额外慢优化器或跨回合回放。','本组比 Ours 少成功60回合。α=1e-4的EMA半衰期约6931回合；若每回合都更新，1750回合后初始慢参数的显式递推系数约0.839。该结果评价的是这一设置，不能据此概括EMA路线无效。'),
 'adajepa_same': ('同权重 AdaJEPA 对照','04_adajepa_same_vs_ours','使用与 Ours 相同的形状初始权重，每个测试回合从初始模型开始，保留原 AdaJEPA 回合内快速适应，不使用跨回合慢记忆。','Ours多成功47回合，提升4.48个百分点。这是同初始权重的主要方法对照；原报告中使用另一权重的AdaJEPA结果仅放在参考附录。'),
 'shared_slow': ('单一共享慢学习器消融','05_shared_slow_vs_ours','用一个共享慢预测器和全局回放代替多域库，保留熟悉度、成熟度、拒收和梯度更新；取消分域分配、pending、合并与吸收。','本组仅比 Ours 少成功2回合，差0.19个百分点。当前单链结果尚不能证明多慢学习器必要，也不能证明两者等效；需要旧域重访和多学习链比较区分其适用条件。'),
 'no_maturity_read': ('成熟度读取门控消融','06_no_maturity_read_vs_ours','允许尚未满足成熟条件的慢学习器参与读取候选；写入、加入、吸收阶段的成熟度检查保持不变。','关闭后少成功6回合，差0.57个百分点。该实验只检验读取候选的成熟限制，不能扩展解释为全部成熟度机制的作用。'),
 'no_familiarity': ('熟悉度读写联合关闭消融','07_no_familiarity_vs_ours','同时取消熟悉度对慢学习器读取和直接巩固的保护，保留分域记忆、成熟度、拒收与其他更新规则。','关闭后多成功18回合，提升1.71个百分点，平均MPC减少0.47。Small T、Square和Z改善，I与T下降，表明总体收益掩盖了域间差异。'),
}
for k in ['naive_s100','ema_slow','adajepa_same','shared_slow','no_maturity_read','no_familiarity']:
    title, fig, desc, interp=descriptions[k]
    r.page(title)
    r.p(desc)
    plot(r,fig,'逐域成功率与全部回合平均MPC。每域每法150次测试；Ours为同一s100第五轮参考。')
    rows=[]
    for d in DOM:
        a=M[k]['domains'][d]; b=O['domains'][d]
        rows.append([DL[d],cnt(b),cnt(a),pct(a),signed(diff(a,b)),num(mpc(b)),num(mpc(a))])
    r.table(['形状','Ours成功/N','本组成功/N','本组成功率','差值 pp','Ours MPC','本组 MPC'],rows,[.7,1.15,1.15,1.05,.9,.95,1.0],size=9)
    r.p(interp)

r.page('熟悉度保护的逐域变化')
plot(r,'09_familiarity_domain_changes','关闭熟悉度读写保护减完整Ours。成功率差值大于0有利，MPC差值小于0有利；差值图以0为参照。')
pair=M['no_familiarity']['pairing_vs_ours']
rows=[]
for d in DOM:
    p=pair['domains_key_matched_changes'][d]
    a=M['no_familiarity']['domains'][d];b=O['domains'][d]
    rows.append([DL[d],p['ours_failure_ablation_success'],p['ours_success_ablation_failure'],a['successes']-b['successes'],signed(diff(a,b)),signed(mpc(a)-mpc(b))])
r.table(['形状','失败变成功','成功变失败','净成功变化','成功率差 pp','MPC差值'],rows,[.85,1.2,1.2,1.2,1.25,1.2],size=9.2)
r.p('同协议键匹配后，74个回合由失败变成功，56个由成功变失败，净增加18个。原 Ours CSV 不含原始状态，本表只描述种子、形状与样本编号一致的结果变化，不声称本次已逐状态验证这一历史对照。')
r.p('联合关闭不能识别读保护、写保护和两者相互作用的独立贡献。GD关读、GD关写和CEM关读写仍在运行，不能将当前学习成功率作为最终独立测试结果。')

r.page('七形状域慢学习率敏感性')
plot(r,'08_slow_learning_rate','六档慢学习率的第五轮独立测试。横轴为实际学习率的对数尺度，Ours默认值1e-4为参照；每档只有一条学习链。')
rows=[]
for k,lr in zip(LR,LRT):
    a=M[k]['overall']; rows.append([lr,cnt(a),pct(a),signed(diff(a)),num(mpc(a)),num(mpcs(a))])
r.table(['慢学习率','成功数 / N','成功率','差值 pp','MPC全部','MPC成功'],rows,[1.1,1.3,1.1,1.1,1.15,1.15])
r.p('本次六档中，2e-4观察到最高成功率82.38%，比默认1e-4高0.95个百分点；继续增大并未提高效果。该排序来自同一独立测试集上的探索，不能将最高档位直接称为已验证的通用最优参数。')
r.p('0.01与同权重AdaJEPA的1050个successes和MPC步数逐元素一致，但动作仅18/21批完全一致。该设置测试中只有4/1050回合的路由曾选择慢学习器；这支持“慢知识采用很少”的解释，不能写成没有训练或完全没有读取。')

r.page('慢学习率的完整逐域明细')
r.p('每个单元格对应150次测试。上表为成功数与成功率，下表为全部回合平均MPC；默认1e-4列对应同一完整Ours。')
r.h('成功数及成功率')
rows=[[DL[d]]+[f"{M[k]['domains'][d]['successes']}/150\n{pct(M[k]['domains'][d])}" for k in LR] for d in DOM]
r.table(['形状']+LRT,rows,[.72]+[1.03]*6,size=9)
r.h('全部回合平均 MPC')
r.table(['形状']+LRT,[[DL[d]]+[num(mpc(M[k]['domains'][d])) for k in LR] for d in DOM],[.72]+[1.03]*6,size=9.3)
r.p('不同学习率的影响主要体现在部分困难形状，而不是各域同步变化。解释学习率收益时，应同时检查逐域成功数、慢学习器是否实际被读取以及总计算开销。以上为描述性比较，无显著性标记。')

r.page('三条学习链的朴素继承比较')
r.p('本页使用Ours与朴素继承各三条学习链的全部第五轮终态，避免挑选最好的一条链。两方法各3150次测试，三条链分别从s100、s400、s700开始。')
rows=[]
for seed in [100,400,700]:
    a=M[f'ours_s{seed}']['overall'];b=M[f'naive_s{seed}']['overall']
    rows.append([f's{seed}',cnt(a),pct(a),cnt(b),pct(b),num(mpc(a)),num(mpc(b))])
a=M['ours_all3']['overall'];b=M['naive_all3']['overall']
rows.append(['三链合计',cnt(a),pct(a),cnt(b),pct(b),num(mpc(a)),num(mpc(b))])
r.table(['学习链','Ours成功/N','Ours成功率','朴素成功/N','朴素成功率','Ours MPC','朴素 MPC'],rows,[.85,1.1,.95,1.1,.95,.95,1.0],size=9)
plot(r,'12_mpc_budget_success','匹配s100测试中，在不同MPC预算内完成任务的比例。分母固定为全部1050次测试；曲线终点是最终成功率。Ours为纯实线无点。')
r.p('三条链中朴素继承均低于对应Ours。预算曲线补充说明成功发生得早还是晚，但MPC次数不等同于运行秒数，不直接代表GD与CEM之间的计算成本。')

for planner,fig in [('GD','10_visual_gd_learning_rate'),('CEM','11_visual_cem_learning_rate')]:
    a=vgroup(planner,1e-4);b=vgroup(planner,2e-4)
    da={x['domain']:x for x in a['by_domain']};db={x['domain']:x for x in b['by_domain']}
    r.page(f'七视觉域 {planner} 慢学习率比较')
    r.p(f"每档3条学习链、共3150次第五轮独立测试。1e-4为{cnt(a['overall'])}，2e-4为{cnt(b['overall'])}；成功率变化{signed(diff(b['overall'],a['overall']))}个百分点。两档具有相同初始权重和已核验一致的初始与目标状态。")
    plot(r,fig,'逐视觉域两档慢学习率对照。每域每档450次执行；误差线表示三条学习链间标准差。',width=6.7)
    rows=[]
    for d in V['domain_order']:
        x,y=da[d],db[d]
        rows.append([V['domain_labels'][d],cnt(x),cnt(y),signed(diff(y,x)),num(mpc(x)),num(mpc(y))])
    x,y=a['overall'],b['overall']
    rows.append(['全部',cnt(x),cnt(y),signed(diff(y,x)),num(mpc(x)),num(mpc(y))])
    r.table(['视觉域','1e-4成功/N','2e-4成功/N','差值 pp','MPC 1e-4','MPC 2e-4'],rows,[1.35,1.2,1.2,1,1.05,1.1],size=9)
    p=V['paired_comparison'][planner]['overall']
    r.p(f"配对变化：失败变成功{p['fail_to_success']}回合，成功变失败{p['success_to_fail']}回合。" + ('GD总体变化很小，红色目标改善同时伴随红色智能体下降，不能概括为所有视觉域受益。' if planner=='GD' else 'CEM整体成功率下降且平均MPC增加，形状GD观察到的2e-4优势没有直接迁移到该设置。'))

r.page('视觉结果的学习链和测试种子分解')
r.p('上表按独立学习链展开，下表按测试种子块展开。二者代表不同的变异来源；测试种子变化不能替代学习过程的重复。每个单元格为成功率与全部回合平均MPC。')
groups=[vgroup(p,lr) for p in ['GD','CEM'] for lr in [1e-4,2e-4]]
headers=['设置','s100','s400','s700','合计成功/N']
rows=[]
for g in groups:
    rows.append([f"{g['planner']} {g['slow_lr']:.0e}"]+[f"{pct(x)}\nMPC {num(mpc(x))}" for x in g['by_chain']]+[cnt(g['overall'])])
r.table(headers,rows,[1.3,1.4,1.4,1.4,1.4],size=9.5)
r.h('按测试种子块汇总')
rows=[]
for g in groups:
    rows.append([f"{g['planner']} {g['slow_lr']:.0e}"]+[f"{cnt(x)}\n{pct(x)} / {num(mpc(x))}" for x in g['by_test_seed']])
r.table(['设置','测试seed 2000','测试seed 2100','测试seed 2200'],rows,[1.35,1.85,1.85,1.85],size=9.4)
r.h('比较边界')
r.p('视觉测试的基础任务会在不同外观和不同学习链下重复执行。3150是执行次数，不应直接当作3150个彼此完全独立的新任务做显著性检验。报告保留逐任务配对记录，同时按链报告差异。')
r.p('原视觉报告中的Frozen和AdaJEPA使用另一初始权重，Ours使用pushobj_T16k_bias_e3。两学习率Ours之间可直接比较；与这些原始基线之间的差异不能全部归因于持续学习机制。')

for part, keys in enumerate([PRI[:6],PRI[6:]],1):
    r.page(f'形状测试种子明细 第{part}部分')
    r.p('每个测试种子包含七形状各50回合，共350回合。主表每组对应一条学习链的第五轮终态；同权重AdaJEPA无需跨回合学习。')
    rows=[]
    for k in keys:
        for seed in ['2000','2100','2200']:
            a=M[k]['test_seeds'][seed]
            rows.append([LABEL[k],seed,cnt(a),pct(a),num(mpc(a)),num(mpcs(a))])
    r.table(['方法','测试种子','成功数 / N','成功率','MPC全部','MPC成功'],rows,[2.0,.85,1.15,.95,1.0,1.05],size=9.2)
    r.p('更细的“方法 × 形状 × 测试种子”指标已随附件保存；每个单元50次测试。误差线若使用这三个种子块计算，仅描述测试任务块差异，不能作为独立学习链重复的误差。')

r.page('学习阶段五轮在线表现')
r.p('本页是学习过程的在线任务表现，不能替代第五轮终态的独立测试。学习中参数不断更新，后续回合依赖此前经验；各轮也采用不同的学习种子。')
r.h('形状单链各轮成功率')
rows=[]
for k in PRI:
    rounds=M[k].get('learning_rounds',{})
    if rounds:
        rows.append([LABEL[k]]+[pct(rounds[str(i)]) if str(i) in rounds else '未提供' for i in range(1,6)])
r.table(['方法','轮1','轮2','轮3','轮4','轮5'],rows,[2.0,.98,.98,.98,.98,.98],size=9.2)
r.h('视觉三链合并各轮成功率')
rows=[]
for g in V['learning_groups']:
    rows.append([f"{g['planner']} {g['slow_lr']:.0e}"]+[pct(x) for x in g['by_round']])
r.table(['设置','轮1','轮2','轮3','轮4','轮5'],rows,[2.0,.98,.98,.98,.98,.98],size=9.3)
r.p('形状Ours历史来源提供轮次成功率，未提供可复核的逐回合学习MPC，因此对应缺项保持缺失。附件shape_learning_episodes.csv只包含能从原始结果重建的学习回合，不填造历史缺失数据。')

r.page('不同初始权重的参考结果')
r.p('本页保留原形状报告的Frozen与AdaJEPA数据，便于追溯历史比较。它们与Ours及新增消融的初始权重不同，因此不进入前面的同权重结构消融排名。')
refkeys=['frozen_official','adajepa_official','adajepa_same','ours_s100']
r.table(['方法','成功数 / N','成功率','MPC全部','MPC成功'],[[M[k]['name'],cnt(M[k]['overall']),pct(M[k]['overall']),num(mpc(M[k]['overall'])),num(mpcs(M[k]['overall']))] for k in refkeys],[2.5,1.2,1.05,1.05,1.1],size=9.3)
r.h('逐形状成功率')
r.table(['形状','Frozen 原权重','AdaJEPA 原权重','AdaJEPA 同权重','Ours'],[[DL[d]]+[pct(M[k]['domains'][d]) for k in refkeys] for d in DOM],[.8,1.55,1.55,1.55,1.45],size=9.4)
r.p('同权重AdaJEPA成功率76.95%，原权重AdaJEPA为72.19%。引用基线时必须同时注明权重口径，不能把二者都简写成同一行“AdaJEPA”再选择较低值作为机制收益。')
r.p('本报告主体只汇总与当前消融问题有关的七形状域和七视觉域学习率实验；此前十四域主实验图表不被重新计算或替换，也不作为当前单链消融的混合基线。')

r.page('进行中的实验与结论边界')
from datetime import datetime
snapshot_time=datetime.fromisoformat(RUN['status_updated']).strftime('%Y年%m月%d日 %H:%M')
r.p(f"状态快照截至 {snapshot_time}（北京时间）。以下三组尚未完成第五轮独立测试，故不纳入已完成结果的效果排名。")
r.table(['实验','已审计学习回合','计划学习回合','已完成测试','计划测试'],[[x['label'],x['completed_learning_episodes'],x['learning_episodes_planned'],x['completed_test_episodes'],x['test_episodes_planned']] for x in RUN['arms']],[2.7,1.05,1.05,1.05,1.05],size=9.4)
r.p('CEM当前仅做同时关闭熟悉度读写保护，未启动CEM单独关读或单独关写。进行中统计是固定时间快照，报告不会自动刷新。')
r.h('不纳入完成结果的历史运行')
r.p('此前中止的视觉朴素继承n30和n50运行缺少完整第五轮及匹配独立测试，保留在排除清单，不与已完成组混合计算。早期在线学习图不能替代本报告的独立测试评价。')
r.h('目前能支持的判断')
r.p('在已观测设置中，直接继承快参数的效果弱于Ours；同权重AdaJEPA与当前EMA设置也低于Ours。共享慢学习器非常接近完整方法，尚未建立多域慢库必要性的稳定证据。关闭熟悉度联合保护的收益因形状而异。')
r.h('尚不能支持的判断')
r.p('不能把单链的小幅差异称为统计显著，不能由一次EMA设置否定整个EMA方法，不能将2e-4视作跨任务通用最优学习率，也不能仅凭第五轮终点证明遗忘被消除。后续应围绕读写拆分、旧域重访和关键组的独立学习重复验证这些解释。')
r.p('慢学习率多档探索使用了已有测试集，本报告如实报告全部档位，未隐藏低分设置；未来确认性实验应在独立验证任务上选择参数，再固定参数评价新的测试任务。')

r.page('数据来源与附件索引')
sources=[
 ['S01','shape_core_gd_singlechain_5round_20261031','同权重AdaJEPA、共享慢学习器、成熟度及慢学习率低高两档；内含历史Ours与原基线'],
 ['S02','shape_naive_gd_n50_3x5_heldout_20261031','三链朴素继承'],
 ['S03','shape_ema_slow_gd_singlechain_5round_20261101','α=1e-4的EMA'],
 ['S04','shape_slow_lr_extended_gd_singlechain_5round_20261101','慢学习率5e-4与0.01'],
 ['S05','shape_slow_lr_3e4_gd_singlechain_5round_20261102','慢学习率3e-4'],
 ['S06','shape_no_familiarity_gd_singlechain_5round_20261104','GD熟悉度读写联合关闭'],
 ['S07','visual_shape_protocol_3x5_heldout_20261029','视觉慢学习率1e-4'],
 ['S08','visual_slow_lr_2e4_3x5_heldout_20261102','视觉慢学习率2e-4'],
 ['S09','shape_familiarity_split_gd_singlechain_5round_20261105','进行中快照'],
]
r.p('实验源目录统一位于 D:\\ADAJEPA\\outputs。下表给出目录名与用途。附件审计JSON记录新增原始NPZ的绝对路径、逐文件哈希和核验结果；历史CSV保留来源路径，其哈希另存historical_source_hashes.json。')
r.table(['编号','源目录','内容'],sources,[.5,3.7,2.7],size=8.6)
r.h('随报告交付的文件')
r.p('data/shape_audit.json 与 visual_audit.json：整体、逐域、逐种子、逐链、配对及来源信息。shape_test_episodes.csv：形状测试逐回合明细；shape_learning_episodes.csv：可复核的形状学习逐回合明细；visual_episode_details.csv：视觉测试逐回合明细。')
r.p('data/shape_domain_seed_metrics.csv、shape_method_metrics.csv、shape_learning_round_metrics.csv、visual_group_metrics.csv：便于表格软件直接读取的分层汇总。figures：全部独立PNG、PDF、SVG及图表清单。scripts：Python重建脚本。')
r.p('主文数字为展示四舍五入，CSV与JSON保留计算精度。合计行是既有记录的汇总，不是额外实验；附件不会通过复制Frozen或AdaJEPA结果来凑齐三链样本数。')

r.save()

# Flat machine-readable summary tables, in addition to complete audit JSON.
def save_csv(name, rows):
    assert rows
    with (ROOT/'data'/name).open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

save_csv('shape_method_metrics.csv',[{'method':m['id'],'name':m['name'],'learning_chains':m['learning_chains'],'comparison_scope':m['comparison_scope'],**m['overall']} for m in S['methods']])
save_csv('shape_domain_seed_metrics.csv',[{'method':m['id'],'domain':d,'test_seed':seed,**x} for m in S['methods'] for d,ss in m['domain_test_seeds'].items() for seed,x in ss.items()])
save_csv('shape_learning_round_metrics.csv',[{'method':m['id'],'round':rnd,**x} for m in S['methods'] for rnd,x in m.get('learning_rounds',{}).items()])
save_csv('visual_group_metrics.csv',[{'planner':g['planner'],'method':g['method'],'slow_lr':g['slow_lr'],'learning_chains':g['learning_chains'],**g['overall']} for g in V['groups']])
(ROOT/'data/source_directory_index.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2),encoding='utf-8')
import hashlib
source_paths=set(p for m in S['methods'] for p in m.get('source_files',[]) if isinstance(p,str) and p.lower().endswith(('.csv','.json')))
hashes=[]
for p in sorted(source_paths):
    fp=Path(p)
    if fp.is_file():
        hashes.append({'path':str(fp),'bytes':fp.stat().st_size,'sha256':hashlib.sha256(fp.read_bytes()).hexdigest()})
(ROOT/'data/historical_source_hashes.json').write_text(json.dumps(hashes,ensure_ascii=False,indent=2),encoding='utf-8')
