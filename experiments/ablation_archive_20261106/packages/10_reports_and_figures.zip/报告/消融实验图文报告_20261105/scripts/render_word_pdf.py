from pathlib import Path
import importlib.util
import json
from PIL import Image, ImageOps, ImageDraw

root = Path(__file__).resolve().parents[1]
source = Path(r'C:\Users\14218\.codex\plugins\cache\openai-primary-runtime\documents\26.1030.10813\skills\documents\render_docx.py')
spec=importlib.util.spec_from_file_location('packaged_renderer',source)
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
# The packaged LibreOffice conversion was attempted and failed because this
# Windows host has no soffice. Keep the packaged rasterizer and use the verified
# native Word PDF export as its conversion stage.
m.convert_to_pdf=lambda *args,**kwargs:(str(root/'消融实验图文报告.pdf'),'Microsoft Word ExportAsFixedFormat')
original=m.convert_from_path
m.convert_from_path=lambda *args,**kwargs:original(*args,**kwargs,poppler_path=r'C:\Users\14218\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin')
paths=m.rasterize(str(root/'消融实验图文报告.docx'),str(root/'qa/render'),144,False,False)
for start in range(0,len(paths),6):
    sheet=Image.new('RGB',(1020,1440),'#dce1e6')
    draw=ImageDraw.Draw(sheet)
    for j,p in enumerate(paths[start:start+6]):
        img=Image.open(p).convert('RGB')
        img.thumbnail((490,440))
        x=(j%2)*510+(510-img.width)//2
        y=(j//2)*480+28
        sheet.paste(img,(x,y))
        draw.text(((j%2)*510+20,(j//2)*480+8),f'Page {start+j+1}',fill='black')
    sheet.save(root/'qa'/f'contact_{start+1:02d}.png')
(root/'qa/render_manifest.json').write_text(json.dumps({'pages':len(paths),'renderer':'Packaged render_docx rasterizer + native Microsoft Word PDF conversion','fallback_reason':'Packaged conversion failed: LibreOffice soffice.exe not found','pngs':paths},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'rendered_pages':len(paths),'contact_sheets':(len(paths)+5)//6}))
