from pathlib import Path
import csv
import hashlib
import json
import re
import zipfile
from datetime import datetime
from pypdf import PdfReader

root=Path(__file__).resolve().parents[1]
pdf=root/'消融实验图文报告.pdf'
reader=PdfReader(pdf)
assert len(reader.pages)==23
page_texts=[p.extract_text() or '' for p in reader.pages]
assert all(len(t)>100 for t in page_texts)
assert all('\ufffd' not in t for t in page_texts)
assert '2384/3150' in ''.join(page_texts)
assert '873/1050' in ''.join(page_texts)
assert '466' in page_texts[1]

counts={}
for name in ['shape_test_episodes.csv','shape_learning_episodes.csv','visual_episode_details.csv']:
    with (root/'data'/name).open(encoding='utf-8-sig',newline='') as f:
        counts[name]=sum(1 for _ in csv.DictReader(f))
assert counts=={'shape_test_episodes.csv':18900,'shape_learning_episodes.csv':21000,'visual_episode_details.csv':16800}

summary=json.loads((root/'data/shape_audit.json').read_text(encoding='utf-8'))
for method in summary['methods']:
    assert sum(m['n'] for m in method['domains'].values())==method['overall']['n']
    assert sum(m['successes'] for m in method['domains'].values())==method['overall']['successes']
    assert sum(m['n'] for m in method['test_seeds'].values())==method['overall']['n']

readme='''AdaJEPA持续学习消融实验图文报告
生成日期：2026年11月5日

建议先打开 消融实验图文报告.pdf（23页），或 图文报告.html（含导航目录）。
消融实验图文报告.docx 是可编辑版本。

范围
1. 七形状域 GD：同权重 AdaJEPA、朴素继承、EMA、共享慢学习器、成熟度读取门控、熟悉度读写保护、六档慢学习率。
2. 七视觉域 GD/CEM：慢学习率1e-4与2e-4。
3. 三链扩展、不同权重背景参考、学习阶段汇总、在跑实验的固定时间快照。

数据
data/shape_test_episodes.csv：18900条形状独立测试执行记录。
data/shape_learning_episodes.csv：21000条可复核的形状学习执行记录。
data/visual_episode_details.csv：16800条视觉独立测试执行记录，包含参考基线。
data/shape_audit.json 与 visual_audit.json：完整分层统计、来源和核验结果。
data/*metrics.csv 与 visual_test_seed_details.csv：可直接用表格软件读取的汇总。
data/running_snapshot.json：报告编制时的运行快照，不自动刷新。

图表
figures/：12张图，每张包含300dpi PNG、矢量PDF与SVG。
图表采用既有论文风格，Ours曲线纯实线且无点。
figures/figure_manifest.json 给出图注、比较范围与数据来源。

解释要点
形状主对比匹配s100单链；三条测试种子不是三条独立学习链。
同权重AdaJEPA与原报告不同权重AdaJEPA分别保留，不能混称。
学习在线表现与第五轮独立测试分开；未完成实验不加入效果排名。
形状Ours历史CSV缺原始状态，逐回合变化为协议键匹配；新增组状态一致性另外核验。
视觉150个基础测试任务在视觉条件与学习链下重复执行，执行条数不等于独立任务数。
历史缺失的学习MPC、逐回合记录保持缺失，没有填造。
报告附件汇总的是实验结果明细；大体积模型权重、动作张量和原始状态仍保留在原实验目录，本包未重复复制。

复现
scripts/中提供图表和文档生成脚本；data/中提供只读审计脚本。
Python使用numpy、matplotlib、pandas、python-docx、Pillow、pypdf等库。
原始复审脚本需要本机原实验目录；已汇总JSON与CSV可独立查阅。
Word转PDF使用本机Microsoft Word，渲染检查使用Poppler。
manifest_sha256.json 记录交付文件校验值。
'''
(root/'阅读说明.txt').write_text(readme,encoding='utf-8')
dictionary='''数据字段与统计口径
success / success_count / successes：原始成功标志或成功次数。
n：执行次数；不代表所有记录均统计独立。
success_rate：0到1的比例；success_rate_pct/percent为百分数。
mpc_steps_all / mpc_steps_all_mean：全部回合平均MPC重规划次数。
mpc_steps_success / mpc_steps_success_mean：仅本方法成功回合的平均MPC次数。
chain：学习链；形状/视觉轮次种子安排见各audit的protocol。
test_seed / seed：测试任务块种子；不要作为学习重复编号。
domain / shape / tag：实验域，映射见对应audit的domain_order/labels。
round：学习轮次；独立测试使用第五轮终态。
source / source_files：原始文件路径；路径存在于本机实验目录。
comparison_scope：匹配单链、额外链、三链合计或不同权重参考。
三链合计行由相应单链汇总，不是新增实验；不要重复累加。
形状逐域每链150次，域×测试种子每链50次；视觉每域每学习率三链共450次。
图中的误差线：形状为三测试块标准差；视觉为三独立学习链标准差。
CSV采用UTF-8 BOM编码，可用Excel或Python读取。
'''
(root/'data/字段说明.txt').write_text(dictionary,encoding='utf-8')

verification={'generated':datetime.now().isoformat(timespec='seconds'),'pdf_pages':23,'figures':12,'csv_rows':counts,
 'numeric_audit':'Shape and visual statistics independently recomputed and reviewer-checked',
 'visual_qa':'All 23 pages inspected; revised pages 2,4,14,15,16,22,23 rechecked',
 'pdf_text_checks_passed':True,'shape_domain_seed_aggregation_passed':True,
 'running_experiments_excluded_from_final_comparisons':True,
 'document_rendering':'Native Word export; packaged render_docx rasterizer with Poppler after LibreOffice unavailable'}
(root/'verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2),encoding='utf-8')

files=[p for p in root.rglob('*') if p.is_file() and 'qa' not in p.relative_to(root).parts and '__pycache__' not in p.parts and p.suffix!='.zip' and p.name not in ['manifest_sha256.json','bundle_info.json']]
manifest=[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)]
(root/'manifest_sha256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
files.append(root/'manifest_sha256.json')
bundle=root/'消融报告与数据图表.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(files): z.write(p,p.relative_to(root).as_posix())
with zipfile.ZipFile(bundle) as z:
    assert z.testzip() is None
    assert len(z.infolist())==len(files)
info={'path':str(bundle),'bytes':bundle.stat().st_size,'files':len(files),'sha256':hashlib.sha256(bundle.read_bytes()).hexdigest()}
(root/'bundle_info.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'pdf_pages':23,'csv_rows':counts,**info},ensure_ascii=False))
