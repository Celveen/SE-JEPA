from pathlib import Path
import html
import json
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parents[1]


class Report:
    def __init__(self):
        self.doc = Document()
        s = self.doc.sections[0]
        s.page_width, s.page_height = Inches(8.5), Inches(11)
        s.top_margin, s.bottom_margin = Inches(.66), Inches(.62)
        s.left_margin, s.right_margin = Inches(.80), Inches(.80)
        s.header_distance, s.footer_distance = Inches(.27), Inches(.28)
        for key in ['Normal', 'Body Text', 'List Bullet', 'List Number']:
            st = self.doc.styles[key]
            st.font.name = 'Arial'
            st.font.size = Pt(10.5)
            st.font.color.rgb = RGBColor(0, 0, 0)
            st.element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), 'Microsoft YaHei')
            st.paragraph_format.line_spacing = 1.17
            st.paragraph_format.space_after = Pt(6)
            st.paragraph_format.widow_control = True
        for key, size in [('Title', 23), ('Subtitle', 12), ('Heading 1', 17), ('Heading 2', 12)]:
            st = self.doc.styles[key]
            st.font.name = 'Arial'
            st.font.size = Pt(size)
            st.font.bold = key != 'Subtitle'
            st.font.italic = False
            st.font.color.rgb = RGBColor(0, 0, 0)
            rf = st.element.get_or_add_rPr().get_or_add_rFonts()
            rf.set(qn('w:eastAsia'), 'Microsoft YaHei')
            st.paragraph_format.space_before = Pt(0 if key in ['Title', 'Heading 1'] else 7)
            st.paragraph_format.space_after = Pt(9)
            st.paragraph_format.line_spacing = 1.1
            st.paragraph_format.keep_with_next = True
        st = self.doc.styles['Caption']
        st.font.name = 'Arial'
        st.font.size = Pt(9)
        st.font.italic = False
        st.font.color.rgb = RGBColor(0, 0, 0)
        st.element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), 'Microsoft YaHei')
        st.paragraph_format.space_after = Pt(6)
        st.paragraph_format.line_spacing = 1.12
        for st in self.doc.styles:
            for b in list(st.element.iter(qn('w:pBdr'))):
                b.getparent().remove(b)
        hp = s.header.paragraphs[0]
        hp.text = 'AdaJEPA 持续学习实验  |  消融结果汇总  |  2026年11月5日'
        for r in hp.runs:
            r.font.size = Pt(8)
            r.font.color.rgb = RGBColor(0, 0, 0)
        fp = s.footer.paragraphs[0]
        fp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        fp.add_run('第 ')
        field = OxmlElement('w:fldSimple')
        field.set(qn('w:instr'), 'PAGE')
        fp._p.append(field)
        fp.add_run(' 页')
        for r in fp.runs:
            r.font.size = Pt(8)
        self.doc.core_properties.title = 'AdaJEPA持续学习消融实验图文报告'
        self.doc.core_properties.subject = '七形状域消融与七视觉域慢学习率比较'
        self.doc.core_properties.author = '实验数据汇总'
        self.pages = []
        self.current = None
        self.fig_n = 0

    def page(self, title, subtitle=None, cover=False):
        if self.current is not None:
            self.doc.add_page_break()
        self.current = {'title': title, 'blocks': []}
        self.pages.append(self.current)
        self.doc.add_paragraph(title, 'Title' if cover else 'Heading 1')
        if subtitle:
            self.p(subtitle, 'Subtitle')

    def p(self, text, style=None):
        p = self.doc.add_paragraph(text, style=style)
        self.current['blocks'].append({'type': 'p', 'text': text, 'style': style})
        return p

    def h(self, text):
        self.doc.add_paragraph(text, 'Heading 2')
        self.current['blocks'].append({'type': 'h', 'text': text})

    def table(self, headers, rows, widths=None, size=9.2):
        t = self.doc.add_table(rows=1, cols=len(headers))
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.autofit = False
        if widths is None:
            widths = [6.9 / len(headers)] * len(headers)
        for c, w in zip(t.columns, widths):
            c.width = Inches(w)
        for i, value in enumerate(headers):
            t.rows[0].cells[i].text = str(value)
        for values in rows:
            cells = t.add_row().cells
            for i, value in enumerate(values):
                cells[i].text = str(value)
        for ri, row in enumerate(t.rows):
            trp = row._tr.get_or_add_trPr()
            no_split = OxmlElement('w:cantSplit')
            trp.append(no_split)
            if ri == 0:
                repeat = OxmlElement('w:tblHeader')
                trp.append(repeat)
            for ci, cell in enumerate(row.cells):
                cell.width = Inches(widths[ci])
                cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                props = cell._tc.get_or_add_tcPr()
                shade = OxmlElement('w:shd')
                shade.set(qn('w:fill'), '263D52' if ri == 0 else ('F2F5F8' if ri % 2 == 0 else 'FFFFFF'))
                props.append(shade)
                borders = OxmlElement('w:tcBorders')
                for edge in ['top', 'left', 'bottom', 'right']:
                    b = OxmlElement('w:' + edge)
                    for k, v in {'val': 'single', 'sz': '4', 'color': 'D9D9D9'}.items():
                        b.set(qn('w:' + k), v)
                    borders.append(b)
                props.append(borders)
                margins = OxmlElement('w:tcMar')
                for edge in ['top', 'left', 'bottom', 'right']:
                    m = OxmlElement('w:' + edge)
                    m.set(qn('w:w'), '65' if edge in ['top', 'bottom'] else '80')
                    m.set(qn('w:type'), 'dxa')
                    margins.append(m)
                props.append(margins)
                for p in cell.paragraphs:
                    p.alignment = WD_ALIGN_PARAGRAPH.LEFT if ci == 0 else WD_ALIGN_PARAGRAPH.CENTER
                    p.paragraph_format.line_spacing = 1.04
                    p.paragraph_format.space_before = Pt(0)
                    p.paragraph_format.space_after = Pt(0)
                    for run in p.runs:
                        run.font.name = 'Arial'
                        run.font.size = Pt(size)
                        run.font.bold = ri == 0
                        run.font.color.rgb = RGBColor(255, 255, 255) if ri == 0 else RGBColor(0, 0, 0)
                        run._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), 'Microsoft YaHei')
        self.current['blocks'].append({'type': 'table', 'headers': headers, 'rows': rows})
        spacer = self.doc.add_paragraph()
        spacer.paragraph_format.space_after = Pt(1)
        spacer.paragraph_format.space_before = Pt(0)
        spacer.paragraph_format.line_spacing = 1
        spacer.add_run().font.size = Pt(2)
        return t

    def figure(self, path, caption, width=6.8):
        path = Path(path)
        assert path.exists(), path
        self.fig_n += 1
        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(2)
        p.paragraph_format.keep_with_next = True
        p.add_run().add_picture(str(path), width=Inches(width))
        txt = f'图{self.fig_n}  {caption}'
        self.doc.add_paragraph(txt, 'Caption')
        self.current['blocks'].append({'type': 'figure', 'path': str(path.relative_to(ROOT)).replace('\\', '/'), 'caption': txt})

    def save(self):
        target = ROOT / '消融实验图文报告.docx'
        self.doc.save(target)
        (ROOT / 'data' / 'report_content.json').write_text(json.dumps(self.pages, ensure_ascii=False, indent=2), encoding='utf-8')
        nav = ''.join(f'<a href="#p{i}">{html.escape(p["title"])}</a>' for i, p in enumerate(self.pages, 1))
        sections = []
        for i, page in enumerate(self.pages, 1):
            items = [f'<section id="p{i}"><h1>{html.escape(page["title"])}</h1>']
            for b in page['blocks']:
                if b['type'] == 'p':
                    items.append(f'<p>{html.escape(b["text"])}</p>')
                elif b['type'] == 'h':
                    items.append(f'<h2>{html.escape(b["text"])}</h2>')
                elif b['type'] == 'figure':
                    items.append(f'<figure><a href="{b["path"]}"><img src="{b["path"]}"></a><figcaption>{html.escape(b["caption"])}</figcaption></figure>')
                else:
                    items.append('<table><thead><tr>' + ''.join(f'<th>{html.escape(str(x))}</th>' for x in b['headers']) + '</tr></thead><tbody>')
                    items.extend('<tr>' + ''.join(f'<td>{html.escape(str(x))}</td>' for x in r) + '</tr>' for r in b['rows'])
                    items.append('</tbody></table>')
            items.append('</section>')
            sections.append(''.join(items))
        css = 'body{font-family:Arial,"Microsoft YaHei",sans-serif;color:#18212a;background:#edf0f3;margin:0;line-height:1.75}nav{position:fixed;left:0;top:0;bottom:0;width:235px;overflow:auto;background:#fff;padding:20px;font-size:13px}nav a{display:block;color:#294f70;padding:4px;text-decoration:none}main{margin:28px 36px 60px 300px;max-width:1000px}section{background:white;padding:40px 46px;margin-bottom:24px;scroll-margin-top:20px}h1{font-size:25px;color:black}h2{font-size:18px;color:black}p{font-size:15px}table{border-collapse:collapse;width:100%;font-size:13px;margin:20px 0}td,th{border:1px solid #d9d9d9;padding:8px;text-align:center}td:first-child{text-align:left}th{background:#263d52;color:#fff}tbody tr:nth-child(even){background:#f2f5f8}figure{margin:20px 0}img{max-width:100%;height:auto}figcaption{font-size:12px;color:#47505a} .downloads a{margin-right:20px}@media(max-width:900px){nav{position:static;width:auto}main{margin:16px}section{padding:24px}}@media print{nav,.downloads{display:none}main{margin:0}section{break-before:page}}'
        downloads = '<p class="downloads"><a href="消融实验图文报告.pdf">下载 PDF</a><a href="消融实验图文报告.docx">下载 Word</a><a href="消融报告与数据图表.zip">下载完整报告附件</a></p>'
        html_text = '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>消融实验图文报告</title><style>' + css + '</style><nav><strong>报告目录</strong>' + nav + '</nav><main>' + downloads + ''.join(sections) + '</main></html>'
        (ROOT / '图文报告.html').write_text(html_text, encoding='utf-8')
        print(json.dumps({'docx': str(target), 'logical_pages': len(self.pages), 'figures': self.fig_n}, ensure_ascii=False))
