"""Auditable report figures from verified local experimental summaries."""
from pathlib import Path
import sys,json,math,statistics,hashlib
sys.path.insert(0,r'D:\ADAJEPA\tmp\T_figure_python_deps')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'figures'; OUT.mkdir(parents=True,exist_ok=True)
DOM=['I','L','square','Z','small_tee','plus','T']
DLAB=['I','L','square','Z','smallT','+','T']
C={'ours_s100':'#7FB5E8','adajepa_same':'#7BCDBF','naive_s100':'#CFCAC2','ema_slow':'#AAB2E8',
   'shared_slow':'#D4A99C','no_maturity_read':'#D8C68F','no_familiarity':'#DA9AAB'}
LABEL={'ours_s100':'Ours','adajepa_same':'AdaJEPA','naive_s100':'Naive inheritance',
       'ema_slow':'Slow-parameter EMA','shared_slow':'Shared slow learner',
       'no_maturity_read':'No maturity read gate','no_familiarity':'No familiarity gates'}
ZHLABEL={'ours_s100':'完整 Ours','adajepa_same':'同权重 AdaJEPA','naive_s100':'朴素继承',
         'ema_slow':'慢参数 EMA','shared_slow':'单一共享慢学习器',
         'no_maturity_read':'关闭成熟度读取限制','no_familiarity':'关闭熟悉度读写保护'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.labelsize':10,
 'axes.titlesize':10,'axes.linewidth':.65,'axes.edgecolor':'#555555',
 'xtick.labelsize':10,'ytick.labelsize':10,'legend.fontsize':10,'text.color':'#151515',
 'axes.labelcolor':'#151515','xtick.color':'#333333','ytick.color':'#333333',
 'pdf.fonttype':42,'ps.fonttype':42,'figure.facecolor':'white','savefig.facecolor':'white',
 'svg.hashsalt':'ablation-report-20261105'})
MAN=[]

def axes_style(ax,bars=True,grid='y'):
    ax.set_axisbelow(True)
    ax.grid(axis=grid,color='#E3E3E3' if bars else '#D0D0D0',lw=.5,ls='-' if bars else ':')
    if bars:ax.set_facecolor('#F7F7F7')
    for sp in ax.spines.values():sp.set_color('#D0D0D0')
    ax.tick_params(length=2.8,pad=3)

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def value(metric,key):
    return float(metric['success_rate'])*100 if key=='rate' else float(metric['mpc_steps_all'])

def seed_blocks(m,domain=None):
    if domain is None:return list(m.get('test_seeds',{}).values())
    raw=m.get('domain_test_seeds',{})
    if domain in raw:
        z=raw[domain]
        return list(z.values()) if isinstance(z,dict) else z
    return [v[domain] for v in raw.values() if isinstance(v,dict) and domain in v]

def sd(m,key,domain=None):
    bs=seed_blocks(m,domain)
    return statistics.stdev([value(b,key) for b in bs]) if len(bs)>1 else 0

def provenance(methods):
    return {m['id']:m.get('source_files',[]) for m in methods}

def save(fig,stem,title,caption,methods,**extra):
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer();w,h=fig.canvas.get_width_height()
    for t in fig.findobj(matplotlib.text.Text):
        if t.get_visible() and t.get_text():
            b=t.get_window_extent(renderer)
            if not(b.x0>=-.6 and b.y0>=-.6 and b.x1<=w+.6 and b.y1<=h+.6):
                raise RuntimeError(f'Text clipped: {stem}: {t.get_text()} {b.bounds} vs {(w,h)}')
    for ax in fig.axes:
        for line in ax.lines:
            if line.get_gid()=='ours':
                assert line.get_linestyle()=='-' and line.get_marker() in [None,'None','',' ']
    files={ext:str(OUT/f'{stem}.{ext}') for ext in ['png','pdf','svg']}
    fig.savefig(files['png'],dpi=300)
    fig.savefig(files['pdf'],metadata={'Title':title,'Subject':caption,'Creator':'Python / Matplotlib'})
    fig.savefig(files['svg'])
    MAN.append({'id':stem,'title':title,'caption':caption,'files':files,
                'methods':[m['id'] for m in methods],
                'learning_chains':{m['id']:m.get('learning_chains') for m in methods},
                'source_files':provenance(methods),'dpi':300,'figure_inches':list(fig.get_size_inches()),**extra})
    plt.close(fig); print('Saved',stem,flush=True)

def pair_figure(m,ours,stem):
    fig,axs=plt.subplots(1,2,figsize=(6.8,3.1))
    fig.subplots_adjust(left=.082,right=.985,top=.79,bottom=.18,wspace=.27)
    pair=[m,ours];idx=np.arange(7)
    for ax,key,ylab,title in zip(axs,['rate','mpc'],['Success rate (%)','Mean MPC steps'],['(a) Held-out success','(b) MPC, all episodes']):
        axes_style(ax)
        for j,k in enumerate(pair):
            vals=[value(k['domains'][d],key) for d in DOM]
            errs=[sd(k,key,d) for d in DOM]
            ax.bar(idx+(j-.5)*.39,vals,width=.35,color=C[k['id']],edgecolor='white',lw=.6,
                   yerr=errs,capsize=1.7,error_kw={'elinewidth':.65,'capthick':.65})
        ax.set_xticks(idx,DLAB,rotation=30,ha='right');ax.set_xlim(-.65,6.65)
        ax.set_ylim(0,112 if key=='rate' else 33)
        ax.set_yticks([0,25,50,75,100] if key=='rate' else [0,10,20,30])
        ax.set_ylabel(ylab);ax.set_title(title,loc='left',pad=9)
    fig.legend(handles=[Patch(facecolor=C[k['id']],label=LABEL[k['id']]) for k in pair],
               loc='upper center',bbox_to_anchor=(.52,.99),ncol=2,frameon=False,columnspacing=1.7)
    cap=f"{ZHLABEL[m['id']]}与完整 Ours 的七形状域 GD 独立测试对比，各 1050 回合、每域 150 回合。Ours 为 s100 链，各消融按相同学习种子链比较；AdaJEPA 按回合恢复原始权重。左：成功率；右：全部回合平均 MPC，失败记 30 步。误差棒为 3 个测试种子之间的样本标准差，不是训练重复标准差。"
    save(fig,stem,f"{ZHLABEL[m['id']]}与 Ours",cap,pair,error_bars='sample SD across 3 test seeds; not training replicates')

def overview(methods):
    ids=['adajepa_same','naive_s100','ema_slow','shared_slow','no_maturity_read','ours_s100']
    ms=[methods[x] for x in ids]; y=np.arange(len(ms))
    fig,axs=plt.subplots(1,2,figsize=(6.8,3.8),sharey=True)
    fig.subplots_adjust(left=.272,right=.98,top=.88,bottom=.16,wspace=.23)
    for ax,key,title in zip(axs,['rate','mpc'],['(a) Success rate','(b) Mean MPC steps']):
        axes_style(ax,grid='x')
        for i,m in enumerate(ms):
            val=value(m['overall'],key);err=sd(m,key)
            ax.barh(i,val,height=.62,color=C[m['id']],edgecolor='white',lw=.6,xerr=err,capsize=2,
                    error_kw={'elinewidth':.65,'capthick':.65})
            ax.text(val+err+(.9 if key=='rate' else .24),i,f'{val:.2f}',va='center',fontsize=10)
        ax.set_xlim(0,112 if key=='rate' else 22)
        ax.set_xticks([0,25,50,75,100] if key=='rate' else [0,5,10,15,20])
        ax.set_title(title,loc='left',pad=10);ax.set_xlabel('Success rate (%)' if key=='rate' else 'Mean MPC steps')
    axs[0].set_yticks(y,[LABEL[x] for x in ids]);axs[0].invert_yaxis()
    cap='主要结构与继承方式消融总览。每组 1050 个独立测试回合，均对齐原始形状权重与 s100 学习链设置；朴素继承只取第一链。误差棒为 3 个测试种子的样本标准差。平均 MPC 包含失败回合，失败按 30 步计。'
    save(fig,'01_structure_overview','主要消融总体对比',cap,ms,error_bars='test-seed SD, not training replicates')

def lr_figure(methods):
    ids=['slow_lr_low','ours_s100','slow_lr_high','slow_lr_3e4','slow_lr_5e4','slow_lr_1e2']
    ms=sorted([methods[x] for x in ids],key=lambda m:m['slow_lr']);x=[m['slow_lr'] for m in ms]
    fig,axs=plt.subplots(1,2,figsize=(6.8,3.3))
    fig.subplots_adjust(left=.095,right=.985,top=.83,bottom=.29,wspace=.28)
    for ax,key in zip(axs,['rate','mpc']):
        axes_style(ax,False,grid='both');y=[value(m['overall'],key) for m in ms]
        ax.plot(x,y,color='#708CC3',lw=1.8,marker=None,gid='ours')
        base=value(methods['ours_s100']['overall'],key)
        ax.axhline(base,color='#AFB8C3',ls='-',lw=1.0,label='Ours reference (1e-4)',gid='ours')
        for i,(xx,yy) in enumerate(zip(x,y)):
            ax.annotate(f'{yy:.2f}',(xx,yy),textcoords='offset points',xytext=(0,9 if i%2==0 else -17),ha='center',fontsize=10)
        ax.set_xscale('log');ax.set_xlim(min(x)/1.6,max(x)*1.7)
        ax.set_xticks(x,['5e-5','1e-4','2e-4','3e-4','5e-4','1e-2'],rotation=50,ha='right')
        ax.minorticks_off();ax.set_xlabel('Slow learning rate (log scale)')
        ax.set_ylabel('Success rate (%)' if key=='rate' else 'Mean MPC steps')
        ax.set_ylim(40,100) if key=='rate' else ax.set_ylim(5,23)
    axs[0].set_title('(a) Held-out success',loc='left');axs[1].set_title('(b) MPC, all episodes',loc='left')
    fig.legend(handles=[Line2D([],[],color='#708CC3',lw=1.8,marker=None,label='Ours, slow-LR sweep'),
                        Line2D([],[],color='#AFB8C3',lw=1,ls='-',marker=None,label='Reference: 1e-4')],
               loc='upper center',bbox_to_anchor=(.53,1.0),ncol=2,frameon=False)
    cap='七形状域 GD 慢梯度学习率敏感性。横轴采用真实学习率数值的对数尺度；每个设置为单学习链、1050 个独立测试回合。水平参考线为完整 Ours 的 1e-4 设置。折线表示不同参数设置，不能解释为训练过程。EMA 系数不作为梯度学习率并入本图。'
    save(fig,'08_slow_learning_rate','慢学习率敏感性',cap,ms,x_axis='actual learning rate, log scale',error_bars='none')

def familiarity(methods):
    m=methods['no_familiarity'];o=methods['ours_s100'];ds=DOM+['overall'];lab=DLAB+['All']
    fig,axs=plt.subplots(1,2,figsize=(6.8,3.3),sharey=True)
    fig.subplots_adjust(left=.105,right=.985,top=.85,bottom=.23,wspace=.36)
    for ax,key in zip(axs,['rate','mpc']):
        vals=[value(m['overall'] if d=='overall' else m['domains'][d],key)-value(o['overall'] if d=='overall' else o['domains'][d],key) for d in ds]
        axes_style(ax,grid='x');ax.axvline(0,color='#777777',lw=.75)
        colors=['#7FB5E8' if (v>=0 if key=='rate' else v<=0) else '#D4A99C' for v in vals]
        ax.barh(range(len(ds)),vals,color=colors,height=.68,edgecolor='white',lw=.5)
        span=max(abs(v) for v in vals)
        ax.set_xlim(-max(1,span)*1.55,max(1,span)*1.55)
        ax.set_xticks([-10,-5,0,5,10] if key=='rate' else [-3,-1.5,0,1.5,3])
        for i,v in enumerate(vals):
            ax.text(v+(span*.07 if v>=0 else -span*.07),i,f'{v:+.2f}',va='center',ha='left' if v>=0 else 'right',fontsize=10)
        ax.set_xlabel('Success change (pp)' if key=='rate' else 'MPC change (steps)')
        ax.set_title('(a) Higher is better' if key=='rate' else '(b) Lower is better',loc='left',pad=10)
    axs[0].set_yticks(range(len(ds)),lab);axs[0].invert_yaxis()
    fig.legend(handles=[Patch(facecolor='#7FB5E8',label='Improvement'),Patch(facecolor='#D4A99C',label='Decline')],loc='upper center',bbox_to_anchor=(.54,1.0),ncol=2,frameon=False)
    cap='关闭熟悉度读写保护相对完整 Ours 的变化。成功率正值表示提升，平均 MPC 负值表示改善；蓝色为改善，浅棕色为退步。每域 150 回合，总体 1050 回合，仅一个学习链。该图是描述性差值，不表示统计显著；独立关闭读取/写入以及 CEM 新实验未完成，不纳入本图。'
    save(fig,'09_familiarity_domain_changes','熟悉度读写保护：逐域变化',cap,[m,o],delta_definition='ablation minus Ours; no significance claims')

def budget(methods):
    p=Path(r'D:\ADAJEPA\报告\七形状域_逐项消融对比图_20261104\data\heldout_episode_data.json')
    rows=read(p)['rows'];ids=['adajepa_same','naive_s100','ema_slow','ours_s100']
    aliases={'naive_s100':'naive','ours_s100':'ours'}
    styles={'adajepa_same':'--','naive_s100':':','ema_slow':'-.','ours_s100':'-'}
    fig,ax=plt.subplots(figsize=(6.8,3.4));fig.subplots_adjust(left=.10,right=.985,top=.76,bottom=.18)
    axes_style(ax,False,grid='both')
    for id in ids:
        rr=[r for r in rows if r['method']==aliases.get(id,id)]
        assert len(rr)==1050 and sum(r['success'] for r in rr)==methods[id]['overall']['successes']
        ys=[100*sum(r['success'] and r['mpc_steps']<=k for r in rr)/len(rr) for k in range(1,31)]
        ax.plot(range(1,31),ys,color=C[id],ls=styles[id],lw=2 if id=='ours_s100' else 1.7,
                marker=None,label=LABEL[id],gid='ours' if id=='ours_s100' else id)
    ax.set(xlim=(0,30),ylim=(0,100),xticks=[0,5,10,15,20,25,30],yticks=[0,25,50,75,100],
           xlabel='MPC step budget',ylabel='Success rate (%)')
    fig.legend(loc='upper center',bbox_to_anchor=(.54,.995),ncol=2,frameon=False,handlelength=3,columnspacing=2)
    cap='MPC 预算内成功率，由实际逐回合结果重算：成功且步数不超过预算的回合数，除以全部 1050 个测试回合。Ours 为纯实线、无点，AdaJEPA 为虚线；第 30 步的终点等于各方法最终成功率。朴素继承只取 s100 第一链。'
    save(fig,'12_mpc_budget_success','补充：MPC 预算内成功率',cap,[methods[id] for id in ids],extra_source=str(p))

def build_shape():
    data=read(ROOT/'data/shape_audit.json');methods={m['id']:m for m in data['methods']}
    o=methods['ours_s100'];assert o['overall']['successes']==855 and o['overall']['n']==1050
    overview(methods)
    for n,id in enumerate(['naive_s100','ema_slow','adajepa_same','shared_slow','no_maturity_read','no_familiarity'],2):
        assert methods[id]['overall']['n']==1050
        pair_figure(methods[id],o,f'{n:02d}_{id}_vs_ours')
    lr_figure(methods);familiarity(methods);budget(methods)

def build_visual():
    d=read(ROOT/'data/visual_audit.json')
    dom=['default','blur','snp1','dark','red_agent','red_object','red_goal']
    labels=['Original','Blur','Noise','Dark','Agent','Object','Goal']
    for planner,stem in [('GD','10_visual_gd_learning_rate'),('CEM','11_visual_cem_learning_rate')]:
        ms=sorted([g for g in d['groups'] if g['planner']==planner and g['method']=='v6a'],key=lambda g:g['slow_lr'])
        assert len(ms)==2 and [g['slow_lr'] for g in ms]==[1e-4,2e-4]
        assert all(g['learning_chains']==3 and g['overall']['n']==3150 for g in ms)
        fig,axs=plt.subplots(1,2,figsize=(6.8,3.4))
        fig.subplots_adjust(left=.082,right=.985,top=.80,bottom=.25,wspace=.27)
        colors=['#7FB5E8','#AAB2E8']
        for ax,key in zip(axs,['success_rate_pct','mpc_steps_all_mean']):
            axes_style(ax)
            for j,g in enumerate(ms):
                dd={r['domain']:r for r in g['by_domain']}
                vals=[dd[k][key] for k in dom]
                errs=[statistics.stdev([r[key] for r in g['by_domain_chain'] if r['domain']==k]) for k in dom]
                ax.bar(np.arange(7)+(j-.5)*.39,vals,width=.35,color=colors[j],edgecolor='white',lw=.6,
                       yerr=errs,capsize=1.7,error_kw={'elinewidth':.65,'capthick':.65})
            ax.set_xticks(range(7),labels,rotation=45,ha='right');ax.set_xlim(-.65,6.65)
            israte=key=='success_rate_pct';ax.set_ylim(0,112 if israte else 33)
            ax.set_yticks([0,25,50,75,100] if israte else [0,10,20,30])
            ax.set_ylabel('Success rate (%)' if israte else 'Mean MPC steps')
            ax.set_title('(a) Held-out success' if israte else '(b) MPC, all episodes',loc='left',pad=9)
        fig.legend(handles=[Patch(facecolor=colors[j],label=f'Ours, slow LR = {"1e-4" if j==0 else "2e-4"}') for j in range(2)],
                   loc='upper center',bbox_to_anchor=(.52,.99),ncol=2,frameon=False,columnspacing=1.3)
        cap=f'七视觉域 {planner} 的慢学习率 1e-4 与 2e-4 对比。两组均为 3 条独立学习链的第五轮端点，每条链 1050 个独立测试回合，总计每设置 3150 回合、每域 450 回合。误差棒为 3 条学习链的样本标准差；每条链先汇总三个测试种子。平均 MPC 包含失败回合，失败计 30 步。Original/Blur/Noise/Dark/Agent/Object/Goal 对应原始视觉、模糊、椒盐噪声、暗光、红色智能体、红色物体、红色目标。'
        mm=[{'id':f'visual_{planner.lower()}_lr_{g["slow_lr"]}', 'learning_chains':3,'source_files':d['sources']} for g in ms]
        save(fig,stem,f'七视觉域 {planner}：慢学习率比较',cap,mm,error_bars='sample SD across 3 learning chains; each chain aggregates 3 held-out test seeds')

def main():
    build_shape()
    build_visual()
    MAN.sort(key=lambda m:m['id'])
    (OUT/'figure_manifest.json').write_text(json.dumps(MAN,ensure_ascii=False,indent=2),encoding='utf-8')

if __name__=='__main__':main()
