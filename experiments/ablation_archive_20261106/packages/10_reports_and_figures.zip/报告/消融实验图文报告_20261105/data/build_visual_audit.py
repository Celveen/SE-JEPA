import json
import hashlib
import math
import csv
from pathlib import Path
from datetime import datetime
from collections import defaultdict

import numpy as np

BASE = Path('D:/ADAJEPA')
OUT = BASE / '报告/消融实验图文报告_20261105/data'
OUT.mkdir(parents=True, exist_ok=True)
OLD = BASE / 'outputs/visual_shape_protocol_3x5_heldout_20261029'
NEW = BASE / 'outputs/visual_slow_lr_2e4_3x5_heldout_20261102'
RUN = BASE / 'outputs/shape_familiarity_split_gd_singlechain_5round_20261105'
LABELS = dict(zip(['default','blur','snp1','dark','red_agent','red_object','red_goal'],
                  ['原始视觉','模糊','椒盐噪声','暗光','红色智能体','红色物体','红色目标']))

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save(name, value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')

def stats(records):
    n=len(records); s=sum(r['success'] for r in records)
    steps=sum(r['mpc_steps'] for r in records)
    steps_success=sum(r['mpc_steps'] for r in records if r['success'])
    return dict(n=n,successes=s,failures=n-s,success_rate=s/n,success_rate_pct=100*s/n,
                mpc_steps_sum=steps,mpc_steps_all_mean=steps/n,
                mpc_steps_success_sum=steps_success,
                mpc_steps_success_mean=steps_success/s if s else None)

def group_stats(records, keys):
    groups=defaultdict(list)
    for r in records:groups[tuple(r[k] for k in keys)].append(r)
    return [dict(zip(keys,k),**stats(v)) for k,v in sorted(groups.items())]

def batch_stats(rows):
    n=sum(r['n'] for r in rows);s=sum(r['successes'] for r in rows)
    steps=sum(round(r['mpc_steps_all_mean']*r['n']) for r in rows)
    ssteps=sum(round(r['mpc_steps_success_mean']*r['successes']) for r in rows if r['successes'])
    return dict(n=n,successes=s,success_rate=s/n,success_rate_pct=100*s/n,
                mpc_steps_sum=steps,mpc_steps_all_mean=steps/n,
                mpc_steps_success_mean=ssteps/s if s else None)

old=read(OLD/'final_results.json');new=read(NEW/'final_results.json')
comparison_path=BASE/'报告/七视觉域慢学习率最终对比_20261104/最终对比数据.json'
comparison=read(comparison_path)
gd_path=BASE/'报告/GD慢学习率详细对比_20261104/GD详细配对数据.json'
gd=read(gd_path)
schedule=old['protocol']['seed_schedule']
learning_source_episode_ids=set()
test_source_episode_ids={}
for key,stream in old['protocol']['streams'].items():
    ids={int(sample['ep_idx']) for sample in stream['samples']}
    if key.startswith('learn_'):
        learning_source_episode_ids.update(ids)
    elif key.startswith('test_'):
        test_source_episode_ids[key]=ids
split_verification=dict(
    identifier='source ep_idx from protocol.streams.samples',
    learning_unique_source_episodes=len(learning_source_episode_ids),
    heldout_unique_source_episodes=len(set().union(*test_source_episode_ids.values())),
    test_blocks={key:dict(unique_source_episodes=len(ids),learning_overlap=len(ids & learning_source_episode_ids))
                 for key,ids in test_source_episode_ids.items()},
    between_test_block_overlap=[dict(block_a=a,block_b=b,overlap=len(test_source_episode_ids[a]&test_source_episode_ids[b]))
        for i,a in enumerate(test_source_episode_ids) for b in list(test_source_episode_ids)[i+1:]],
    note='This episode-level exclusion is verified for the visual experiment only; do not transfer this claim to the shape protocol.')
assert split_verification['learning_unique_source_episodes']==466
assert split_verification['heldout_unique_source_episodes']==150
assert all(v['unique_source_episodes']==50 and v['learning_overlap']==0 for v in split_verification['test_blocks'].values())
assert all(v['overlap']==0 for v in split_verification['between_test_block_overlap'])
test_records=[]; verified=[]; raw={}; learning=[]
for root,final,lr in [(OLD,old,1e-4),(NEW,new,2e-4)]:
    assert final['status']=='completed'
    for r in final['results']:
        if r['phase']=='learn':
            learning.append(dict(r,slow_lr=lr))
            continue
        rel='results/'+r['path'].split('/results/',1)[1]+'/final_eval_results.npz'
        p=root/rel
        h=sha(p)
        assert h==r['result_sha256'],str(p)
        with np.load(p,allow_pickle=False) as z:
            successes=z['successes'].astype(bool)
            steps=np.where(successes,z['action_len'],30).astype(int)
            assert len(steps)==r['n'] and int(successes.sum())==r['successes']
            assert np.isfinite(steps).all() and (steps>=1).all() and (steps<=30).all()
            assert math.isclose(float(steps.mean()),r['mpc_steps_all_mean'],abs_tol=1e-10)
            raw[(lr,r['optimizer'],r['method'],r['chain'],r['seed'],r['tag'])] = {
                'successes':successes.copy(),'steps':steps.copy(),
                'state_0':z['state_0'].copy(),'state_g':z['state_g'].copy()}
        verified.append(dict(path=str(p),sha256=h,n=r['n'],readonly_verified=r.get('readonly_verified'),
                             source_input_sha256=r['source_input_sha256']))
        for i,(success,step) in enumerate(zip(successes,steps)):
            test_records.append(dict(planner=r['optimizer'],method=r['method'],
                slow_lr=lr if r['method']=='v6a' else None,chain=r['chain'],
                chain_initial_seed=schedule[r['chain']-1][0] if r['chain'] else None,
                test_seed=r['seed'],domain=r['tag'],domain_label=LABELS[r['tag']],sample_idx=i,
                success=int(success),mpc_steps=int(step),source_result=str(p)))

paired=[]
for r in comparison['records']:
    k=(r['optimizer'],'v6a',r['chain'],r['test_seed'],r['domain']);i=r['sample_idx']
    a=raw[(1e-4,)+k];b=raw[(2e-4,)+k]
    assert np.array_equal(a['state_0'],b['state_0']) and np.array_equal(a['state_g'],b['state_g'])
    assert int(a['successes'][i])==r['success_1e4'] and int(b['successes'][i])==r['success_2e4']
    assert int(a['steps'][i])==r['mpc_1e4'] and int(b['steps'][i])==r['mpc_2e4']
    paired.append(dict(r,chain_initial_seed=schedule[r['chain']-1][0],domain_label=LABELS[r['domain']]))
assert len(paired)==6300
for r in gd['records']:
    k=('GD','v6a',r['chain'],r['test_seed'],r['domain']);i=r['sample_idx']
    a=raw[(1e-4,)+k];b=raw[(2e-4,)+k]
    assert int(a['successes'][i])==r['success_1e4'] and int(b['successes'][i])==r['success_2e4']
    assert int(a['steps'][i])==r['mpc_steps_1e4'] and int(b['steps'][i])==r['mpc_steps_2e4']

groups=[]
for planner in ['GD','CEM']:
    for method,lr in [('v6a',1e-4),('v6a',2e-4),('adajepa',None),('frozen',None)]:
        rs=[r for r in test_records if r['planner']==planner and r['method']==method and r['slow_lr']==lr]
        chains=group_stats(rs,['chain','chain_initial_seed']) if method=='v6a' else []
        seeds=group_stats(rs,['test_seed'])
        groups.append(dict(planner=planner,method=method,slow_lr=lr,
            learning_chains=3 if method=='v6a' else 0,checkpoint_round=5 if method=='v6a' else None,
            overall=stats(rs),by_domain=group_stats(rs,['domain','domain_label']),
            by_chain=chains,by_test_seed=seeds,
            by_domain_chain=group_stats(rs,['domain','chain']) if method=='v6a' else [],
            by_chain_test_seed=group_stats(rs,['chain','test_seed']) if method=='v6a' else [],
            by_domain_test_seed=group_stats(rs,['domain','test_seed']),
            across_learning_chains_sample_sd_pct=float(np.std([x['success_rate_pct'] for x in chains],ddof=1)) if chains else None,
            across_test_seeds_sample_sd_pct=float(np.std([x['success_rate_pct'] for x in seeds],ddof=1)),
            cumulative_success_by_mpc_step=[dict(step=i,successes=sum(r['success'] and r['mpc_steps']<=i for r in rs),n=len(rs)) for i in range(1,31)]))

learning_groups=[]
for planner in ['GD','CEM']:
    for lr in [1e-4,2e-4]:
        rows=[r for r in learning if r['optimizer']==planner and r['slow_lr']==lr]
        learning_groups.append(dict(planner=planner,slow_lr=lr,overall=batch_stats(rows),
            by_round=[dict(round=i,**batch_stats([r for r in rows if r['round']==i])) for i in range(1,6)],
            by_chain=[dict(chain=c,chain_initial_seed=schedule[c-1][0],**batch_stats([r for r in rows if r['chain']==c])) for c in [1,2,3]],
            by_round_chain=[dict(round=i,chain=c,**batch_stats([r for r in rows if r['round']==i and r['chain']==c])) for c in [1,2,3] for i in range(1,6)]))

excluded=[]
for name in ['visual_naive_gd_n30_3x5_20261029','visual_naive_gd_n50_3x5_20261029']:
    root=BASE/'outputs'/name;s=read(root/'status.json')
    excluded.append(dict(experiment=name,status=s['status'],updated=s['updated'],audited_episodes=s.get('audited_episodes'),
                         planned_episodes=s.get('total_episodes'),source=str(root/'status.json'),
                         reason='用户中止的旧视觉朴素消融，非完整独立测试结果；排除出汇总效果与排名。'))

audit=dict(schema_version=1,generated=datetime.now().astimezone().isoformat(),scope='七视觉域慢学习率消融及背景参照',
    domain_order=list(LABELS),domain_labels=LABELS,
    learning_chain_schedule=[dict(chain=i+1,label=f'链{i+1}（起始s{seeds[0]}）',round_seeds=seeds) for i,seeds in enumerate(schedule)],
    protocol=dict(learning_chains_per_lr_per_planner=3,rounds=5,domains=7,episodes_per_domain_per_round=50,
        learning_episodes_per_lr_per_planner=5250,heldout_test_seeds=[2000,2100,2200],
        heldout_base_tasks=150,test_episodes_per_chain=1050,test_episodes_per_lr_per_planner=3150,
        test_episodes_per_baseline_per_planner=1050,checkpoint_round=5,read_only_persistent_state=True,
        fast_adaptation_in_test=True,max_mpc_iterations=30),
    metric_definition=dict(success='成功以原始 successes 标记为准，第30步成功仍计成功。',
        mpc='全部回合平均实际MPC迭代次数；失败回合统一计30。',
        success_only_mpc='仅成功子集平均；不同方法成功子集不同，不宜单独用于公平效率结论。'),
    comparability_notes=[
        '两个慢学习率使用相同 Ours 初始权重、相同学习/独立测试任务及规划配置，是可直接配对的学习率消融。',
        '三条视觉学习链起始种子为100、400、700；完整五轮种子表单列。不能误标为形状实验的s100/s200/s300。',
        '每条学习链独立完成5轮，每条链末权重均评测；未挑选最好链。',
        '三个测试种子是三个测试任务块，不等于三个独立学习重复。',
        '150个基础独立测试任务在七种视觉条件与三条学习链中重复评价；3150个评测不应视作3150个完全独立样本做显著性检验。',
        '原有 test_summary 的误差条为测试种子间标准差并在每个种子内合并Ours链；本文件另外给出学习链间标准差，二者须明确区分。',
        'Frozen/AdaJEPA使用官方视觉检查点，Ours使用pushobj_T16k_bias_e3；这些背景参照是跨权重条件比较，不能用来隔离Ours机制贡献。',
        'Frozen/AdaJEPA各1050回合为复用数据，不应复制三遍后声称新测试3150回合。',
        '学习曲线仅表示学习期在线表现，最终成功率只用独立测试。'],
    sources=[dict(path=str(p),sha256=sha(p)) for p in [OLD/'final_results.json',NEW/'final_results.json',comparison_path,gd_path,OLD/'protocol.json',NEW/'protocol.json']],
    verification=dict(raw_heldout_files_sha256_rechecked=len(verified),raw_test_episodes_recomputed=len(test_records),
        old_new_paired_episode_count=len(paired),paired_initial_goal_states_exact=True,counts_and_mpc_match_final_results=True,
        comparison_records_match_raw=True,gd_detailed_records_match_raw=True,
        source_episode_split=split_verification,
        learning_curves_source='completed-batch summaries in final_results.json; heldout metrics independently recomputed from NPZ'),
    groups=groups,learning_groups=learning_groups,paired_comparison=comparison['optimizers'],
    excluded_experiments=excluded,raw_source_manifest=verified,
    records=test_records,paired_records=paired)
save('visual_audit.json',audit)
csv_fields=['planner','lr','method','chain','chain_initial_seed','domain','domain_label','seed','sample_idx','success','mpc','source']
with (OUT/'visual_episode_details.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=csv_fields);writer.writeheader()
    for r in test_records:
        writer.writerow(dict(planner=r['planner'],lr=r['slow_lr'],method=r['method'],chain=r['chain'],
            chain_initial_seed=r['chain_initial_seed'],domain=r['domain'],domain_label=r['domain_label'],
            seed=r['test_seed'],sample_idx=r['sample_idx'],success=r['success'],mpc=r['mpc_steps'],source=r['source_result']))
seed_fields=['planner','lr','method','test_seed','n','successes','failures','success_rate_pct','mpc_steps_all_mean','mpc_steps_success_mean']
with (OUT/'visual_test_seed_details.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=seed_fields,extrasaction='ignore');writer.writeheader()
    for g in groups:
        for row in g['by_test_seed']:
            writer.writerow(dict(row,planner=g['planner'],lr=g['slow_lr'],method=g['method']))

# Freeze a report snapshot; never interpret partial learning scores as final test results.
s=read(RUN/'status.json');sync=read(RUN/'sync_status.json');arms=[]
for planner,method,label in [('GD','no_familiar_read','GD：关闭熟悉度读取保护'),('GD','no_familiar_write','GD：关闭熟悉度写入保护'),('CEM','no_familiarity','CEM：同时关闭熟悉度读写保护')]:
    finished=[r for r in s.get('finished',[]) if r['optimizer']==planner and r['method']==method]
    completed_learn=[r for r in finished if r['phase']=='learn'];completed_test=[r for r in finished if r['phase']=='test']
    active=[r for r in s.get('active',[]) if r['optimizer']==planner and r['method']==method]
    learning_n=sum(r['n'] for r in completed_learn)
    active_n=sum(r.get('completed_episodes',0) for r in active)
    arms.append(dict(planner=planner,method=method,label=label,
        completed_learning_batches=len(completed_learn),completed_learning_episodes=learning_n,
        active_reported_episodes=active_n,learning_episodes_planned=1750,test_episodes_planned=1050,
        completed_test_batches=len(completed_test),completed_test_episodes=sum(r['n'] for r in completed_test),
        active=active,completed_rounds=learning_n//350,
        partial_learning_metrics=batch_stats(completed_learn) if completed_learn else None,
        final_heldout_result_available=len(completed_test)==21))
snapshot=dict(generated=datetime.now().astimezone().isoformat(),status_updated=s['updated'],status=s['status'],
    total_episodes=s['total_episodes'],audited_episodes=s['audited_episodes'],completed_jobs=s['completed_jobs'],
    total_jobs=s['total_jobs'],active_reported_episodes=sum(a['active_reported_episodes'] for a in arms),
    errors=s.get('errors',[]),sync=sync,arms=arms,
    scientific_reporting_note='此为报告生成时的进度快照。三组尚处学习期，没有完整独立测试结果，不能纳入消融最终效果比较或排名。',
    source_status=str(RUN/'status.json'),source_sync=str(RUN/'sync_status.json'))
save('running_snapshot.json',snapshot)
print(json.dumps({'groups':[{k:g[k] for k in ['planner','method','slow_lr','overall']} for g in groups],
                  'verification':audit['verification'],'snapshot':snapshot},ensure_ascii=False,indent=2))
