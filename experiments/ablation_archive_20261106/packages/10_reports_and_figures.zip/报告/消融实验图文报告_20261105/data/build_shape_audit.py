from pathlib import Path
import json,csv,hashlib,re,datetime
from collections import defaultdict
import numpy as np

OUT=Path(__file__).resolve().parent
B=Path(r'D:\ADAJEPA\outputs')
CORE=B/'shape_core_gd_singlechain_5round_20261031'
REF=CORE/'reference_shape_report'
SHAPES=['I','L','square','Z','small_tee','plus','T']
SEEDS=[2000,2100,2200]
CHAIN_NAMES={1:'s100',2:'s400',3:'s700'}
ROOTS={
'core':CORE,
'naive':B/'shape_naive_gd_n50_3x5_heldout_20261031',
'ema':B/'shape_ema_slow_gd_singlechain_5round_20261101',
'ext':B/'shape_slow_lr_extended_gd_singlechain_5round_20261101',
'lr3':B/'shape_slow_lr_3e4_gd_singlechain_5round_20261102',
'familiar':B/'shape_no_familiarity_gd_singlechain_5round_20261104'}

def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def metric(rows):
 s=np.array([x['success'] for x in rows],bool); m=np.array([x['mpc_steps'] for x in rows],float)
 return dict(n=len(rows),successes=int(s.sum()),success_rate=float(s.mean()),success_rate_percent=float(s.mean()*100),mpc_steps_all=float(m.mean()),mpc_steps_success=float(m[s].mean()) if s.any() else None,mpc_steps_sum=int(m.sum()))
def aggregate(rows,key,values=None):
 if values is None: values=sorted(set(x[key] for x in rows))
 return {str(v):metric([x for x in rows if x[key]==v]) for v in values if any(x[key]==v for x in rows)}

TEST=[];LEARN=[];FILE_AUDITS=[];STATES={};METHODS=[]
BASESTATES={}
for seed in SEEDS:
 for d in SHAPES:
  f=CORE/'results/test/GD/adajepa_same'/f'seed_{seed}'/d/'final_eval_results.npz'
  with np.load(f) as z:BASESTATES[(seed,d)]=(z['state_0'].copy(),z['state_g'].copy())

def raw_rows(root,method,mid,chain=1):
 protocol=read(root/'protocol.json'); rows=[]; learns=[]; files=[]; matches=0
 testbase=root/'results/test/GD'/method
 if method=='naive':testbase=testbase/f'chain_{chain}'
 for seed in SEEDS:
  for d in SHAPES:
   f=testbase/f'seed_{seed}'/d/'final_eval_results.npz'
   a=read(f.parent/'audit.json'); h=sha(f); assert h==a['result_sha256'],str(f)
   with np.load(f) as z:
    s=z['successes'].astype(bool); l=z['action_len']; assert len(s)==50 and np.isinf(l[~s]).all()
    eq=all(np.array_equal(z[k],b) for k,b in zip(['state_0','state_g'],BASESTATES[(seed,d)]));assert eq,str(f)
    matches+=len(s)
    for i in range(len(s)):
     rows.append(dict(method_id=mid,phase='test',planner='GD',chain=CHAIN_NAMES[chain],round=5,seed=seed,domain=d,sample_idx=i,success=int(s[i]),mpc_steps=int(l[i]) if s[i] else 30,source=str(f),pairing_state_verified=True))
   item=dict(path=str(f),sha256=h,phase='test',n=50,result_hash_verified=True,states_equal_adajepa_same=eq,readonly_verified=a.get('readonly_verified'))
   FILE_AUDITS.append(item);files.append(str(f))
 teststreams=protocol['streams']; refstreams=read(CORE/'protocol.json')['streams']
 sm=0
 for k,v in teststreams.items():
  if v.get('phase')=='test':
   expected=refstreams.get(k)
   assert expected and all(v.get(t)==expected.get(t) for t in ['sha256','indices','ep_idx','seed','shape']),k
   sm+=1
 learnbase=root/'results/learn/GD'/method
 if method=='naive':learnbase=root/'results/learn/GD'/f'chain_{chain}'
 for f in sorted(learnbase.glob('*/final_eval_results.npz')):
  q=re.match(r'chunk_\d+_r(\d+)_(.*)',f.parent.name);assert q,str(f)
  rnd=int(q[1]);d=q[2];seed=protocol['seed_schedule'][chain-1][rnd-1]
  a=read(f.parent/'audit.json');h=sha(f);assert h==a['result_sha256'],str(f)
  with np.load(f) as z:
   s=z['successes'].astype(bool);l=z['action_len'];assert len(s)==50 and np.isinf(l[~s]).all()
   for i in range(len(s)):
    learns.append(dict(method_id=mid,phase='learn',planner='GD',chain=CHAIN_NAMES[chain],round=rnd,seed=seed,domain=d,sample_idx=i,success=int(s[i]),mpc_steps=int(l[i]) if s[i] else 30,source=str(f),pairing_state_verified=''))
  FILE_AUDITS.append(dict(path=str(f),sha256=h,phase='learn',n=50,result_hash_verified=True))
  files.append(str(f))
 TEST.extend(rows);LEARN.extend(learns)
 return rows,learns,files,dict(state_matched_to_adajepa_same_n=matches,test_stream_manifest_matched_batches=sm)

def add_method(mid,name,root,rows,learns,files,chains=1,chainnames=None,slow_lr=None,ema_alpha=None,mechanism='',scope='matched_single_chain',checks=None,limitations=None):
 obj=dict(id=mid,name=name,planner='GD',experiment_root=str(root),learning_chains=chains,learning_chain_ids=chainnames if chainnames is not None else ['s100'],learning_episodes_per_chain=1750 if learns or mid.startswith('ours') else 0,learning_protocol='5轮 × 7域 × 50回合；每轮全域固定顺序' if chains else '无跨回合学习链',slow_lr=slow_lr,ema_alpha=ema_alpha,comparison_scope=scope,overall=metric(rows),domains=aggregate(rows,'domain',SHAPES),test_seeds=aggregate(rows,'seed',SEEDS),domain_test_seeds={d:aggregate([r for r in rows if r['domain']==d],'seed',SEEDS) for d in SHAPES},learning_rounds=aggregate(learns,'round',range(1,6)) if learns else {},learning_round_domains={str(r):aggregate([x for x in learns if x['round']==r],'domain',SHAPES) for r in range(1,6)} if learns else {},source_files=files,source=files[0],mechanism=mechanism,verification=checks or {},limitations=limitations or [])
 obj['test_seed_success_rate_sd']=float(np.std([obj['test_seeds'][str(s)]['success_rate'] for s in SEEDS],ddof=1))
 if chains==1:obj['limitations'].append('只有一条学习链；三个测试种子不是三次独立学习重复。')
 METHODS.append(obj);return obj

specs=[
('core','adajepa_same','同权重 AdaJEPA',None,'每回合从与 Ours 相同预训练权重开始，保留回合内快速适应，不继承跨回合慢记忆。'),
('core','shared_slow','单一共享慢学习器',1e-4,'将多域记忆压缩为一个共享慢预测器和全局回放；取消分域、pending、合并、吸收；仍保留熟悉度、成熟度和拒收保护。'),
('core','no_maturity_read','去掉成熟度读取门控',1e-4,'仅允许未成熟慢学习器参与读取候选；写入与吸收相关成熟度机制以及熟悉度保护仍保留。'),
('core','slow_lr_low','慢学习率 5e-5',5e-5,'仅改变慢预测器梯度学习率；其余完整 Ours 机制保留。'),
('core','slow_lr_high','慢学习率 2e-4',2e-4,'仅改变慢预测器梯度学习率；其余完整 Ours 机制保留。'),
('ema','ema_slow','慢参数 EMA（α=1e-4）',None,'取消经验回放及慢梯度训练，以回合末快参数的 EMA 更新跨回合慢参数；适配参数范围含编码器与预测器，和完整 Ours 的慢预测器训练范围不同。'),
('ext','slow_lr_5e4','慢学习率 5e-4',5e-4,'仅改变慢预测器梯度学习率；其余完整 Ours 机制保留。'),
('ext','slow_lr_1e2','慢学习率 0.01',1e-2,'仅改变慢预测器梯度学习率；其余完整 Ours 机制保留。'),
('lr3','slow_lr_3e4','慢学习率 3e-4',3e-4,'仅改变慢预测器梯度学习率；其余完整 Ours 机制保留。'),
('familiar','no_familiarity','关闭熟悉度读写保护',1e-4,'取消熟悉度对读取候选与直接写入/验证的阻断；保留 pending、成熟度、拒收及其他记忆管理。取消保护不等于每回合必然写入。')]
for rk,mid,name,lr,desc in specs:
 rows,learns,files,check=raw_rows(ROOTS[rk],mid,mid)
 lim=[]
 if mid=='ema_slow':lim.append('EMA α 不是梯度学习率；α=1e-4 每回合更新的半衰期约6931回合，不能据此否定所有 EMA 设置。')
 o=add_method(mid,name,ROOTS[rk],rows,learns,files,chains=0 if mid=='adajepa_same' else 1,chainnames=[] if mid=='adajepa_same' else ['s100'],slow_lr=lr,ema_alpha=1e-4 if mid=='ema_slow' else None,mechanism=desc,checks=check,limitations=lim)
 if mid!='adajepa_same':assert len(learns)==1750
 # Independently recomputed result agrees with historical summary.
 exp=read(ROOTS[rk]/'test_summary.json')['results'][mid]['all']['pooled']
 assert o['overall']['successes']==exp['successes'] and abs(o['overall']['mpc_steps_all']-exp['mpc_steps_all'])<1e-10

nr=[];nl=[];nf=[]
for c in [1,2,3]:
 mid='naive_'+CHAIN_NAMES[c];rows,learns,files,check=raw_rows(ROOTS['naive'],'naive',mid,c)
 nr+=rows;nl+=learns;nf+=files
 add_method(mid,'朴素继承（'+CHAIN_NAMES[c]+'）',ROOTS['naive'],rows,learns,files,chainnames=[CHAIN_NAMES[c]],mechanism='将上回合末快速适配参数直接作为下一回合起点；无慢学习器、分域库与保护路由。',scope='matched_single_chain' if c==1 else 'additional_training_chain',checks=check)
add_method('naive_all3','朴素继承（三链合计）',ROOTS['naive'],nr,nl,nf,chains=3,chainnames=list(CHAIN_NAMES.values()),mechanism='三个独立学习链的第五轮末状态分别接受同一 H7t3 测试。',scope='three_chain_reference',limitations=['3150次执行包含相同测试任务在不同已学习模型上的重复，不是3150个不同任务。'])

with (REF/'shape7_episodes.csv').open(encoding='utf-8-sig',newline='') as f:orig=list(csv.DictReader(f))
def original_rows(method,units,mid):
 out=[]
 for x in orig:
  if x['planner']=='GD' and x['method']==method and x['unit'] in units:
   out.append(dict(method_id=mid if method!='ours' else 'ours_'+x['unit'],phase='test',planner='GD',chain=x['unit'],round=5 if method=='ours' else '',seed=int(x['seed']),domain=x['shape'],sample_idx=int(x['sample_idx']),success=int(x['success']),mpc_steps=int(x['mpc_steps']),source=str(REF/'shape7_episodes.csv'),pairing_state_verified=False))
 return out

orr=read(REF/'ours_rounds.json')
for chain in ['s100','s400','s700']:
 rows=original_rows('ours',[chain],'ours_'+chain);TEST+=rows
 o=add_method('ours_'+chain,'Ours（'+chain+'，慢学习率 1e-4）',REF,rows,[],[str(REF/'shape7_episodes.csv'),str(REF/'ours_rounds.json')],chainnames=[chain],slow_lr=1e-4,mechanism='完整快慢适应、多慢预测器记忆及熟悉度/成熟度保护；第五轮末状态，测试时冻结持久记忆写入。',scope='matched_single_chain' if chain=='s100' else 'additional_training_chain',limitations=['沿用原形状报告；本地逐回合参考 CSV 不含初始/目标状态，无法在此次审计中重新对 Ours 做逐状态严格配对。'])
 for rnd in range(1,6):
  v=orr['GD']['per_chain'][chain][str(rnd)]['all'];n=v['episodes'];succ=round(v['rate']*n/100)
  o['learning_rounds'][str(rnd)]=dict(n=n,successes=succ,success_rate=succ/n,success_rate_percent=succ/n*100,mpc_steps_all=None,mpc_steps_success=None,mpc_steps_sum=None)
 o['learning_episodes_per_chain']=1750
o=add_method('ours_all3','Ours（三链合计）',REF,original_rows('ours',['s100','s400','s700'],'ours_all3'),[],[str(REF/'shape7_episodes.csv')],chains=3,chainnames=['s100','s400','s700'],slow_lr=1e-4,mechanism='原报告完整 Ours 三条学习链第五轮末状态汇总。',scope='three_chain_reference',limitations=['仅供三链朴素继承匹配比较；不得替代单链消融的 s100 基线。'])
o['learning_episodes_per_chain']=1750
for rnd in range(1,6):
 vals=[orr['GD']['per_chain'][chain][str(rnd)]['all'] for chain in ['s100','s400','s700']]
 n=sum(v['episodes'] for v in vals);succ=sum(round(v['rate']*v['episodes']/100) for v in vals)
 o['learning_rounds'][str(rnd)]=dict(n=n,successes=succ,success_rate=succ/n,success_rate_percent=succ/n*100,mpc_steps_all=None,mpc_steps_success=None,mpc_steps_sum=None)
for m,name in [('frozen','Frozen（原报告官方权重）'),('adajepa','AdaJEPA（原报告官方权重）')]:
 mid=m+'_official';rows=original_rows(m,['official'],mid);TEST+=rows
 add_method(mid,name,REF,rows,[],[str(REF/'shape7_episodes.csv')],chains=0,chainnames=['official'],mechanism='原形状报告官方预训练权重参考；'+('不进行测试时适配。' if m=='frozen' else '每回合重置并作快速适配，不保留跨回合学习。'),scope='different_checkpoint_reference',limitations=['官方预训练权重与 Ours/本次消融不同，不能把差值解释为仅由消融结构造成。'])

baseline={ (x['seed'],x['domain'],x['sample_idx']):x for x in TEST if x['method_id']=='ours_s100'}
def keychanges(rows):
 changes=dict(n=len(rows),ours_success_ablation_failure=0,ours_failure_ablation_success=0,both_success=0,both_failure=0)
 for x in rows:
  a=baseline[(x['seed'],x['domain'],x['sample_idx'])]['success'];b=x['success']
  key='both_success' if a and b else 'both_failure' if not a and not b else 'ours_success_ablation_failure' if a else 'ours_failure_ablation_success'
  changes[key]+=1
 return changes
for m in METHODS:
 if m['comparison_scope']=='matched_single_chain' and m['id']!='ours_s100':
  rows=[x for x in TEST if x['method_id']==m['id']]
  m['pairing_vs_ours']=dict(level='protocol_key_only_not_state_verified',basis='同一 H7t3 种子、形状、sample_idx；新增组已核验状态一致，但原 Ours CSV 缺状态，不能称为此次已严格验证的逐状态配对。',overall_key_matched_changes=keychanges(rows),domains_key_matched_changes={d:keychanges([r for r in rows if r['domain']==d]) for d in SHAPES},statistical_significance_claimed=False)
base=next(x for x in METHODS if x['id']=='ours_s100')['overall']
for m in METHODS:
 m['delta_vs_ours_s100']=dict(successes=m['overall']['successes']-base['successes'] if m['overall']['n']==base['n'] else None,success_rate_pp=(m['overall']['success_rate']-base['success_rate'])*100,mpc_steps_all=m['overall']['mpc_steps_all']-base['mpc_steps_all'])

# Exact-output diagnostic: high LR is numerically equal on outcomes, not all actions.
lrbase=ROOTS['ext']/'results/test/GD/slow_lr_1e2'
samebase=CORE/'results/test/GD/adajepa_same'
equal={k:0 for k in ['successes','action_len','actions','state_0','state_g']}
diag=dict(test_episodes=0,episodes_any_slow_route=0,episodes_final_slow_read=0,routing_decisions=0,final_active_learners=169)
for f in lrbase.glob('*/*/final_eval_results.npz'):
 with np.load(f) as a,np.load(samebase/f.relative_to(lrbase)) as b:
  for k in equal:equal[k]+=int(np.array_equal(a[k],b[k],equal_nan=True))
for f in lrbase.glob('*/*/episodes.jsonl'):
 for line in f.read_text('utf-8').splitlines():
  e=json.loads(line);rr=e.get('route',[])
  diag['test_episodes']+=1;diag['episodes_any_slow_route']+=int(any(q.get('best') is not None for q in rr))
  diag['episodes_final_slow_read']+=int(e.get('read') is not None);diag['routing_decisions']+=len(rr)
diag['exactly_equal_batches_vs_adajepa_same']=equal;diag['total_test_batches']=21
diag['interpretation']='0.01与同权重AdaJEPA的成功/失败及步数逐回合相同，但三批动作不完全相同；慢知识仅少量回合被实际读取，不表示没有训练。'
next(m for m in METHODS if m['id']=='slow_lr_1e2')['diagnostics']=diag

order=['ours_s100','adajepa_same','naive_s100','ema_slow','shared_slow','no_maturity_read','no_familiarity','slow_lr_low','slow_lr_high','slow_lr_3e4','slow_lr_5e4','slow_lr_1e2','ours_s400','ours_s700','naive_s400','naive_s700','ours_all3','naive_all3','frozen_official','adajepa_official']
METHODS.sort(key=lambda x:order.index(x['id']))
data=dict(schema_version='1.0',generated_at=datetime.datetime.now().astimezone().isoformat(),scope='已完成七形状域 GD 消融；新启动读/写拆分及 CEM 消融不并入完成结果',domain_order=SHAPES,test_seeds=SEEDS,metrics_definition={'success_rate':'0到1；success_rate_percent为百分数','mpc_steps_all':'全部执行回合平均MPC次数，失败按30步；不是环境原始控制步数','mpc_steps_success':'仅该方法成功回合平均MPC次数；不同方法成功子集不同','test_seed_success_rate_sd':'三个测试seed块的样本标准差；不代表独立学习重复波动'},protocol={'learning_chain_seed_schedule':read(ROOTS['naive']/'protocol.json')['seed_schedule'],'test_episodes_per_learned_chain':1050,'each_domain_test_executions':150,'round_endpoint':5,'test_persistent_memory_readonly':True,'fast_adaptation_during_test':True,'learning_test_split':'片段索引排除；未声称原始轨迹层级完全互斥，也未声称不同测试种子任务互不重叠','shared_checkpoint_sha256':read(CORE/'protocol.json')['checkpoint_sha256']},methods=METHODS,raw_file_verification=FILE_AUDITS,csv={'test':str(OUT/'shape_test_episodes.csv'),'learn':str(OUT/'shape_learning_episodes.csv')},notes=['学习阶段成功率不能当作第五轮后独立测试成功率。','Ours沿用原始CSV；其逐回合键匹配变化只作描述，未以其做严格配对显著性推断。','已重算全部本次消融NPZ且验证每个NPZ和保存审计哈希一致。','两个原报告官方权重基线仅单独参考。'])
(OUT/'shape_audit.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
for name,rows in [('shape_test_episodes.csv',TEST),('shape_learning_episodes.csv',LEARN)]:
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
notes=['七形状域完成消融数据审计','所有指标已从保存NPZ/原报告逐回合CSV重新计算。','原始NPZ已核验文件哈希及新增测试组初始/目标状态与同权重AdaJEPA完全一致。','Ours原报告CSV缺状态，只提供protocol key matched变化，不能当作此次重新验证的严格状态配对。','训练/测试片段索引排除，不宣称原始轨迹级独立或不同测试种子任务互不重叠。','']
for m in METHODS:notes.append(f"{m['id']}: {m['overall']['successes']}/{m['overall']['n']}, {m['overall']['success_rate_percent']:.6f}%, MPC(all)={m['overall']['mpc_steps_all']:.6f}, MPC(success)={m['overall']['mpc_steps_success']:.6f}")
notes+=['',f'已核验NPZ {len(FILE_AUDITS)}份，逐回合测试CSV {len(TEST)}行，学习CSV {len(LEARN)}行。','原始Ours五轮仅已有成功率汇总，MPC留空，未伪造逐回合学习数据。']
(OUT/'shape_audit_notes.txt').write_text('\n'.join(notes),encoding='utf-8')
print('\n'.join(notes))
