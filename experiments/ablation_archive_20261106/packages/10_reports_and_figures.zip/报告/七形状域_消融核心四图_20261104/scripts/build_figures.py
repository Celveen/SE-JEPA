"""Create compact, auditable scientific figures from recorded shape ablations."""
from pathlib import Path
import sys, json, hashlib, shutil, html, csv, io, zipfile
sys.path.insert(0, r'D:\ADAJEPA\tmp\T_figure_python_deps')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.backends.backend_pdf import PdfPages
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1] if Path(__file__).parent.name=='scripts' else Path(r'D:\ADAJEPA\报告\七形状域_消融核心四图_20261104')
SOURCE = ROOT/'data/heldout_episode_data.json'
if not SOURCE.exists(): SOURCE = Path(r'D:\ADAJEPA\报告\七形状域_继承与EMA消融图表_20261104\data\plot_data.json')
for sub in ['data','figures','preview','PNG_600dpi','SVG_矢量','scripts']:
    (ROOT/sub).mkdir(parents=True, exist_ok=True)
D = json.loads(SOURCE.read_text(encoding='utf-8'))
ROWS = D['rows']
M = ['adajepa_same','naive','ema_slow','ours']
DOM = ['I','L','square','Z','small_tee','plus','T']
DLAB = ['I','L','square','Z','smallT','+','T']
SEEDS = [2000,2100,2200]
LABEL = dict(zip(M,['AdaJEPA','Naive inheritance','Slow-parameter EMA','Ours']))
SHORT = dict(zip(M,['AdaJEPA','Naive\ninheritance','Slow-parameter\nEMA','Ours']))
COLOR = dict(zip(M,['#7BCDBF','#CFCAC2','#AAB2E8','#7FB5E8']))
LS = dict(zip(M,['-.','--',':','-']))
GD = '#708CC3'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.labelsize':10,
    'axes.titlesize':12,'axes.linewidth':.65,'axes.edgecolor':'#555555',
    'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,'text.color':'#151515',
    'axes.labelcolor':'#151515','xtick.color':'#333333','ytick.color':'#333333',
    'pdf.fonttype':42,'ps.fonttype':42,'figure.facecolor':'white','savefig.facecolor':'white',
    'svg.hashsalt':'shape-core-four-20261104'})

def rows(method, domain=None, seed=None):
    return [r for r in ROWS if r['method']==method and (domain is None or r['domain']==domain)
            and (seed is None or r['test_seed']==seed)]

def stat(rr):
    return {'n':len(rr),'successes':sum(r['success'] for r in rr),
            'rate':100*np.mean([r['success'] for r in rr]),
            'mpc':np.mean([r['mpc_steps'] for r in rr])}

def summary(method, domain=None):
    s=stat(rows(method,domain))
    blocks=[stat(rows(method,domain,seed)) for seed in SEEDS]
    for key in ['rate','mpc']:s[key+'_sd']=float(np.std([x[key] for x in blocks],ddof=1))
    return s

def tidy(ax, top, ticks, bars=True):
    ax.set_axisbelow(True)
    ax.set_ylim(0,top);ax.set_yticks(ticks)
    ax.grid(axis='y' if bars else 'both',color='#E3E3E3' if bars else '#D0D0D0',lw=.5,ls='-' if bars else ':')
    if bars:
        ax.set_facecolor('#F7F7F7')
        for sp in ax.spines.values():sp.set_color('#D0D0D0')
    ax.tick_params(length=2.8,pad=3)

def legend(fig, methods=M, lines=False, y=.99):
    hs=[Line2D([],[],color=GD,ls=LS[m],lw=1.9 if m=='ours' else 1.6,marker=None,label=LABEL[m])
        if lines else Patch(facecolor=COLOR[m],label=LABEL[m]) for m in methods]
    fig.legend(handles=hs,loc='upper center',bbox_to_anchor=(.53,y),ncol=len(methods),frameon=False,
               columnspacing=2.4,handlelength=3 if lines else 2)

def foot(fig, lines, left=.065, bottom=.025, gap=.041):
    for i,line in enumerate(reversed(lines)):
        fig.text(left,bottom+i*gap,line,fontsize=8.3,color='#555555')

def bar(ax,x,method,s,key,width=.6,fs=9,offset=1.3):
    value=float(s[key]);err=float(s[key+'_sd'])
    ax.bar(x,value,width,color=COLOR[method],edgecolor='white',linewidth=.6,
           yerr=err,capsize=2,error_kw={'elinewidth':.65,'capthick':.65})
    ax.text(x,value+err+offset,f'{value:.1f}' if key=='rate' else f'{value:.2f}',
            ha='center',va='bottom',fontsize=fs)

MAN=[]
COMBINED=ROOT/'七形状域_消融核心四图.pdf'
PDF=PdfPages(COMBINED)
def save(fig,stem,title,caption,kind='heldout'):
    fig.canvas.draw();renderer=fig.canvas.get_renderer();w,h=fig.canvas.get_width_height()
    for t in fig.findobj(matplotlib.text.Text):
        if t.get_visible() and t.get_text():
            b=t.get_window_extent(renderer)
            assert b.x0>=-.5 and b.y0>=-.5 and b.x1<=w+.5 and b.y1<=h+.5,(stem,t.get_text(),b.bounds)
    for ax in fig.axes:
        for line in ax.lines:
            if line.get_gid()=='ours':assert line.get_linestyle()=='-' and line.get_marker() in [None,'None','',' ']
    fig.savefig(ROOT/'figures'/f'{stem}.pdf',metadata={'Title':title,'Subject':caption,'Creator':'Python / Matplotlib'})
    PDF.savefig(fig)
    fig.savefig(ROOT/'preview'/f'{stem}.png',dpi=180)
    fig.savefig(ROOT/'PNG_600dpi'/f'{stem}.png',dpi=600)
    fig.savefig(ROOT/'SVG_矢量'/f'{stem}.svg')
    MAN.append({'stem':stem,'title':title,'caption':caption,'data_type':kind})
    plt.close(fig);print('Saved',stem,flush=True)

assert len(ROWS)==4200
assert len({(r['method'],r['test_seed'],r['domain'],r['sample_idx']) for r in ROWS})==4200
for m,n in [('adajepa_same',808),('naive',679),('ema_slow',795),('ours',855)]:
    assert summary(m)['n']==1050 and summary(m)['successes']==n

fig,axes=plt.subplots(1,2,figsize=(12.8,4.3))
fig.subplots_adjust(left=.065,right=.99,top=.78,bottom=.25,wspace=.22);legend(fig)
for ax,key,title,top,ticks in [(axes[0],'rate','(a) Held-out success rate',110,range(0,101,20)),
                              (axes[1],'mpc','(b) Mean MPC steps (all episodes)',21,range(0,21,5))]:
    tidy(ax,top,ticks)
    for i,m in enumerate(M):bar(ax,i,m,summary(m),key,fs=10,offset=1.9 if key=='rate' else .35)
    ax.set_xticks(range(4),[SHORT[m] for m in M]);ax.set_title(title,loc='left',pad=11)
    ax.set_ylabel('Success Rate (%)' if key=='rate' else 'MPC Steps')
foot(fig,['1,050 test episodes per method. Error bars: +/- 1 SD across three test seeds.',
          'Round-5 endpoints, one learning chain; AdaJEPA resets per episode. Failures count as 30 MPC steps.'])
save(fig,'01_overall_performance','总体性能：成功率与MPC步数',
     '七形状域GD独立测试，各方法1050回合；左为成功率，右为所有回合平均MPC步数，失败计30步。误差棒为三个测试种子的样本标准差，不是学习链的波动。')

fig,axes=plt.subplots(2,1,figsize=(12.8,7.8),sharex=True)
fig.subplots_adjust(left=.065,right=.99,top=.87,bottom=.15,hspace=.38);legend(fig,y=.985)
for ax,key,title,top,ticks in [(axes[0],'rate','(a) Held-out success by shape',110,range(0,101,20)),
                              (axes[1],'mpc','(b) Mean MPC steps by shape',32,range(0,31,5))]:
    tidy(ax,top,ticks)
    for j,m in enumerate(M):
        for i,d in enumerate(DOM):bar(ax,i+(j-1.5)*.20,m,summary(m,d),key,width=.19,fs=8.1,offset=1.3 if key=='rate' else .55)
    ax.set_xticks(range(7),DLAB);ax.tick_params(labelbottom=True);ax.set_xlim(-.6,6.6)
    ax.set_title(title,loc='left',pad=11);ax.set_ylabel('Success Rate (%)' if key=='rate' else 'MPC Steps')
foot(fig,['150 test episodes per shape and method. Error bars: +/- 1 SD across three test seeds.',
          'Round-5 endpoints, single learning chain; identical evaluation protocol. Failures count as 30 MPC steps.'],bottom=.028,gap=.026)
save(fig,'02_per_shape_performance','七形状域性能：成功率与MPC步数',
     '每个形状、每种方法150回合。上图显示成功率，下图显示所有回合平均MPC步数；直接展示不同形状的收益与退步，不仅看总体均值。')

BUDGETS={}
fig,ax=plt.subplots(figsize=(10.6,4.7));fig.subplots_adjust(left=.08,right=.98,top=.79,bottom=.23);legend(fig,lines=True)
tidy(ax,100,range(0,101,20),bars=False)
for m in M:
    blocks=[]
    for seed in SEEDS:
        rr=rows(m,seed=seed)
        blocks.append([100*sum(r['success'] and r['mpc_steps']<=k for r in rr)/len(rr) for k in range(1,31)])
    a=np.asarray(blocks);mu=a.mean(axis=0);sd=a.std(axis=0,ddof=1)
    assert np.all(np.diff(mu)>=0) and abs(mu[-1]-summary(m)['rate'])<1e-9
    ax.fill_between(range(1,31),np.maximum(0,mu-sd),np.minimum(100,mu+sd),color=GD,alpha=.045,lw=0)
    ax.plot(range(1,31),mu,color=GD,ls=LS[m],lw=1.9 if m=='ours' else 1.6,marker=None,gid=m)
    BUDGETS[m]={str(k):float(mu[k-1]) for k in [1,5,10,15,20,25,30]}
ax.set(xlim=(0,30),xticks=[0,5,10,15,20,25,30],xlabel='MPC Step Budget',ylabel='Success Rate (%)')
ax.set_title('Success within a fixed MPC budget - GD',loc='left',pad=11)
foot(fig,['1,050 test episodes per method. Shading: +/- 1 SD across three test seeds.',
          'Recorded action steps 1-30; unsuccessful episodes stay in the denominator.'],left=.08,bottom=.028,gap=.038)
save(fig,'03_mpc_budget_success','MPC预算与成功率',
     '横轴为允许的MPC步数，纵轴为预算内成功回合占全部回合的比例。曲线从实际记录的第1步开始；第30步终点等于最终成功率。阴影为测试种子间标准差。')

# The fourth figure is appended only from an independently audited learning-stage dataset.
round_path=ROOT/'data/learning_round_audit.json'
if not round_path.exists():round_path=Path(r'D:\ADAJEPA\outputs\shape_round_data_audit_20261104.json')
if not round_path.exists():
    PDF.close()
    raise RuntimeError('First three figures generated; audited learning-stage round data required before completion.')
R=json.loads(round_path.read_text(encoding='utf-8'))
# This schema is produced by the audit agent; normalization is kept explicit below.
ROUND_METHODS={m:[{'round':i,'n':v['n'],'successes':v['successes'],'success_rate':v['success_rate_percent'],
                   'mpc_steps':v['mpc_steps_all'],'seed':v['seed'],'phase':'online_learning'}
                  for i in range(1,6) for v in [R['online_learning'][m]['rounds'][str(i)]]]
               for m in ['naive','ema_slow','ours']}
fig,ax=plt.subplots(figsize=(11.5,5.0))
fig.subplots_adjust(left=.08,right=.98,top=.75,bottom=.27)
learn_methods=['naive','ema_slow','ours'];legend(fig,learn_methods,lines=True,y=.99)
fig.text(.53,.87,'LEARNING-STAGE RESULTS - NOT ROUND-BY-ROUND HELD-OUT EVALUATION',
         ha='center',fontsize=9,color='#555555')
tidy(ax,100,range(40,101,10),bars=False)
ax.set_ylim(40,100)
for m in learn_methods:
    seq=ROUND_METHODS[m]
    assert [v['round'] for v in seq]==[1,2,3,4,5]
    assert all(v['n']==350 for v in seq)
    ys=[v['success_rate'] for v in seq]
    ax.plot(range(1,6),ys,color=GD,ls=LS[m],lw=1.9 if m=='ours' else 1.6,marker=None,gid=m)
    for x,y in zip(range(1,6),ys):
        ax.text(x,y+(2.2 if m=='ours' else -3.3),f'{y:.1f}',ha='center',va='center',fontsize=9,color='#3E536F')
ax.set(xlim=(.8,5.2),xticks=[1,2,3,4,5],xlabel='Learning Round',ylabel='Success Rate (%)')
ax.set_title('Online learning success over five rounds - GD',loc='left',pad=11)
foot(fig,['350 learning episodes per round and method; one chain. No error bars from training repeats.',
          'Learning seeds change by round (100, 200, 300, 1000, 1100); values are not fixed-test learning curves.',
          'AdaJEPA: no comparable five-round learning log. All four methods appear in held-out Figures 1-3.'],left=.08,bottom=.02,gap=.039)
save(fig,'04_learning_stage_rounds','五轮学习过程（学习阶段，非逐轮独立测试）',
     '仅展示Ours原s100链、朴素继承第1链、EMA的真实学习阶段结果，每轮350回合。每轮学习种子不同，不能据此证明固定测试集上的改善或遗忘；AdaJEPA没有可比的五轮学习日志，故不画水平线。当前三组均仅第5轮有独立测试。','learning_only')
PDF.close()
assert len(PdfReader(COMBINED).pages)==4

for source,target in [(SOURCE,ROOT/'data/heldout_episode_data.json'),(round_path,ROOT/'data/learning_round_audit.json'),
                      (Path(__file__),ROOT/'scripts/build_figures.py')]:
    if source.resolve()!=target.resolve():shutil.copy2(source,target)
(ROOT/'data/budget_success_rates.json').write_text(json.dumps(BUDGETS,ensure_ascii=False,indent=2),encoding='utf-8')
table=[{'method':m,'label':LABEL[m],**summary(m)} for m in M]
(ROOT/'data/summary.json').write_text(json.dumps(table,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'figure_manifest.json').write_text(json.dumps(MAN,ensure_ascii=False,indent=2),encoding='utf-8')
for name,items in [('heldout_episodes.csv',ROWS),('learning_round_metrics.csv',[{'method':m,**r} for m in learn_methods for r in ROUND_METHODS[m]])]:
    with (ROOT/'data'/name).open('w',encoding='utf-8-sig',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(items[0]));wr.writeheader();wr.writerows(items)

cards=[]
for i,x in enumerate(MAN,1):
    stem=x['stem']
    cards.append(f'<article><h2>{i:02d} · {html.escape(x["title"])}</h2><img src="preview/{stem}.png"><p>{html.escape(x["caption"])}</p><nav><a href="figures/{stem}.pdf">矢量PDF</a><a href="PNG_600dpi/{stem}.png">600dpi原图</a><a href="SVG_矢量/{stem}.svg">SVG</a></nav></article>')
page='''<!doctype html><html lang="zh"><meta charset="utf-8"><title>七形状域消融核心四图</title><style>body{max-width:1320px;margin:40px auto;padding:0 24px;font:16px/1.65 system-ui;background:#f4f6f8;color:#243447}article,section{background:white;margin:24px 0;padding:24px;border-radius:10px}h1{font-size:30px}h2{font-size:21px}img{width:100%;height:auto}nav{display:flex;gap:24px}a{color:#386b99}.note{border-left:4px solid #708cc3;padding:12px 20px;background:#edf3f9}</style><h1>七形状域 · 消融核心四图</h1><p>GD · 同权重AdaJEPA、朴素继承、慢参数EMA、完整Ours</p><nav><a href="七形状域_消融核心四图.pdf">四页PDF合集</a><a href="data/heldout_episodes.csv">独立测试逐回合数据</a><a href="data/learning_round_metrics.csv">学习阶段逐轮数据</a></nav><section><p class="note">第1–3图：第5轮权重独立测试，各组1050回合。第4图：学习阶段结果，每轮350回合，不能解释为每轮固定测试集表现。现有实验仅评估了第5轮权重；未补造第1–4轮测试结果。</p><p>配色与先前图表一致；Ours纯实线且无点。误差棒/阴影只表示三个测试种子之间的样本标准差，不是独立学习链的波动。朴素继承只选第1链。Ours慢学习率1e-4；EMA系数1e-4。</p><p>样本核验：三种消融原始初始/目标状态已核对；Ours复用原始报告CSV，回合键与协议对齐，但CSV不含状态张量，因此不能仅据CSV独立核验Ours物理状态配对。测试划分为原实验的片段级heldout协议。</p></section>'''+''.join(cards)+'</html>'
(ROOT/'图表索引.html').write_text(page,encoding='utf-8')
(ROOT/'README.txt').write_text('四张核心图，Python/Matplotlib生成；每张PDF、SVG、600dpi PNG，附4页PDF和数据。\n前三张为第5轮权重独立测试；第四张只展示真实学习阶段日志，不能当作逐轮固定测试。\n学习阶段350回合/轮，单链，无训练重复误差条；测试1050回合/方法，误差棒为3个测试种子SD。\n详见data/learning_round_audit.json及data/heldout_episode_data.json的来源信息。\n',encoding='utf-8')
print(json.dumps({'directory':str(ROOT),'figures':len(MAN),'combined':str(COMBINED)},ensure_ascii=False),flush=True)
