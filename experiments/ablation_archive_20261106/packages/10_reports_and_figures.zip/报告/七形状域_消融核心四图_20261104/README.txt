四张核心图，Python/Matplotlib生成；每张PDF、SVG、600dpi PNG，附4页PDF和数据。
前三张为第5轮权重独立测试；第四张只展示真实学习阶段日志，不能当作逐轮固定测试。
学习阶段350回合/轮，单链，无训练重复误差条；测试1050回合/方法，误差棒为3个测试种子SD。
详见data/learning_round_audit.json及data/heldout_episode_data.json的来源信息。
