"""One additional slow learning rate (3e-4); exact published S7t5/H7t3 inputs, local verified backup."""
from pathlib import Path
import concurrent.futures as cf
import fcntl,json,os,queue,shutil,signal,sys,threading,time,traceback
import numpy as np
import torch
from omegaconf import OmegaConf
import engine as E
import naive_reference as B
from scripts.cont_run_stream import NAMED_ARMS

ROOT=E.ROOT;CODE=E.CODE;P=E.P
OLD=Path(P['source_experiment'])
LEARN=[m for m in P['methods'] if P['variants'][m]['learn']]

def job(method,index):
    if method!='adajepa_same' and index<35:
        rnd=index//7+1;tag=P['domain_order'][index%7]
        return dict(phase='learn',optimizer='GD',method=method,chain=1,index=index,round=rnd,tag=tag,
                    seed=P['seed_schedule'][0][rnd-1],input_key=f'learn_c1_r{rnd}_{tag}')
    ti=index-(35 if method!='adajepa_same' else 0)
    seed=P['test_seeds'][ti//7];tag=P['domain_order'][ti%7]
    return dict(phase='test',optimizer='GD',method=method,chain=1,index=ti,round=None if method=='adajepa_same' else 5,tag=tag,seed=seed,input_key=f'test_s{seed}_{tag}')

def output(j):
    if j['phase']=='learn':return ROOT/'results/learn/GD'/j['method']/f"chunk_{j['index']:02d}_r{j['round']}_{j['tag']}"
    return ROOT/'results/test/GD'/j['method']/f"seed_{j['seed']}"/j['tag']

def command(j,out,n,state=None,variant=None):
    if j['method']=='adajepa_same':return B.command(j,out,n,None,'stock' if variant=='stock_baseline' else 'reset')
    cmd=[sys.executable,str(CODE/'plan.py'),'--config-name','cont_plan_gd_pushobj',
         'ckpt_base_path='+P['checkpoint'],'model_epoch=latest',
         'eval_data_path='+P['streams'][j['input_key']]['path'],f'n_evals={n}',f"seed={j['seed']}",
         'segments_order=file','goal_source=segments','+wandb_logging=false','hydra.run.dir='+str(out),
         'planner.max_iter=30','n_plot_samples=0','decode_for_viz=false','planner.sub_planner.cuda_graph=true']
    cmd += [x for x in NAMED_ARMS['cls6a_free'] if not x.startswith('planner._target_=')]
    if variant=='stock_cls':cmd+=['planner._target_=planning.continual_v7.CLSv7MPCPlanner']
    else:cmd+=['planner._target_=planning.core_ablations.AuditedCLSAblation','+planner.ablation='+'full']
    return cmd+['planner.continual.tag='+j['tag'],'planner.continual.state_in='+(str(state) if state else 'null'),
        'planner.continual.state_out=continual_state.pt','planner.continual.read_only='+str(j['phase']=='test').lower(),
        'planner.continual.save_frames=false','planner.continual.save_deltas=false',
        'planner.continual.slow_lr='+str(P['variants'][j['method']]['slow_lr'])]

def audit(j,out,n,initial,state,state_before,variant):
    if j['method']=='adajepa_same':return B.audit(j,out,n,initial,None,None,'stock' if variant=='stock_baseline' else 'reset')
    row=B.audit(j,out,n,initial,state,state_before,'stock')
    if n==50:
        reference=(OLD/'results/learn/GD/slow_lr_low'/f"chunk_{j['index']:02d}_r{j['round']}_{j['tag']}") if j['phase']=='learn' else (OLD/'results/test/GD/adajepa_same'/f"seed_{j['seed']}"/j['tag'])
        with np.load(out/'final_eval_results.npz') as actual,np.load(reference/'final_eval_results.npz') as ref:
            for key in ['state_0','state_g']:
                assert np.array_equal(actual[key],ref[key]), ('Reference targets mismatch',key,j)
        row['targets_match_completed_core_ablation']=True
    cfg=OmegaConf.to_container(OmegaConf.load(out/'.hydra/config.yaml'),resolve=True)
    c=cfg['planner']['continual']
    assert c['familiar_thr']==.0146 and c['familiar_read'] and c['mature_k']==3
    assert c['mature_ratio']==.9 and c['reject_ratio']==1.2 and c['write']=='delta'
    assert c['slow_lr']==P['variants'][j['method']]['slow_lr'] and c['slow_steps']==15 and c['slow_batch']==8
    assert c['pending_m']==3 and c['tau_new']==.05 and c['min_n']==3
    assert c['tau']==.1 and c['merge_k']==2 and c['merge_eps']==.5
    assert c['absorb_every']==25 and c['absorb_frag']==6 and not c['absorb_pending']
    assert not c['save_frames'] and not c['save_deltas'] and c['read_only']==(j['phase']=='test')
    rec=E.lines(out/'continual_episodes.jsonl')
    assert [r['episode'] for r in rec]==list(range(initial,initial+n))
    assert [r['sample_idx'] for r in rec]==list(range(n))
    with np.load(out/'final_eval_results.npz') as z:assert [r['success'] for r in rec]==z['successes'].tolist()
    if variant!='stock_cls':
        a=json.loads((out/'ablation_audit.json').read_text())
        assert a['ablation']=='full' and a['slow_lr']==c['slow_lr']
        assert all(lr==c['slow_lr'] for lr in a['slow_optimizer_lrs'])
        assert a['episodes']==n and a['initial_episode']==initial and a['final_episode']==initial+n
        assert a['familiarity_protection_kept'] and a['mature_k_for_write_and_absorption']==3
        assert a['read_maturity_gate_removed']==(j['method']=='no_maturity_read' and variant!='full')
        if j['method']=='shared_slow' and variant!='full':assert set(a['domain_keys'])<={'shared'} and a['active_learners']<=1
    if j['phase']=='learn':
        st=torch.load(out/'continual_state.pt',map_location='cpu',weights_only=False)
        assert st['episode']==initial+n and st['cls_cfg']['slow_lr']==c['slow_lr']
        for d in st['domains'].values():
            if d['learner'] is not None:
                assert all(torch.isfinite(t).all().item() for t in d['learner'].values() if isinstance(t,torch.Tensor)), 'Non-finite slow learner weights'
        assert all(not np.isinf(r.get('slow_loss',float('nan'))) for r in rec), 'Infinite slow loss'
        row.update(state_sha256=E.sha(out/'continual_state.pt'),state_in_sha256=state_before,initial_episode=initial,final_episode=initial+n,
                   domain_count=len(st['domains']),active_learners=sum(d['learner'] is not None for d in st['domains'].values()))
        del st
    else:
        assert not (out/'continual_state.pt').exists()
        assert all(r['write'] is None and r['write_rule']=='read_only' for r in rec)
        if variant!='stock_cls':assert a['persistent_state_unchanged'] and not a['state_written']
        row.update(readonly_verified=True,state_in_sha256=state_before,initial_episode=initial)
    return row

def preflight():
    assert P['total_episodes']==2800 and P['total_jobs']==56 and len(LEARN)==1
    assert E.sha(Path(P['checkpoint'])/'checkpoints/model_latest.pth')==P['checkpoint_sha256']
    for v in P['streams'].values():assert E.sha(v['path'])==v['sha256']
    for tag in P['domain_order']:
        tr={i for v in P['streams'].values() if v['phase']=='learn' and v['tag']==tag for i in v['indices']}
        te={i for v in P['streams'].values() if v['phase']=='test' and v['tag']==tag for i in v['indices']}
        assert not tr&te
    for name,h in json.loads((ROOT/'base_source_manifest.json').read_text()).items():assert E.sha(CODE/name)==h,name
    assert shutil.disk_usage(ROOT).free>10*2**30
    E.save(ROOT/'preflight.json',{'passed':True,'time':E.now(),'checkpoint_sha256':P['checkpoint_sha256'],
        'published_input_files_verified':len(P['streams']),'train_test_segment_disjoint':True,'trajectory_disjoint_claimed':False,
        'new_episodes':2800,'familiarity_ablations_excluded':True})

def smoke():
    preflight();E.PHASE='validating'
    def one(m,gpu):
        j=job(m,0);o=ROOT/'smoke'/m
        E.execute(j,gpu,n=8,out=o)
        s=o/'continual_state.pt'
        a=json.loads((o/'ablation_audit.json').read_text())
        assert a['active_learners']>0 and a['slow_optimizer_lrs'], 'Smoke must exercise slow learning'
        E.execute(job(m,1),gpu,n=2,out=ROOT/'smoke'/(m+'_resume'),state=s,initial=8)
        E.execute({**j,'phase':'test'},gpu,n=2,out=ROOT/'smoke'/(m+'_readonly'),state=s,initial=8)
        return {m:{'slow_lr':a['slow_lr'],'actual_optimizer_lrs':a['slow_optimizer_lrs'],
                    'active_learners':a['active_learners'],'resume_readonly_passed':True,'finite_weights':True}}
    checks={}
    with cf.ThreadPoolExecutor(len(LEARN)) as pool:
        for f in [pool.submit(one,m,g) for g,m in enumerate(LEARN)]:checks.update(f.result())
    E.save(ROOT/'smoke_validation.json',{'passed':True,'time':E.now(),'checks':checks,
        'only_learning_samples_used':True,'excluded_from_formal_results':True,
        'formal_chains_restart_from_pretrained':True,
        'prior_wrapper_equivalence_validation':str(OLD/'smoke_validation.json')})
    E.status('validation_passed')

def run():
    preflight();assert json.loads((ROOT/'smoke_validation.json').read_text())['passed']
    def restored(j):
        o=output(j)
        if not (o/'audit.json').exists() or not (o/'backup_ack.json').exists():return False
        a=json.loads((o/'audit.json').read_text());assert E.sha(o/'final_eval_results.npz')==a['result_sha256']
        with E.LOCK:E.FINISHED[str(o)]=a
        return True
    def execute_one(j,gpu,state,initial,prev=None):
        try:
            out=output(j)
            a=E.execute(j,gpu,state=state,initial=initial);E.export(j,out)
            if prev:E.retire_previous(prev,out)
            with E.LOCK:E.FINISHED[str(out)]=a
        except BaseException:
            with E.LOCK:E.ERRORS.append({'job':j,'traceback':traceback.format_exc()})
            E.STOP.set();raise
    E.PHASE='learning'
    def learn(m,gpu):
        for i in range(35):
            E.check_stop();j=job(m,i)
            if restored(j):continue
            prev=output(job(m,i-1)) if i else None
            execute_one(j,gpu,prev/'continual_state.pt' if prev else None,i*50,prev)
    with cf.ThreadPoolExecutor(len(LEARN)) as pool:
        for f in [pool.submit(learn,m,g) for g,m in enumerate(LEARN)]:f.result()
    E.check_stop();E.PHASE='heldout_test';q=queue.Queue()
    for i in range(35,56):
        for m in LEARN:
            j=job(m,i)
            if not restored(j):q.put(j)
    def test(gpu):
        while not E.STOP.is_set():
            try:j=q.get_nowait()
            except queue.Empty:return
            try:execute_one(j,gpu,output(job(j['method'],34))/'continual_state.pt',1750)
            finally:q.task_done()
    with cf.ThreadPoolExecutor(4) as pool:
        for f in [pool.submit(test,g) for g in range(4)]:f.result()
    E.check_stop();assert len(E.FINISHED)==56
    summarize()
    E.save(ROOT/'final_results.json',{'status':'completed','time':E.now(),'results':list(E.FINISHED.values())})
    E.PHASE='completed';E.status()

def summarize():
    tests={};learn={}
    def metric(rows):
        n=sum(r['n'] for r in rows);s=sum(r['successes'] for r in rows)
        return dict(n=n,successes=s,success_rate=s/n,mpc_steps_all=sum(r['mpc_steps_all_mean']*r['n'] for r in rows)/n,
                    mpc_steps_success=sum((r['mpc_steps_success_mean'] or 0)*r['successes'] for r in rows)/s if s else None)
    for m in P['methods']:
        tests[m]={}
        for tag in ['all']+P['domain_order']:
            rows=[r for r in E.FINISHED.values() if r['method']==m and r['phase']=='test' and (tag=='all' or r['tag']==tag)]
            by={str(s):metric([r for r in rows if r['seed']==s]) for s in P['test_seeds']}
            tests[m][tag]={'pooled':metric(rows),'by_test_seed':by,'success_rate_test_seed_std':float(np.std([r['success_rate'] for r in by.values()],ddof=1))}
        if m in LEARN:learn[m]={str(i):metric([r for r in E.FINISHED.values() if r['method']==m and r['phase']=='learn' and r['round']==i]) for i in range(1,6)}
    E.save(ROOT/'test_summary.json',{'source':'H7t3 heldout, one learned chain per arm; test seeds are not training replicates','results':tests})
    E.save(ROOT/'learning_summary.json',{'source':'S7t5 online learning only','results':learn})

E.command=command;E.audit=audit;E.output=output
if __name__=='__main__':
    lock=(ROOT/'supervisor.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    signal.signal(signal.SIGTERM,lambda *_:E.STOP.set());signal.signal(signal.SIGINT,lambda *_:E.STOP.set())
    threading.Thread(target=E.heartbeat,daemon=True).start()
    try:{'preflight':preflight,'smoke':smoke,'run':run}[sys.argv[1]]()
    except BaseException:
        E.ERRORS.append({'time':E.now(),'traceback':traceback.format_exc()});E.STOP.set()
        E.status('stopped' if (ROOT/'STOP').exists() else 'failed');raise
    finally:E.STOP.set()
