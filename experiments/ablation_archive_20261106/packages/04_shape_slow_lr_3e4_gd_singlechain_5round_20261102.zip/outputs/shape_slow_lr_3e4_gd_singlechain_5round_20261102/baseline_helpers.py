"""Four-GPU supervised execution with paired-target, noise and reset audits."""
from pathlib import Path
import concurrent.futures as cf
import datetime, fcntl, gzip, hashlib, json, os, queue, shutil, signal, subprocess, sys, threading, time, traceback
import numpy as np
from omegaconf import OmegaConf

ROOT=Path(__file__).resolve().parent
CODE=ROOT/'code'
PROTO=json.loads((ROOT/'protocol.json').read_text())
sys.path.insert(0,str(CODE))
from planning.paired_noise import mask_record
LOCK=threading.RLock()
STOP=threading.Event()
ACTIVE={}
FINISHED=[]
FIRST_FAILURE=None

def now():return datetime.datetime.now().astimezone().isoformat()
def save(p,d):
    p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2));tmp.replace(p)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def lines(p):return [json.loads(x) for x in Path(p).read_text().splitlines() if x.strip()]
def tag_block(tag):return next(b for b in PROTO['blocks'] if b['tag']==tag)
def checkpoint(job):return PROTO['original_checkpoint'] if job.get('scope')=='original_default' else PROTO['checkpoint']

def compact_targets(out):
    """Losslessly retain optional visualization targets without repeated raw images."""
    source=out/'plan_targets.pkl'
    if not source.exists():return
    target=out/'plan_targets.pkl.gz';tmp=out/'plan_targets.pkl.gz.tmp'
    original_hash=sha(source);original_bytes=source.stat().st_size
    with source.open('rb') as src,gzip.open(tmp,'wb',compresslevel=3) as dst:
        shutil.copyfileobj(src,dst)
    digest=hashlib.sha256()
    with gzip.open(tmp,'rb') as src:
        for block in iter(lambda:src.read(1024*1024),b''):digest.update(block)
    assert digest.hexdigest()==original_hash,'Compressed target verification failed'
    tmp.replace(target)
    save(out/'target_archive.json',dict(original='plan_targets.pkl',archive=target.name,
         sha256=original_hash,original_bytes=original_bytes,archive_bytes=target.stat().st_size,
         verified_lossless=True,created=now()))
    source.unlink()

def command(out,job,n,variant='logged'):
    opt,method,seed,tag=[job[k] for k in ('optimizer','method','seed','tag')]
    block=tag_block(tag)
    if variant=='resume_v6a':
        previous=Path(PROTO['original_v6a_runs'][opt][str(seed)])/'results/cls6a_free/chunk_29_r5_red_goal'
        old=json.loads((previous/'command.json').read_text())
        start=next(i for i,x in enumerate(old) if x.endswith('/plan.py'))-1
        old=old[start:]
        replace={
            'eval_data_path':str(ROOT/'stream/chunk_default.pkl'),'n_evals':str(n),'hydra.run.dir':str(out),
            'planner.continual.tag':'default','planner.continual.state_in':str(previous/'continual_state.pt'),
            'planner.continual.save_frames':'false','planner.continual.save_deltas':'false'}
        old=[x for x in old if not x.lstrip('+').startswith(('env_kwargs_override.','ood_corruption=','ood_level='))]
        for i,x in enumerate(old):
            key=x.split('=',1)[0].lstrip('+')
            if key in replace:old[i]=key+'='+replace[key]
        old+=['n_plot_samples=0','ood_corruption=null','ood_level=null','env_kwargs_override=null']
        return old
    name=('cont_plan_' if variant=='previous' else 'adajepa_plan_')+opt.lower()+'_pushobj'
    cmd=[sys.executable,str(CODE/'plan.py'),'--config-name',name,
         f"ckpt_base_path={checkpoint(job)}",'model_epoch=latest',f'eval_data_path={ROOT/"stream"/(block["chunk"]+".pkl")}',
         f'n_evals={n}',f'seed={seed}',('' if variant=='previous' else '+')+'segments_order=file',
         'goal_source=segments','+wandb_logging=false',f'hydra.run.dir={out}','planner.max_iter=30',
         'decode_for_viz=false','n_plot_samples=0','+ood_noise_seed=20261019','+ood_noise_pair_across_seeds=true']
    if variant=='previous':
        cmd+=['planner._target_=planning.paired_logging.PairedAdaJEPAPlanner','planner.continual.w=0',
              'planner.continual.state_in=null','planner.continual.save_frames=false','planner.continual.save_deltas=false',f'planner.continual.tag={tag}']
    elif variant=='stock_frozen':
        cmd+=['planner._target_=planning.mpc.MPCPlanner','~planner.adapt']
    else:
        cmd+=['planner._target_=planning.official_baseline_logging.LoggedAdaJEPAPlanner']
        if method=='frozen':cmd+=['planner.adapt.steps=0','planner.adapt.lr=0','planner.adapt.encoder_lr=0']
    if opt=='GD':
        cmd+=['planner.sub_planner.target=planning.cuda_graph_gd.CUDAGraphGDPlanner',
              'objective._target_=planning.cuda_graph_objectives.create_objective_fn']
    return cmd+block['overrides']

def audit(out,job,n,variant='logged'):
    cfg=OmegaConf.to_container(OmegaConf.load(out/'.hydra/config.yaml'),resolve=True)
    p=cfg['planner']
    assert cfg['seed']==job['seed'] and cfg['n_evals']==n and cfg['segments_order']=='file'
    assert cfg['ckpt_base_path']==checkpoint(job) and p['max_iter']==30
    assert cfg['ood_noise_seed']==20261019 and cfg['ood_noise_pair_across_seeds'] is True
    assert cfg['goal_H']==25 and p['n_taken_actions']==5 and p['sub_planner']['horizon']==25
    if variant=='stock_frozen':assert 'adapt' not in p
    else:
        assert p['adapt']['steps']==(0 if job['method']=='frozen' else 1)
        if job['method'] in ['adajepa','v6a']:assert p['adapt']['lr']==5e-4 and p['adapt']['encoder_lr']==1e-5
    if job['optimizer']=='CEM':
        assert p['sub_planner']['num_samples']==200 and p['sub_planner']['topk']==30 and p['sub_planner']['opt_steps']==10
    else:assert p['sub_planner']['opt_steps']==100 and p['sub_planner']['lr']==.1
    with np.load(out/'final_eval_results.npz') as z, np.load(ROOT/'target_reference_n50.npz') as ref:
        success=z['successes'].astype(bool)
        assert len(success)==n and np.isfinite(z['actions']).all()
        assert all(np.array_equal(z[k],ref[k][:n]) for k in ['state_0','state_g'])
        action_len=z['action_len'].copy()
    if variant=='logged':
        records=lines(out/'episodes.jsonl')
        assert [r['sample_idx'] for r in records]==list(range(n))
        assert [r['success'] for r in records]==success.tolist()
        assert all(r['started_from_pretrained'] for r in records)
        assert all(r['model_before_sha256']==records[0]['model_before_sha256'] for r in records)
        if job['method']=='frozen':assert all(not r['model_changed'] for r in records)
        else:assert all(r['model_changed'] for r in records)
        assert all((r['first_success_step']==action_len[i]) if r['success'] else np.isinf(action_len[i]) for i,r in enumerate(records))
        assert all(1<=r['steps']<=30 for r in records)
        reset=json.loads((out/'model_reset_audit.json').read_text())
        assert reset['final_reset_exact'] and reset['episodes']==n
        trace=lines(out/'per_iter_logs.json')
        assert len(trace)==sum(r['steps'] for r in records)
        for i,r in enumerate(records):
            ep=[x for x in trace if x['sample_idx']==i]
            assert [x['step'] for x in ep]==list(range(1,r['steps']+1))
            hits=[x['step'] for x in ep if x['success']]
            assert hits==([r['first_success_step']] if r['success'] else [])
        if job['method']=='frozen':assert not (out/'adajepa_losses.csv').exists()
    elif variant in ['previous','resume_v6a','v6a_logged']:
        records=lines(out/'continual_episodes.jsonl')
        assert [r['success'] for r in records]==success.tolist()
        if variant=='previous':assert all(r['slow_pred_after']==0 and r['slow_enc_after']==0 for r in records)
        elif variant=='resume_v6a':
            prior=Path(PROTO['original_v6a_runs'][job['optimizer']][str(job['seed'])])/'results/cls6a_free/chunk_29_r5_red_goal/continual_state.pt'
            assert p['continual']['state_in']==str(prior) and p['continual']['familiar_thr']==.0146
            assert [r['episode'] for r in records]==list(range(1500,1500+n))
            assert [r['sample_idx'] for r in records]==list(range(n))
            assert all(r['tag']=='default' for r in records)
            assert (out/'continual_state.pt').stat().st_size>0
    else:records=[]
    log=lines(out/'logs.json');final=[r for r in log if 'final_eval/success_rate' in r]
    assert len(final)==1 and abs(final[0]['final_eval/success_rate']-success.mean())<1e-6
    noise_count=0
    if job['tag']=='snp1':
        masks={}
        for row in lines(out/'paired_noise.jsonl'):
            assert row['sample_seed'] in range(n) and row['noise_seed']==20261019
            _,expected=mask_record(row['noise_seed'],row['sample_seed'],row['role'],row['frame_index'],row['height'],row['width'],row['density'])
            assert row==expected
            key=(row['sample_seed'],row['role'],row['frame_index'])
            assert key not in masks;masks[key]=row['mask_sha256']
        assert all((i,'reference',0) in masks and (i,'reference',25) in masks and (i,'online',0) in masks for i in range(n))
        noise_count=len(masks)
    counts=[int(np.sum(success & (action_len<=k))) for k in range(1,31)]
    meta=json.loads((out/'run_metadata.json').read_text());assert meta['rc']==0
    result=dict(**job,n=n,successes=int(success.sum()),success_rate=float(success.mean()),
                success_counts_by_mpc_step=counts,noise_records=noise_count,paired_targets=True,
                seconds=meta['seconds'],gpu=meta['gpu'],completed=meta['completed'],path=str(out),variant=variant)
    if variant=='resume_v6a':
        result.update(initial_episode=1500,final_episode=1500+n,final_domains=records[-1].get('domains',{}),
            read_n=sum(r.get('read') is not None for r in records),write_n=sum(r.get('write') is not None for r in records),
            pending_n=records[-1].get('pending_n'),position='supplement after round 5; not interleaved into the previous five rounds')
    return result

def execute(job,n,gpu,out,variant='logged'):
    if (out/'audit.json').exists():
        result=audit(out,job,n,variant);compact_targets(out);return result
    free=shutil.disk_usage(ROOT).free
    assert free>1.2*2**30,f'Disk space low before starting {job}: {free/2**30:.3f} GiB'
    if out.exists():
        dest=ROOT/'interrupted_attempts'/(out.name+'_'+str(time.time_ns()));dest.parent.mkdir(exist_ok=True);out.rename(dest)
    out.mkdir(parents=True)
    cmd=['taskset','-c',','.join(map(str,PROTO['cpu_affinity'][str(gpu)]))]+command(out,job,n,variant)
    env={**os.environ,**json.loads((ROOT/'runtime_env.json').read_text()),'CUDA_VISIBLE_DEVICES':str(gpu)}
    if variant=='resume_v6a':
        original_code=Path(PROTO['original_v6a_runs'][job['optimizer']][str(job['seed'])])/'code'
        env['PYTHONPATH']=str(original_code)+':'+':'.join(env['PYTHONPATH'].split(':')[1:])
    save(out/'command.json',cmd)
    start=time.time()
    with (out/'console.log').open('w') as f:
        with (ROOT/'resource_start.lock').open('w') as gate:
            fcntl.flock(gate,fcntl.LOCK_EX)
            available=next(int(s.split()[1])*1024 for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:'))
            assert available>12*2**30,'Insufficient available RAM'
            p=subprocess.Popen(cmd,cwd=CODE,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
            with LOCK:ACTIVE[str(gpu)]={**job,'pid':p.pid,'path':str(out),'n':n,'started':now()}
            time.sleep(5)
        print('START',job,'GPU',gpu,'PID',p.pid,flush=True)
        try:
            while p.poll() is None:
                free=shutil.disk_usage(ROOT).free
                if STOP.is_set() or free<0.8*2**30:
                    reason=(f'Sibling failed: {FIRST_FAILURE}' if FIRST_FAILURE else 'Stop requested') if STOP.is_set() else f'Disk space low during execution: {free/2**30:.3f} GiB'
                    os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=30)
                    raise RuntimeError(reason)
                time.sleep(2)
        finally:
            with LOCK:ACTIVE.pop(str(gpu),None)
    save(out/'run_metadata.json',dict(rc=p.returncode,seconds=time.time()-start,gpu=gpu,completed=now()))
    assert p.returncode==0,f'Failed {out}; inspect console.log'
    row=audit(out,job,n,variant);save(out/'audit.json',row)
    compact_targets(out)
    print('AUDITED',job,row['successes'],'/',n,flush=True)
    return row

def preflight():
    assert sha(Path(PROTO['checkpoint'])/'checkpoints/model_latest.pth')==PROTO['checkpoint_sha256']
    assert sha(Path(PROTO['original_checkpoint'])/'checkpoints/model_latest.pth')==PROTO['original_checkpoint_sha256']
    for opt,seeds in PROTO['original_v6a_runs'].items():
        for seed,rel in seeds.items():
            state=Path(rel)/'results/cls6a_free/chunk_29_r5_red_goal/continual_state.pt'
            assert state.exists() and sha(state)==PROTO['original_state_sha256'][opt][seed]
    assert PROTO['seeds']==[100,200,300] and len(PROTO['domain_order']) in [6,7]
    for b in PROTO['blocks']:assert sha(ROOT/'stream'/(b['chunk']+'.pkl'))==PROTO['target_sha256']
    manifest=json.loads((ROOT/'base_source_manifest.json').read_text())
    assert all(sha(CODE/k)==v for k,v in manifest.items()),'Original source snapshot changed'
    files={str(p.relative_to(CODE)):sha(p) for p in CODE.rglob('*') if p.is_file() and '__pycache__' not in str(p)}
    save(ROOT/'source_manifest.json',files)
    save(ROOT/'preflight.json',dict(passed=True,time=now(),checkpoint_sha256=PROTO['checkpoint_sha256'],target_sha256=PROTO['target_sha256'],source_files=len(files),disk_free_gib=shutil.disk_usage(ROOT).free/2**30))

def compare(a,b):
    with np.load(a/'final_eval_results.npz') as x,np.load(b/'final_eval_results.npz') as y:
        checks={k:bool(np.array_equal(x[k],y[k])) for k in ['actions','action_len','successes','state_0','state_g']}
    assert all(checks.values()),checks
    return checks

def smoke():
    cases=[(o,m) for o in ['GD','CEM'] for m in ['adajepa','frozen']]
    with cf.ThreadPoolExecutor(4) as pool:
        tasks=[pool.submit(execute,dict(optimizer=o,method=m,seed=100,tag='snp1'),2,i,ROOT/'smoke'/f'{o}_{m}') for i,(o,m) in enumerate(cases)]
        rows=[f.result() for f in tasks]
    with cf.ThreadPoolExecutor(4) as pool:
        tasks=[pool.submit(execute,dict(optimizer=o,method='adajepa',seed=100,tag='snp1'),2,i,ROOT/'smoke'/f'{o}_previous','previous') for i,o in enumerate(['GD','CEM'])]
        # A one-sample run avoids batch-size-dependent CEM random-number allocation.
        tasks += [pool.submit(execute,dict(optimizer=o,method='frozen',seed=100,tag='snp1'),1,i+2,ROOT/'smoke'/f'{o}_stock_frozen','stock_frozen') for i,o in enumerate(['GD','CEM'])]
        rows += [f.result() for f in tasks]
    checks={}
    for o in ['GD','CEM']:
        checks[o+'_adajepa_matches_previous']=compare(ROOT/'smoke'/f'{o}_adajepa',ROOT/'smoke'/f'{o}_previous')
        with np.load(ROOT/'smoke'/f'{o}_frozen/final_eval_results.npz') as a,np.load(ROOT/'smoke'/f'{o}_stock_frozen/final_eval_results.npz') as b:
            t=b['actions'].shape[1]
            c={k:bool(np.array_equal(a[k][:1],b[k])) for k in ['action_len','successes','state_0','state_g']}
            c['actions_to_stop']=bool(np.array_equal(a['actions'][:1,:t],b['actions']))
            assert all(c.values()),(o,c)
            checks[o+'_frozen_matches_stock_mpc']=c
    save(ROOT/'smoke_validation.json',dict(passed=True,time=now(),checks=checks,runs=rows))

def status(state,extra=None):
    with LOCK:
        active=[]
        for item in ACTIVE.values():
            row=dict(item);f=Path(item['path'])/('live_episodes.jsonl' if item['method']=='v6a' else 'episodes.jsonl')
            try:rec=lines(f) if f.exists() else []
            except json.JSONDecodeError:rec=[]  # writer may currently be appending its last line
            row['completed_episodes']=len(rec);row['successes']=sum(r['success'] for r in rec)
            active.append(row)
        save(ROOT/'status.json',dict(status=state,updated=now(),total_episodes=PROTO['total_episodes'],
             completed_jobs=len(FINISHED),completed_episodes=sum(r['n'] for r in FINISHED)+sum(r['completed_episodes'] for r in active),
             active=active,finished=FINISHED,**(extra or {})))

def run():
    assert json.loads((ROOT/'smoke_validation.json').read_text())['passed']
    jobs=queue.Queue();official=[];supplements=[]
    # Interleave both methods and planners so all four conditions start together.
    for seed in PROTO['seeds']:
        for tag in PROTO['domain_order']:
            for opt in ['GD','CEM']:
                for method in ['adajepa','frozen']:
                    official.append(dict(optimizer=opt,method=method,seed=seed,tag=tag,scope='official'))
    for seed in PROTO['seeds']:
        for opt in ['GD','CEM']:
            for method in ['v6a','adajepa']:
                supplements.append(dict(optimizer=opt,method=method,seed=seed,tag='default',scope='original_default'))
    for i,job in enumerate(official):
        if i<len(supplements):jobs.put(supplements[i])
        jobs.put(job)
    def worker(gpu):
        global FIRST_FAILURE
        while not STOP.is_set():
            try:job=jobs.get_nowait()
            except queue.Empty:return
            out=ROOT/('original_default' if job['scope']=='original_default' else 'results')/job['optimizer']/job['method']/f"seed_{job['seed']}"/job['tag']
            try:
                row=execute(job,50,gpu,out,'resume_v6a' if job['method']=='v6a' else 'logged')
                with LOCK:FINISHED.append(row)
            except BaseException as error:
                with LOCK:
                    failure=dict(time=now(),job=job,gpu=gpu,error=str(error),traceback=traceback.format_exc(),
                                 disk_free_gib=shutil.disk_usage(ROOT).free/2**30)
                    if FIRST_FAILURE is None:
                        FIRST_FAILURE=failure
                        save(ROOT/'first_failure.json',failure)
                        print('FIRST_FAILURE',json.dumps(failure,ensure_ascii=False),flush=True)
                    STOP.set()
                raise
            finally:jobs.task_done()
    with cf.ThreadPoolExecutor(4) as pool:
        workers=[pool.submit(worker,g) for g in [0,1,2,3]]
        while not all(f.done() for f in workers):
            status('running');time.sleep(10)
        if FIRST_FAILURE:raise RuntimeError(json.dumps(FIRST_FAILURE,ensure_ascii=False))
        for f in workers:f.result()
    assert sum(r['n'] for r in FINISHED)==PROTO['total_episodes']
    save(ROOT/'final_results.json',dict(status='completed',completed=now(),protocol=PROTO,results=FINISHED))
    status('completed')

def stop(*_):STOP.set()

if __name__=='__main__':
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    with (ROOT/'supervisor.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            mode=sys.argv[1] if len(sys.argv)>1 else 'all'
            preflight()
            if mode in ['all','smoke']:
                status('validating');smoke()
            if mode in ['all','run']:run()
            elif mode=='smoke':status('validation_passed')
        except BaseException as e:
            STOP.set();status('failed',dict(error=str(e),traceback=traceback.format_exc()));traceback.print_exc();raise
