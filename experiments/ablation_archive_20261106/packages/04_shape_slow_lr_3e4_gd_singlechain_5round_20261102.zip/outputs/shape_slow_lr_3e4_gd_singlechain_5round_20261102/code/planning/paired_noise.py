"""Reproducible salt/pepper masks indexed independently of method and visit.

The distribution and overwrite order match image_corruption.apply_salt_pepper.
Reference images and online measurements use separate, documented streams.
Online frame indices are physical steps in the cumulative environment rollout.
"""
import hashlib
import json
from functools import lru_cache
from pathlib import Path

import numpy as np

SCHEME = 'paired-snp-v1'
_recorded = set()


def target_indices(sample_seeds, evaluation_seed_stride):
    """Invert plan.py's eval_seed = planning_seed * target_index + 1.

    This removes the experiment seed from noise identity, including when the
    evaluator is sliced to a single target. It never changes environment seeds.
    """
    stride = int(evaluation_seed_stride)
    seeds = np.asarray(sample_seeds).reshape(-1)
    if stride <= 0 or np.any(seeds != seeds.astype(np.int64)):
        raise ValueError('Expected positive seed stride and integer sample seeds')
    offsets = seeds.astype(np.int64) - 1
    if np.any(offsets < 0) or np.any(offsets % stride):
        raise ValueError('Evaluation sample seeds do not match their planning seed')
    return offsets // stride


@lru_cache(maxsize=512)
def mask_record(noise_seed, sample_seed, role, frame_index, height, width, density):
    identity = f'{SCHEME}|{int(noise_seed)}|{int(sample_seed)}|{role}|{int(frame_index)}'
    digest = hashlib.sha256(identity.encode('ascii')).digest()
    rng = np.random.RandomState(np.frombuffer(digest[:16], dtype='<u4').copy())
    n = int(float(density) * height * width)
    mask = np.zeros((height, width), dtype=np.uint8)
    ys = rng.randint(0, height, n)
    xs = rng.randint(0, width, n)
    mask[ys, xs] = 1
    ys = rng.randint(0, height, n)
    xs = rng.randint(0, width, n)
    mask[ys, xs] = 2
    mask.setflags(write=False)
    record = dict(scheme=SCHEME, noise_seed=int(noise_seed), sample_seed=int(sample_seed),
                  role=role, frame_index=int(frame_index), height=height, width=width,
                  density=float(density), mask_sha256=hashlib.sha256(mask.tobytes()).hexdigest())
    return mask, record


def corrupt_paired(obs, corruption, level, sample_seeds, noise_seed, role,
                   frame_offset=0, audit_path='paired_noise.jsonl', evaluation_seed_stride=None):
    if corruption not in ('snp1', 'snp5'):
        raise ValueError('Paired corruption is only used for salt-and-pepper noise')
    frames = np.asarray(obs['visual'])
    if frames.ndim != 5 or frames.dtype != np.uint8:
        raise ValueError(f'Expected uint8 B,T,H,W,C images, got {frames.shape} {frames.dtype}')
    seeds = np.asarray(sample_seeds).reshape(-1)
    if evaluation_seed_stride is not None:
        # The legacy audit field sample_seed now records the stable target index.
        seeds = target_indices(seeds, evaluation_seed_stride)
    if len(seeds) != frames.shape[0]:
        raise ValueError(f'Seed/image batch mismatch: {len(seeds)} versus {frames.shape[0]}')
    density = float(level if level is not None else (0.01 if corruption == 'snp1' else 0.05))
    result = frames.copy()
    h, w = frames.shape[-3:-1]
    new_records = []
    destination = str(Path(audit_path).resolve()) if audit_path else None
    for b, sample_seed in enumerate(seeds):
        for t in range(frames.shape[1]):
            key = (int(noise_seed), int(sample_seed), role, int(frame_offset) + t, h, w, density)
            mask, record = mask_record(*key)
            result[b, t][mask == 1] = 255
            result[b, t][mask == 2] = 0
            audit_key = (destination,) + key
            if destination and audit_key not in _recorded:
                new_records.append(record)
                _recorded.add(audit_key)
    if new_records:
        with open(destination, 'a', encoding='utf-8') as f:
            for record in new_records:
                f.write(json.dumps(record, sort_keys=True) + '\n')
    return {**obs, 'visual': result}
