"""Parameter-only continual adaptation, with a frozen-endpoint held-out mode."""
import hashlib
import json
import time
from pathlib import Path
import torch
from .adajepa_mpc import AdaJEPAMPCPlanner


def digest(named):
    h = hashlib.sha256()
    for name, value in named:
        h.update(name.encode()); h.update(str(value.dtype).encode()); h.update(str(tuple(value.shape)).encode())
        h.update(value.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()


class NaiveInheritancePlanner(AdaJEPAMPCPlanner):
    def __init__(self, inheritance=None, **kwargs):
        super().__init__(**kwargs)
        self.c = dict(inheritance or {})
        self.mode = self.c.get('mode', 'learn')
        assert self.mode in ('learn', 'readonly', 'reset_control')
        tr = self.adajepa_trainer
        self.params = list(tr._ada_predictor_params) + list(tr._ada_encoder_params)
        names = {id(p): n for n, p in self.wm.named_parameters()}
        self.names = [names[id(p)] for p in self.params]
        self.initial = {k: v.detach().clone() for k, v in self.wm.state_dict().items()}
        self.carried = [p.detach().clone() for p in self.params]
        self.initial_episode = 0
        if self.c.get('state_in'):
            st = torch.load(self.c['state_in'], map_location='cpu', weights_only=False)
            assert st['schema'] == 'naive-parameters-v2'
            assert st['checkpoint_sha256'] == self.c['checkpoint_sha256']
            assert st['parameter_names'] == self.names
            assert len(st['parameters']) == len(self.params)
            assert digest(zip(self.names, st['parameters'])) == st['parameter_sha256']
            assert all(p.shape == x.shape and p.dtype == x.dtype for p, x in zip(self.params, st['parameters']))
            self.carried = [x.to(p.device).clone() for p, x in zip(self.params, st['parameters'])]
            self.initial_episode = int(st['episode'])
        assert self.mode != 'readonly' or self.c.get('state_in')
        self.loaded_digest = digest(zip(self.names, self.carried))
        self.records = []
        Path('inheritance_definition.json').write_text(json.dumps({
            'mode': self.mode, 'parameter_names': self.names,
            'parameter_count': sum(p.numel() for p in self.params),
            'optimizer': 'Original fresh Adam each finetune; no optimizer state inherited',
            'buffers': 'Original pretrained buffers restored at each episode',
            'replay': 'recent5 within episode only; empty at every episode start',
            'state_in': self.c.get('state_in'), 'loaded_parameter_sha256': self.loaded_digest,
            'initial_episode': self.initial_episode,
        }, indent=2))

    @torch.no_grad()
    def assert_reset(self):
        assert bool(torch.stack([torch.all(v == self.initial[k]) for k, v in self.wm.state_dict().items()]).all())
        assert not self._obs_buffer and not self._act_buffer and not self._segment_scores

    def _plan_single(self, **kwargs):
        self.assert_reset()
        with torch.no_grad():
            if self.mode != 'reset_control':
                for p, x in zip(self.params, self.carried):
                    p.copy_(x)
        before = digest(zip(self.names, self.params))
        expected = (self.records[-1]['parameter_after_sha256']
                    if self.records and self.mode == 'learn' else self.loaded_digest)
        assert before == expected, 'Episode start did not match the required endpoint'
        start = time.perf_counter()
        result = super()._plan_single(**kwargs)
        after = digest(zip(self.names, self.params))
        assert all(torch.isfinite(p).all() for p in self.params)
        if self.mode == 'learn':
            self.carried = [p.detach().clone() for p in self.params]
        row = dict(sample_idx=self._sample_idx, episode=self.initial_episode + len(self.records),
                   mode=self.mode, success=bool(self.is_success[0]), steps=int(self.iter),
                   first_success_step=int(self.action_len[0] / self.n_taken_actions) if self.is_success[0] else None,
                   parameter_before_sha256=before, parameter_after_sha256=after,
                   reset_buffers_verified=True, empty_recent_buffer_verified=True,
                   seconds=time.perf_counter() - start, finished_at=time.time())
        self.records.append(row)
        with open('episodes.jsonl', 'a') as f:
            f.write(json.dumps(row) + '\n')
        print('[episode]', json.dumps(row), flush=True)
        return result

    def plan(self, *args, **kwargs):
        result = super().plan(*args, **kwargs)
        assert bool(torch.stack([torch.all(v == self.initial[k]) for k, v in self.wm.state_dict().items()]).all())
        endpoint = digest(zip(self.names, self.carried))
        if self.mode == 'learn':
            torch.save(dict(schema='naive-parameters-v2', checkpoint_sha256=self.c['checkpoint_sha256'],
                            episode=self.initial_episode + len(self.records), parameter_names=self.names,
                            parameters=[x.cpu() for x in self.carried], parameter_sha256=endpoint),
                       self.c.get('state_out', 'naive_state.pt'))
        else:
            assert endpoint == self.loaded_digest, 'Held-out evaluation changed its persistent state'
        Path('inheritance_audit.json').write_text(json.dumps(dict(
            mode=self.mode, initial_episode=self.initial_episode, final_episode=self.initial_episode + len(self.records),
            loaded_parameter_sha256=self.loaded_digest, final_parameter_sha256=endpoint,
            episodes=len(self.records), exact_episode_starts_verified=True, final_reset_exact=True,
            persistent_state_unchanged=self.mode != 'learn', state_written=self.mode == 'learn'), indent=2))
        return result
